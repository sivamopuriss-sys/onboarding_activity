"""test_model.py"""
import sys; sys.path.insert(0,".")
import torch

def test_fraud_detector_forward():
    from app.model import FraudDetector
    model = FraudDetector(input_dim=5)
    x = torch.randn(4, 5)
    out = model(x)
    assert out.shape == (4, 1)
    assert (out >= 0).all() and (out <= 1).all()

def test_sample_transaction_structure():
    import json
    with open("samples/sample_transactions.jsonl") as f:
        record = json.loads(f.readline())
    required = ["transaction_id","amount","hour_of_day","is_weekend",
                "transactions_last_hour","avg_transaction_amount","label"]
    for k in required:
        assert k in record, f"Missing field: {k}"

def test_fraud_threshold_range():
    threshold = 0.75
    assert 0.5 <= threshold <= 1.0
