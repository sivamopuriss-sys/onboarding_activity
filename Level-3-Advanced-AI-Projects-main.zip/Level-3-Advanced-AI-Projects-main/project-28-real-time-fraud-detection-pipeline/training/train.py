"""train.py — PyTorch transformer model training with W&B"""
import os, json
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score, roc_auc_score, precision_score, recall_score
from sklearn.preprocessing import StandardScaler
import wandb
from pathlib import Path
from dotenv import load_dotenv
from data_gen import generate_dataset

load_dotenv()
wandb.init(project=os.getenv("WANDB_PROJECT","fraud-detection-pipeline"),
           name="transformer-fraud-detector", tags=["pytorch","fraud","transformer"])

FEATURES    = ["amount","hour_of_day","is_weekend","transactions_last_hour","avg_transaction_amount"]
MODEL_PATH  = os.getenv("MODEL_PATH","./model_weights/fraud_detector.pt")
EPOCHS      = 20
BATCH_SIZE  = 256
HIDDEN_DIM  = 64
LR          = 1e-3
THRESHOLD   = float(os.getenv("FRAUD_THRESHOLD","0.75"))


class FraudDetector(nn.Module):
    """Lightweight transformer-style model for tabular fraud detection."""
    def __init__(self, input_dim: int, hidden_dim: int = 64):
        super().__init__()
        self.embedding = nn.Linear(input_dim, hidden_dim)
        self.attention = nn.MultiheadAttention(hidden_dim, num_heads=4, batch_first=True)
        self.norm1     = nn.LayerNorm(hidden_dim)
        self.ff        = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim * 2), nn.ReLU(),
            nn.Linear(hidden_dim * 2, hidden_dim), nn.Dropout(0.1))
        self.norm2     = nn.LayerNorm(hidden_dim)
        self.classifier = nn.Linear(hidden_dim, 1)

    def forward(self, x):
        x = self.embedding(x).unsqueeze(1)      # [B, 1, H]
        attn_out, _ = self.attention(x, x, x)
        x = self.norm1(x + attn_out)
        x = self.norm2(x + self.ff(x))
        return torch.sigmoid(self.classifier(x.squeeze(1)))


def load_data(path: str = "data/transactions.jsonl"):
    if not os.path.exists(path):
        print("Generating synthetic dataset...")
        generate_dataset(output_path=path)
    with open(path) as f:
        records = [json.loads(l) for l in f]
    X = np.array([[r[f] for f in FEATURES] for r in records], dtype=np.float32)
    y = np.array([r["label"] for r in records], dtype=np.float32)
    return X, y


def train():
    X, y = load_data()
    scaler = StandardScaler()
    X = scaler.fit_transform(X)

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)
    train_dl = DataLoader(TensorDataset(torch.tensor(X_train), torch.tensor(y_train)),
                          batch_size=BATCH_SIZE, shuffle=True)
    test_dl  = DataLoader(TensorDataset(torch.tensor(X_test),  torch.tensor(y_test)),
                          batch_size=BATCH_SIZE)

    model     = FraudDetector(input_dim=len(FEATURES), hidden_dim=HIDDEN_DIM)
    optimiser = torch.optim.Adam(model.parameters(), lr=LR)
    criterion = nn.BCELoss()

    wandb.config.update({"epochs":EPOCHS,"batch_size":BATCH_SIZE,"hidden_dim":HIDDEN_DIM,
                         "learning_rate":LR,"threshold":THRESHOLD})

    for epoch in range(EPOCHS):
        model.train()
        train_loss = 0
        for xb, yb in train_dl:
            preds = model(xb).squeeze()
            loss  = criterion(preds, yb)
            optimiser.zero_grad(); loss.backward(); optimiser.step()
            train_loss += loss.item()

        # Evaluate
        model.eval()
        all_preds, all_labels = [], []
        with torch.no_grad():
            for xb, yb in test_dl:
                probs = model(xb).squeeze().numpy()
                all_preds.extend(probs); all_labels.extend(yb.numpy())

        binary_preds = (np.array(all_preds) >= THRESHOLD).astype(int)
        metrics = {
            "epoch":      epoch+1,
            "train_loss": train_loss / len(train_dl),
            "f1":         f1_score(all_labels, binary_preds, zero_division=0),
            "precision":  precision_score(all_labels, binary_preds, zero_division=0),
            "recall":     recall_score(all_labels, binary_preds, zero_division=0),
            "auc_roc":    roc_auc_score(all_labels, all_preds),
        }
        wandb.log(metrics)
        print(f"Epoch {epoch+1}/{EPOCHS} | Loss: {metrics['train_loss']:.4f} | "
              f"F1: {metrics['f1']:.3f} | AUC: {metrics['auc_roc']:.3f}")

    Path(os.path.dirname(MODEL_PATH) or ".").mkdir(exist_ok=True)
    torch.save({"model_state":model.state_dict(),"scaler_mean":scaler.mean_,
                "scaler_scale":scaler.scale_,"features":FEATURES,"threshold":THRESHOLD}, MODEL_PATH)
    print(f"Model saved: {MODEL_PATH}")
    wandb.finish()


if __name__ == "__main__":
    train()
