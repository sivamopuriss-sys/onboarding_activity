"""data_gen.py — Synthetic transaction data generator"""
import json, random, os
from datetime import datetime, timedelta
from pathlib import Path

random.seed(42)

MERCHANTS = ["Amazon","Walmart","Apple Store","Shell","Starbucks","McDonald's",
             "Netflix","Uber","Airbnb","Steam","Unknown Merchant","Offshore Gaming"]
COUNTRIES  = ["US","UK","CA","DE","FR","AU","NG","RU","CN","BR"]


def generate_transaction(is_fraud: bool = False) -> dict:
    base_amount = random.uniform(5, 200) if not is_fraud else random.uniform(500, 5000)
    return {
        "transaction_id": f"TXN-{random.randint(100000,999999)}",
        "timestamp":      (datetime.now() - timedelta(minutes=random.randint(0,1440))).isoformat(),
        "amount":         round(base_amount, 2),
        "merchant":       random.choice(MERCHANTS[-2:]) if is_fraud else random.choice(MERCHANTS[:-2]),
        "merchant_country": random.choice(COUNTRIES[-4:]) if is_fraud else "US",
        "hour_of_day":    random.randint(0,4) if is_fraud else random.randint(8,22),
        "is_weekend":     random.choice([0,1]),
        "transactions_last_hour": random.randint(5,20) if is_fraud else random.randint(0,3),
        "avg_transaction_amount": round(random.uniform(10,50),2),
        "label":          1 if is_fraud else 0,
    }


def generate_dataset(n_samples: int = 10000, fraud_rate: float = 0.05,
                     output_path: str = "data/transactions.jsonl") -> str:
    Path("data").mkdir(exist_ok=True)
    n_fraud = int(n_samples * fraud_rate)
    records = (
        [generate_transaction(is_fraud=True)  for _ in range(n_fraud)] +
        [generate_transaction(is_fraud=False) for _ in range(n_samples - n_fraud)]
    )
    random.shuffle(records)
    with open(output_path,"w") as f:
        for r in records:
            f.write(json.dumps(r)+"\n")
    print(f"Generated {n_samples} transactions ({n_fraud} fraud, {n_samples-n_fraud} legit)")
    return output_path


if __name__ == "__main__":
    generate_dataset()
