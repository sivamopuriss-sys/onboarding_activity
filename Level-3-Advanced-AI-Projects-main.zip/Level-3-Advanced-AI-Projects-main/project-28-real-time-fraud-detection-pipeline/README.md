# Project 28 — Real-Time Fraud Detection Pipeline

![Level](https://img.shields.io/badge/Level-Advanced-purple)
![Industry](https://img.shields.io/badge/Industry-Finance-orange)
![Stack](https://img.shields.io/badge/Stack-PyTorch%20%7C%20Kafka%20%7C%20AWS%20Kinesis%20%7C%20Lambda%20%7C%20W%26B-blue)

## Business Problem
Financial fraud occurs in milliseconds. A fraud detection system must flag suspicious
transactions in under 200ms. Streaming architectures (Kafka/Kinesis) paired with
lightweight transformer-based anomaly detection enable real-time flagging at scale —
one of the most commercially valuable AI engineering use cases.

## Project Objective
Build a complete streaming fraud detection pipeline:
- **PyTorch transformer** trained on synthetic transaction data
- **Kafka producer** simulates real-time transaction stream (local dev)
- **AWS Kinesis + Lambda** for cloud production stream processing
- **Streamlit dashboard** shows live fraud alerts
- **W&B** tracks model training metrics with before/after comparison

## System Architecture
```mermaid
graph TD
    A[Transaction generator] --> B[Kafka producer - local dev]
    A --> C[AWS Kinesis - production]
    B --> D[Kafka consumer + inference]
    C --> E[AWS Lambda + inference]
    D --> F[Fraud flag decision < 200ms]
    E --> F
    F --> G[Streamlit live alert dashboard]
    F --> H[DynamoDB alert store]
    I[PyTorch model training + W&B] --> J[Model artifact]
    J --> D
    J --> E
```

## Folder Structure
```
project-28-real-time-fraud-detection-pipeline/
├── app/
│   ├── model.py            # PyTorch transformer anomaly detector
│   ├── producer.py         # Kafka transaction stream generator
│   ├── consumer.py         # Kafka consumer + inference
│   ├── kinesis_handler.py  # AWS Kinesis Lambda handler
│   └── dashboard.py        # Streamlit live alert dashboard
├── training/
│   ├── train.py            # Model training script + W&B
│   └── data_gen.py         # Synthetic transaction data generator
├── evaluation/
│   └── wandb_eval.py       # Before/after metrics
├── infra/
│   ├── Dockerfile
│   └── template.yaml       # AWS SAM - Lambda + Kinesis
├── tests/
│   └── test_model.py
├── samples/
│   └── sample_transactions.jsonl
├── langsmith_config.py
├── .github/workflows/deploy.yml
├── .env.example
├── requirements.txt
└── README.md
```

## Setup

### Local (Kafka)
```bash
pip install -r requirements.txt
# Start Kafka: docker run -d -p 9092:9092 apache/kafka:latest
python training/train.py        # Train model + log to W&B
python app/consumer.py &        # Start consumer
python app/producer.py          # Stream transactions
streamlit run app/dashboard.py  # View live alerts
```

### Cloud (AWS Kinesis + Lambda)
```bash
sam build && sam deploy --guided
```

## Observability
- W&B tracks: training loss, precision, recall, F1, AUC per epoch
- LangSmith: basic tracing on LLM-assisted alert generation
- Target latency: < 200ms p99 inference

## Time Estimate
| Mode | Time |
|---|---|
| Self-paced | 22–30 hours |
| Instructor-guided | 13–17 hours |

---

## Step-by-Step Implementation Guide

This guide walks you through building this project from scratch. Follow each step in order.

---

### Step 1: Project Setup

```bash
mkdir project-28-real-time-fraud-detection-pipeline
cd project-28-real-time-fraud-detection-pipeline
python -m venv venv && source venv/bin/activate
mkdir -p app training evaluation infra tests samples data model_weights

touch app/model.py app/producer.py app/consumer.py app/kinesis_handler.py app/dashboard.py
touch training/train.py training/data_gen.py
touch requirements.txt .env.example
```

`requirements.txt`:
```
torch>=2.2.0
scikit-learn>=1.4.0
numpy>=1.26.0
pandas>=2.0.0
kafka-python>=2.0.0
boto3>=1.34.0
wandb>=0.17.0
streamlit>=1.35.0
fastapi>=0.110.0
uvicorn>=0.29.0
python-dotenv>=1.0.0
pytest>=8.0.0
```

`.env.example`:
```
KAFKA_BOOTSTRAP_SERVERS=localhost:9092
KAFKA_TOPIC=transactions
MODEL_PATH=./model_weights/fraud_detector.pt
FRAUD_THRESHOLD=0.75
AWS_REGION=us-east-1
KINESIS_STREAM_NAME=fraud-transactions
DYNAMODB_ALERTS_TABLE=fraud-alerts
WANDB_API_KEY=your-wandb-key
WANDB_PROJECT=fraud-detection-pipeline
```

---

### Step 2: Understand Streaming ML System Design

```
Local development:
  Transaction generator → Kafka producer → Kafka consumer + inference → in-memory alerts → Streamlit

Cloud production:
  Transaction source → AWS Kinesis stream → Lambda trigger → inference → DynamoDB alerts → Streamlit
```

**Why Kafka for local development, Kinesis for production?** Kafka runs locally via Docker with zero cloud cost — ideal for developing and testing the streaming pipeline. Kinesis is a fully managed AWS service that handles partition management, replication, and scaling automatically — no infrastructure to maintain. The consumer logic (deserialise → infer → store alert) is nearly identical for both; only the SDK changes.

**Why <200ms latency target?** In credit card fraud, the transaction must be flagged before the merchant processes it (typically 1–3 seconds). A 200ms inference budget gives the model enough time to run while leaving headroom for network latency and the merchant's processing time. At 500ms, the fraud check occurs after approval — too late to prevent the transaction.

**Why a PyTorch transformer instead of XGBoost?** This project uses a lightweight transformer (attention over a small feature vector) to demonstrate the architecture pattern. In practice, XGBoost or LightGBM typically outperform transformers on pure tabular data. The transformer architecture is more realistic for scenarios combining tabular features + transaction text descriptions in a single model.

---

### Step 3: Generate Synthetic Transaction Data (`training/data_gen.py`)

```python
"""data_gen.py — Synthetic transaction data generator"""
import json, random, os
from datetime import datetime, timedelta
from pathlib import Path

random.seed(42)

MERCHANTS = ["Amazon","Walmart","Apple Store","Shell","Starbucks","McDonald's",
             "Netflix","Uber","Airbnb","Steam","Unknown Merchant","Offshore Gaming"]
COUNTRIES = ["US","UK","CA","DE","FR","AU","NG","RU","CN","BR"]


def generate_transaction(is_fraud: bool = False) -> dict:
    base_amount = random.uniform(5, 200) if not is_fraud else random.uniform(500, 5000)
    return {
        "transaction_id":         f"TXN-{random.randint(100000,999999)}",
        "timestamp":              (datetime.now() - timedelta(minutes=random.randint(0,1440))).isoformat(),
        "amount":                 round(base_amount, 2),
        "merchant":               random.choice(MERCHANTS[-2:]) if is_fraud else random.choice(MERCHANTS[:-2]),
        "merchant_country":       random.choice(COUNTRIES[-4:]) if is_fraud else "US",
        "hour_of_day":            random.randint(0,4)  if is_fraud else random.randint(8,22),
        "is_weekend":             random.choice([0,1]),
        "transactions_last_hour": random.randint(5,20) if is_fraud else random.randint(0,3),
        "avg_transaction_amount": round(random.uniform(10,50),2),
        "label":                  1 if is_fraud else 0,
    }


def generate_dataset(n_samples: int = 10000, fraud_rate: float = 0.05,
                     output_path: str = "data/transactions.jsonl") -> str:
    Path("data").mkdir(exist_ok=True)
    n_fraud  = int(n_samples * fraud_rate)
    records  = (
        [generate_transaction(is_fraud=True)  for _ in range(n_fraud)] +
        [generate_transaction(is_fraud=False) for _ in range(n_samples - n_fraud)]
    )
    random.shuffle(records)
    with open(output_path,"w") as f:
        for r in records: f.write(json.dumps(r)+"\n")
    print(f"Generated {n_samples} transactions ({n_fraud} fraud, {n_samples-n_fraud} legit)")
    return output_path


if __name__ == "__main__":
    generate_dataset()
```

**Why 5% fraud rate?** Real-world credit card fraud rates are 0.1–1%. A 5% rate makes training faster (more positive examples to learn from) without creating a dataset so imbalanced that the model defaults to always predicting "legit." When evaluating, always use precision/recall/F1 rather than accuracy — 95% accuracy by predicting "legit" every time is useless.

**Why these specific features?** `amount`, `hour_of_day`, `is_weekend`, `transactions_last_hour`, and `avg_transaction_amount` are the most predictive tabular fraud signals without requiring PII. Fraudsters tend to transact at off-hours (2–4am), in large amounts, with unfamiliar merchants, in quick succession. These patterns are deliberately baked into the synthetic generator.

---

### Step 4: Train the Fraud Detection Model (`training/train.py`)

The training script uses a lightweight transformer architecture. Key implementation details from `training/train.py`:

```python
class FraudDetector(nn.Module):
    """Lightweight transformer-style model for tabular fraud detection."""
    def __init__(self, input_dim: int, hidden_dim: int = 64):
        super().__init__()
        self.embedding = nn.Linear(input_dim, hidden_dim)
        self.attention = nn.MultiheadAttention(hidden_dim, num_heads=4, batch_first=True)
        self.norm1     = nn.LayerNorm(hidden_dim)
        self.ff        = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim * 2), nn.ReLU(),
            nn.Linear(hidden_dim * 2, hidden_dim), nn.Dropout(0.1))
        self.norm2     = nn.LayerNorm(hidden_dim)
        self.classifier = nn.Linear(hidden_dim, 1)

    def forward(self, x):
        x = self.embedding(x).unsqueeze(1)   # [B, 1, H]
        attn_out, _ = self.attention(x, x, x)
        x = self.norm1(x + attn_out)
        x = self.norm2(x + self.ff(x))
        return torch.sigmoid(self.classifier(x.squeeze(1)))
```

**Architecture explanation:** The model embeds 5 numerical features into a 64-dimensional space, runs self-attention (4 heads), applies layer normalisation + feed-forward layers (residual connections), and classifies with a final linear + sigmoid. The self-attention step allows the model to learn non-linear interactions between features — for example, "high amount AND off-hours AND foreign merchant" is more suspicious than any single feature alone.

To train:
```bash
cd training
python train.py
# Logs to W&B automatically. View at wandb.ai
```

W&B will show: training loss, F1, precision, recall, AUC-ROC per epoch.

**Before/after baseline comparison:** Create a simple baseline (always predict legit = F1 of 0.0 for fraud class, AUC-ROC = 0.5). Your trained model should achieve F1 > 0.85 and AUC-ROC > 0.92 on the test set.

---

### Step 5: The Fraud Detector Model (`app/model.py`)

The model module loads the trained PyTorch model and runs inference. Key design from `app/model.py`:

```python
FEATURES  = ["amount","hour_of_day","is_weekend","transactions_last_hour","avg_transaction_amount"]
THRESHOLD = float(os.getenv("FRAUD_THRESHOLD","0.75"))

def predict(transaction: dict) -> dict:
    """Run inference. Returns fraud probability and flag."""
    features = np.array([[transaction.get(f,0) for f in FEATURES]], dtype=np.float32)
    features = (features - _scaler_mean) / _scaler_scale  # StandardScaler normalisation
    with torch.no_grad():
        prob = _model(torch.tensor(features)).item()
    return {
        "transaction_id":  transaction.get("transaction_id","unknown"),
        "fraud_probability": round(prob, 4),
        "is_fraud":        prob >= _threshold,
        "threshold":       _threshold,
    }
```

**Why load the model at module import (`load_model()` at the top)?** For the Kafka consumer, loading the model inside the message loop would re-load from disk on every transaction — adding 500ms+ latency per message. Loading once at process startup means inference runs with an already-warm model in 5–50ms. For Lambda (`kinesis_handler.py`), loading at module import means it loads on cold start and stays warm for subsequent invocations in the same execution environment.

**Why `StandardScaler` normalisation?** Raw features have very different scales: `amount` ranges 5–5000, `is_weekend` is 0 or 1. Without normalisation, the neural network's gradient updates are dominated by large-scale features and the small-scale features are ignored. Normalising to mean=0, std=1 ensures all features contribute equally to the model's learning.

---

### Step 6: Build the Kafka Producer (`app/producer.py`)

```python
"""producer.py — Kafka transaction stream producer"""
import json, time, random
from kafka import KafkaProducer
from training.data_gen import generate_transaction
from dotenv import load_dotenv
import os
load_dotenv()

TOPIC   = os.getenv("KAFKA_TOPIC","transactions")
SERVERS = os.getenv("KAFKA_BOOTSTRAP_SERVERS","localhost:9092")


def run_producer(tps: int = 10, fraud_rate: float = 0.05):
    """Stream synthetic transactions at `tps` transactions per second."""
    producer = KafkaProducer(
        bootstrap_servers=SERVERS,
        value_serializer=lambda v: json.dumps(v).encode("utf-8"),
    )
    print(f"Streaming to '{TOPIC}' at {tps} TPS (fraud_rate={fraud_rate*100:.0f}%)")
    try:
        while True:
            is_fraud = random.random() < fraud_rate
            txn = generate_transaction(is_fraud=is_fraud)
            producer.send(TOPIC, txn)
            time.sleep(1 / tps)
    except KeyboardInterrupt:
        print("Producer stopped.")
    finally:
        producer.flush()
        producer.close()


if __name__ == "__main__":
    run_producer()
```

Start Kafka locally with Docker:
```bash
docker run -d -p 9092:9092 \
  -e KAFKA_NODE_ID=1 \
  -e KAFKA_PROCESS_ROLES=broker,controller \
  -e KAFKA_LISTENERS=PLAINTEXT://:9092,CONTROLLER://:9093 \
  -e KAFKA_ADVERTISED_LISTENERS=PLAINTEXT://localhost:9092 \
  -e KAFKA_CONTROLLER_QUORUM_VOTERS=1@localhost:9093 \
  apache/kafka:latest
```

**Why `value_serializer=lambda v: json.dumps(v).encode("utf-8")`?** Kafka messages are raw bytes. The producer needs to serialise Python dicts to bytes before sending; the consumer needs to deserialise bytes back to dicts. Consistent JSON serialisation ensures producer and consumer agree on the wire format. In production, Avro or Protobuf schemas provide stricter typing and smaller message sizes.

---

### Step 7: Build the Kafka Consumer + Inference (`app/consumer.py`)

```python
"""consumer.py — Kafka consumer with real-time fraud inference"""
import json, time
from kafka import KafkaConsumer
from model import predict, load_model
from dotenv import load_dotenv
import os
load_dotenv()

TOPIC   = os.getenv("KAFKA_TOPIC","transactions")
SERVERS = os.getenv("KAFKA_BOOTSTRAP_SERVERS","localhost:9092")
alerts  = []  # In-memory store (use DynamoDB in production)


def run_consumer():
    load_model()
    consumer = KafkaConsumer(
        TOPIC,
        bootstrap_servers=SERVERS,
        value_deserializer=lambda v: json.loads(v.decode("utf-8")),
        auto_offset_reset="latest",
        group_id="fraud-detection-group",
    )
    print(f"Listening on '{TOPIC}'...")
    for msg in consumer:
        t_start    = time.time()
        txn        = msg.value
        result     = predict(txn)
        latency_ms = (time.time() - t_start) * 1000

        if result["is_fraud"]:
            alert = {**txn, **result, "latency_ms": round(latency_ms,2)}
            alerts.append(alert)
            print(f"FRAUD ALERT: {result['transaction_id']} | prob={result['fraud_probability']:.3f} | {latency_ms:.1f}ms")
        else:
            print(f"OK: {result['transaction_id']} | prob={result['fraud_probability']:.3f}")


if __name__ == "__main__":
    run_consumer()
```

**Why `auto_offset_reset="latest"`?** When the consumer starts (or restarts after a crash), "latest" means it picks up from the current end of the topic — processing only new transactions. "Earliest" would re-process all historical messages, generating false fraud alerts for old transactions. For real-time fraud detection, you only care about transactions happening now.

**Why `group_id="fraud-detection-group"`?** Consumer groups enable Kafka's partition-based parallelism. Multiple consumer instances with the same group ID will each process a different partition — allowing horizontal scaling. If you add a second consumer instance with the same group ID, Kafka automatically rebalances the partition assignment.

---

### Step 8: Build the AWS Kinesis Lambda Handler (`app/kinesis_handler.py`)

```python
"""kinesis_handler.py — AWS Lambda handler for Kinesis stream"""
import json, base64, boto3, os, time
from model import predict, load_model

try:
    load_model()  # Load at cold start — stays warm for subsequent invocations
except Exception as e:
    print(f"Model load warning: {e}")

dynamodb = boto3.resource("dynamodb", region_name=os.getenv("AWS_REGION","us-east-1"))
TABLE    = os.getenv("DYNAMODB_ALERTS_TABLE","fraud-alerts")


def handler(event, context):
    """AWS Lambda handler for Kinesis records."""
    alerts = []
    for record in event.get("Records",[]):
        payload    = json.loads(base64.b64decode(record["kinesis"]["data"]))
        t_start    = time.time()
        result     = predict(payload)
        latency_ms = (time.time() - t_start) * 1000

        if result["is_fraud"]:
            alert = {**payload, **result, "latency_ms": round(latency_ms,2)}
            alerts.append(alert)
            try:
                dynamodb.Table(TABLE).put_item(Item={k: str(v) for k, v in alert.items()})
            except Exception as e:
                print(f"DynamoDB write failed: {e}")

    return {"alerts_generated": len(alerts),
            "records_processed": len(event.get("Records",[]))}
```

**Why `base64.b64decode`?** Kinesis encodes record data as base64 in the Lambda event payload. The raw JSON transaction string must be decoded from base64 before JSON parsing. This is a Kinesis-specific requirement — Kafka's consumer does not have this step.

**Why `{k: str(v) for k, v in alert.items()}`?** DynamoDB cannot store Python `float` or `bool` types directly in some SDK versions. Converting all values to strings is a safe workaround. In production, use `Decimal` for numeric values (DynamoDB's native numeric type).

---

### Step 9: Build the Streamlit Dashboard (`app/dashboard.py`)

The Streamlit dashboard at `app/dashboard.py` provides a live fraud alert view:

```python
# Key sections of dashboard.py:
import time
import streamlit as st
import pandas as pd

st.set_page_config(page_title="Fraud Detection Dashboard", page_icon="🚨", layout="wide")
st.title("Real-Time Fraud Detection Dashboard")

with st.sidebar:
    threshold = st.slider("Fraud threshold", 0.5, 0.99, 0.75, 0.01)
    refresh   = st.slider("Refresh interval (s)", 1, 10, 2)
    demo_mode = st.checkbox("Demo mode", value=True)

# Metrics row
col1, col2, col3, col4 = st.columns(4)
col1.metric("Alerts Today", "47", "+3")
col2.metric("Avg Latency", "94ms", "-12ms")
# ...

# In live mode: st.rerun() + time.sleep(refresh) creates a refresh loop
```

Start the dashboard:
```bash
# Terminal 1: start consumer
python app/consumer.py &

# Terminal 2: start producer
python app/producer.py &

# Terminal 3: launch dashboard
streamlit run app/dashboard.py
```

**Why `st.rerun()` for live updates?** Streamlit re-executes the entire script on each rerun. Calling `st.rerun()` after `time.sleep(refresh)` creates a polling loop that refreshes the dashboard every N seconds, picking up new alerts from the consumer's in-memory list or DynamoDB.

---

### Step 10: Troubleshooting

| Error | Cause | Fix |
|---|---|---|
| `kafka.errors.NoBrokersAvailable` | Kafka not running | Start Kafka Docker container (see Step 6) |
| `FileNotFoundError: model_weights/fraud_detector.pt` | Model not trained yet | Run `python training/train.py` first |
| Lambda: `Runtime.ImportModuleError: No module named 'model'` | Python path issue in Lambda | Add `sys.path.insert(0, "/var/task")` at top of `kinesis_handler.py` |
| Inference latency >200ms | Model loading on every call | Ensure `load_model()` is called at module level, not inside the handler function |
| W&B not logging metrics | `WANDB_API_KEY` not set | Run `wandb login` or add key to `.env` |
| DynamoDB: `ValidationException: Invalid attribute value type` | Float/bool values in DynamoDB item | Convert all values to str: `{k: str(v) for k, v in alert.items()}` |
| Streamlit dashboard shows no live data | Consumer `alerts` list not shared | In demo mode, use static data; for live mode, serve alerts via a shared file or API |

---

## Evaluation Rubric

| Criteria | Meets | Exceeds |
|---|---|---|
| **Model** | PyTorch model trains to F1 > 0.80; W&B training curves logged | Before/after baseline comparison; AUC-ROC > 0.92 |
| **Kafka pipeline** | Producer streams transactions; consumer classifies in <200ms | Latency measured and logged per message; group_id enables scaling |
| **AWS Kinesis** | Lambda handler processes Kinesis records; alerts written to DynamoDB | SAM template complete; Kinesis trigger configured |
| **Dashboard** | Streamlit dashboard shows alerts | Live refresh working; threshold slider changes fraud flag in real time |
| **Architecture** | Model, producer, consumer separated into distinct modules | Inference identical for Kafka and Kinesis paths |

---

## Interview Talking Points

1. **Why Kafka for local development, Kinesis for production?** — Kafka requires managing brokers, ZooKeeper/KRaft, partition replication, and consumer group coordination. Kinesis is fully managed — AWS handles all infrastructure. For a startup, Kinesis saves 40–60 engineering hours of Kafka operations per year. For a company already running Kafka infrastructure, it makes sense to extend it to ML inference.

2. **How do you measure the 200ms latency target?** — `latency_ms = (time.time() - t_start) * 1000` measured around the `predict()` call in the consumer/handler. Log percentiles (p50, p95, p99) to W&B. p99 latency is the critical metric — it tells you the worst case, not just the average.

3. **What's the difference between precision and recall for this use case?** — Precision = of all transactions flagged as fraud, what % were actually fraud (false alarm rate). Recall = of all actual fraud transactions, what % did we catch (miss rate). For fraud detection, recall is more important — missing a fraud is more costly than a false alarm. Target: Recall > 0.90, Precision > 0.80.

4. **How would you handle model drift in production?** — Monitor the fraud rate distribution over time in W&B. If it changes significantly (e.g., a new fraud pattern emerges), retrain the model on recent data. Implement a shadow mode where the new model runs in parallel with the production model, comparing predictions before switching over.

5. **What is exactly-once semantics and why does it matter here?** — Kafka/Kinesis can deliver messages "at least once" — if a consumer crashes and restarts, it may re-process the same message. For fraud detection, re-processing could create duplicate fraud alerts for the same transaction. Use idempotent writes (DynamoDB conditional puts on `transaction_id`) to prevent duplicate alerts.

---

## Bonus Extensions

- **Ensemble model:** Average predictions from the PyTorch transformer and an XGBoost model trained on the same features — typically improves F1 by 2–5 percentage points.
- **Graph neural network:** Model the transaction network (customer → merchant → bank) as a graph — fraudulent networks create distinct structural patterns invisible to single-transaction models.
- **Real-time feature engineering:** Add velocity features computed from the last N transactions (rolling average, time since last transaction) by maintaining state in a Redis cache.
- **Automated model retraining:** When the fraud rate detected by the model diverges from the true fraud rate (measured via a 24-hour delayed label), trigger an automated retraining job in SageMaker Pipelines.

