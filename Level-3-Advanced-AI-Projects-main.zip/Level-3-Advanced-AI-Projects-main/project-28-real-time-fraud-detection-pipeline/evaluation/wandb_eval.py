"""wandb_eval.py — Before/after model comparison"""
import wandb
import numpy as np
from sklearn.metrics import f1_score, roc_auc_score, precision_score, recall_score

def log_before_after(base_preds, ft_preds, true_labels, base_proba, ft_proba):
    wandb.init(project="fraud-detection-pipeline", name="before-after-comparison")
    threshold = 0.75
    base_bin  = (np.array(base_proba) >= threshold).astype(int)
    ft_bin    = (np.array(ft_proba)   >= threshold).astype(int)

    table = wandb.Table(
        columns=["Metric","Base Model","Fine-tuned","Delta"],
        data=[
            ["F1 Score",  f1_score(true_labels,base_bin),  f1_score(true_labels,ft_bin),
             f1_score(true_labels,ft_bin)-f1_score(true_labels,base_bin)],
            ["Precision", precision_score(true_labels,base_bin,zero_division=0),
             precision_score(true_labels,ft_bin,zero_division=0), 0],
            ["Recall",    recall_score(true_labels,base_bin,zero_division=0),
             recall_score(true_labels,ft_bin,zero_division=0), 0],
            ["AUC-ROC",   roc_auc_score(true_labels,base_proba),
             roc_auc_score(true_labels,ft_proba), 0],
        ]
    )
    wandb.log({"fraud_model_comparison": table})
    wandb.finish()
