"""model.py — Load and run the fraud detection model"""
import os, json
import numpy as np
import torch
import torch.nn as nn
from dotenv import load_dotenv
load_dotenv()

FEATURES   = ["amount","hour_of_day","is_weekend","transactions_last_hour","avg_transaction_amount"]
MODEL_PATH = os.getenv("MODEL_PATH","./model_weights/fraud_detector.pt")
THRESHOLD  = float(os.getenv("FRAUD_THRESHOLD","0.75"))


class FraudDetector(nn.Module):
    def __init__(self, input_dim, hidden_dim=64):
        super().__init__()
        self.embedding  = nn.Linear(input_dim, hidden_dim)
        self.attention  = nn.MultiheadAttention(hidden_dim, num_heads=4, batch_first=True)
        self.norm1      = nn.LayerNorm(hidden_dim)
        self.ff         = nn.Sequential(nn.Linear(hidden_dim,hidden_dim*2),nn.ReLU(),
                                        nn.Linear(hidden_dim*2,hidden_dim),nn.Dropout(0.1))
        self.norm2      = nn.LayerNorm(hidden_dim)
        self.classifier = nn.Linear(hidden_dim, 1)

    def forward(self, x):
        x = self.embedding(x).unsqueeze(1)
        attn_out, _ = self.attention(x, x, x)
        x = self.norm1(x + attn_out)
        x = self.norm2(x + self.ff(x))
        return torch.sigmoid(self.classifier(x.squeeze(1)))


_model, _scaler_mean, _scaler_scale, _threshold = None, None, None, THRESHOLD


def load_model():
    global _model, _scaler_mean, _scaler_scale, _threshold
    if not os.path.exists(MODEL_PATH):
        raise FileNotFoundError(f"Model not found at {MODEL_PATH}. Run: python training/train.py")
    ckpt = torch.load(MODEL_PATH, map_location="cpu")
    _model = FraudDetector(input_dim=len(FEATURES))
    _model.load_state_dict(ckpt["model_state"])
    _model.eval()
    _scaler_mean  = ckpt["scaler_mean"]
    _scaler_scale = ckpt["scaler_scale"]
    _threshold    = ckpt.get("threshold", THRESHOLD)
    return _model


def predict(transaction: dict) -> dict:
    """Run inference on a single transaction. Returns fraud probability and flag."""
    global _model
    if _model is None:
        load_model()
    features = np.array([[transaction.get(f, 0) for f in FEATURES]], dtype=np.float32)
    features = (features - _scaler_mean) / _scaler_scale
    with torch.no_grad():
        prob = _model(torch.tensor(features)).item()
    return {
        "transaction_id": transaction.get("transaction_id","unknown"),
        "fraud_probability": round(prob, 4),
        "is_fraud": prob >= _threshold,
        "threshold": _threshold,
    }
