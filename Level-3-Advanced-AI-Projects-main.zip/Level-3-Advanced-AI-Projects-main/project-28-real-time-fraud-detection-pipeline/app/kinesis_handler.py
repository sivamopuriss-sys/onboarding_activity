"""kinesis_handler.py — AWS Lambda handler for Kinesis stream"""
import json, base64, boto3, os, time
from model import predict, load_model

# Load model at cold start
try:
    load_model()
except Exception as e:
    print(f"Model load warning: {e}")

dynamodb = boto3.resource("dynamodb", region_name=os.getenv("AWS_REGION","us-east-1"))
TABLE    = os.getenv("DYNAMODB_ALERTS_TABLE","fraud-alerts")


def handler(event, context):
    """AWS Lambda handler for Kinesis records."""
    alerts = []
    for record in event.get("Records", []):
        payload = json.loads(base64.b64decode(record["kinesis"]["data"]))
        t_start = time.time()
        result  = predict(payload)
        latency_ms = (time.time() - t_start) * 1000

        if result["is_fraud"]:
            alert = {**payload, **result, "latency_ms": round(latency_ms, 2)}
            alerts.append(alert)
            # Write to DynamoDB
            try:
                table = dynamodb.Table(TABLE)
                table.put_item(Item={k: str(v) for k, v in alert.items()})
            except Exception as e:
                print(f"DynamoDB write failed: {e}")

    return {"alerts_generated": len(alerts), "records_processed": len(event.get("Records",[]))}
