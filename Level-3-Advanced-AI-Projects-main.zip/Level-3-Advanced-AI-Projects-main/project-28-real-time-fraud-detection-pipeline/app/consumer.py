"""consumer.py — Kafka consumer with real-time fraud inference"""
import json, time
from kafka import KafkaConsumer
from model import predict, load_model
from dotenv import load_dotenv
import os
load_dotenv()

TOPIC   = os.getenv("KAFKA_TOPIC","transactions")
SERVERS = os.getenv("KAFKA_BOOTSTRAP_SERVERS","localhost:9092")
alerts  = []   # In-memory store (use DynamoDB in production)

def run_consumer():
    load_model()
    consumer = KafkaConsumer(
        TOPIC,
        bootstrap_servers=SERVERS,
        value_deserializer=lambda v: json.loads(v.decode("utf-8")),
        auto_offset_reset="latest",
        group_id="fraud-detection-group",
    )
    print(f"Listening on {TOPIC}...")
    for msg in consumer:
        t_start = time.time()
        txn     = msg.value
        result  = predict(txn)
        latency_ms = (time.time() - t_start) * 1000

        if result["is_fraud"]:
            alert = {**txn, **result, "latency_ms": round(latency_ms, 2)}
            alerts.append(alert)
            print(f"FRAUD ALERT: {result['transaction_id']} | "
                  f"prob={result['fraud_probability']:.3f} | {latency_ms:.1f}ms")
        else:
            print(f"OK: {result['transaction_id']} | prob={result['fraud_probability']:.3f}")

if __name__ == "__main__":
    run_consumer()
