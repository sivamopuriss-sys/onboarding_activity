"""dashboard.py — Streamlit live fraud alert dashboard"""
import time, json, os
from pathlib import Path
import streamlit as st
import pandas as pd

st.set_page_config(page_title="Fraud Detection Dashboard", page_icon="🚨", layout="wide")
st.title("🚨 Real-Time Fraud Detection Dashboard")

DEMO_ALERTS = [
    {"transaction_id":"TXN-991234","amount":4299.99,"merchant":"Unknown Merchant",
     "merchant_country":"NG","fraud_probability":0.94,"is_fraud":True,"latency_ms":87.3},
    {"transaction_id":"TXN-882341","amount":3150.00,"merchant":"Offshore Gaming",
     "merchant_country":"RU","fraud_probability":0.88,"is_fraud":True,"latency_ms":92.1},
]

with st.sidebar:
    st.header("Settings")
    threshold = st.slider("Fraud threshold", 0.5, 0.99, 0.75, 0.01)
    refresh   = st.slider("Refresh interval (s)", 1, 10, 2)
    demo_mode = st.checkbox("Demo mode (no Kafka required)", value=True)

# Metrics
col1, col2, col3, col4 = st.columns(4)
col1.metric("Alerts Today", "47", "+3")
col2.metric("Avg Latency", "94ms", "-12ms")
col3.metric("Fraud Rate", "4.7%", "+0.2%")
col4.metric("Transactions/min", "~600", "")

st.markdown("---")
st.subheader("Live Fraud Alerts")

if demo_mode:
    df = pd.DataFrame(DEMO_ALERTS)
    st.warning("Demo mode — showing sample alerts. Connect Kafka to see live data.")
else:
    # In production: read from consumer.alerts list or DynamoDB
    st.info("Waiting for live alerts from Kafka consumer...")
    df = pd.DataFrame()

if not df.empty:
    df["fraud_probability"] = df["fraud_probability"].apply(lambda x: f"{x*100:.1f}%")
    st.dataframe(df[["transaction_id","amount","merchant","merchant_country",
                      "fraud_probability","latency_ms"]], use_container_width=True)

if not demo_mode:
    time.sleep(refresh)
    st.rerun()
