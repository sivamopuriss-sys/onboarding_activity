"""producer.py — Kafka transaction stream producer"""
import json, time, random
from kafka import KafkaProducer
from training.data_gen import generate_transaction
from dotenv import load_dotenv
import os
load_dotenv()

TOPIC   = os.getenv("KAFKA_TOPIC","transactions")
SERVERS = os.getenv("KAFKA_BOOTSTRAP_SERVERS","localhost:9092")

def run_producer(tps: int = 10, fraud_rate: float = 0.05):
    """Stream synthetic transactions at `tps` transactions per second."""
    producer = KafkaProducer(
        bootstrap_servers=SERVERS,
        value_serializer=lambda v: json.dumps(v).encode("utf-8"),
    )
    print(f"Streaming to {TOPIC} at {tps} TPS (fraud_rate={fraud_rate*100:.0f}%)")
    try:
        while True:
            is_fraud = random.random() < fraud_rate
            txn = generate_transaction(is_fraud=is_fraud)
            producer.send(TOPIC, txn)
            time.sleep(1 / tps)
    except KeyboardInterrupt:
        print("Producer stopped.")
    finally:
        producer.flush()
        producer.close()

if __name__ == "__main__":
    run_producer()
