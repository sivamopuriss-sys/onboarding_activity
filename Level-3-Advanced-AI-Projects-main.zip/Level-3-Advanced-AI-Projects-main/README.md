# Level 3 (Advanced) — AI Projects for Assignments

![Level](https://img.shields.io/badge/Level-Advanced-purple)
![Projects](https://img.shields.io/badge/Projects-10-purple)
![Language](https://img.shields.io/badge/Language-Python%20%7C%20TypeScript-yellow)
![AI](https://img.shields.io/badge/AI-CrewAI%20%7C%20LangGraph%20%7C%20Fine--tuning%20%7C%20Streaming-purple)
![Support](https://img.shields.io/badge/Support-KKRGENAI-orange)

---

## Overview

Welcome to the **Level 3 (Advanced) AI Projects** collection — a curated set of 10 production-grade AI systems designed for engineers who are ready to build, deploy, and evaluate real-world AI products at scale.

These projects go beyond multi-component architectures into the hardest problems in applied AI engineering: multi-agent orchestration with CrewAI, parameter-efficient fine-tuning with LoRA/QLoRA, real-time streaming inference, full-stack AI platforms, and cloud deployments on AWS, GCP, and Azure.

Each project targets a high-value industry use case and introduces patterns seen in production AI engineering at leading companies — so students build systems they can defend in a senior technical interview.

---

## Why These Projects?

Level 2 taught you to build systems. Level 3 teaches you to build **production AI products**:

- **Multi-agent orchestration** — CrewAI crews with specialised, adversarial, and arbitrating agents
- **Fine-tuning** — LoRA/QLoRA on GPU (free Colab) and OpenAI Fine-tuning API, with W&B experiment tracking and before/after accuracy comparison
- **Real-time streaming** — Kafka + AWS Kinesis + Lambda for sub-200ms inference pipelines
- **LangGraph stateful agents** — complex conditional routing, persistent state, multi-tool orchestration
- **Cloud deployment** — AWS Lambda/SageMaker, GCP Cloud Run/Vertex AI, Azure Container Apps
- **Observability** — LangSmith tracing, W&B dashboards, cost guardrails with TokenBudget
- **Guardrails** — Instructor validation, PII detection, safety layers before external API calls
- **Full-stack AI** — Next.js frontends, FastAPI backends, PostgreSQL/DynamoDB persistence

The goal: **by completing these projects, a student should be able to architect, build, deploy, and explain production AI systems in a Staff Engineer or AI Engineer technical interview.**

---

## Who Is This For?

| Audience | How This Helps |
|---|---|
| **Students who completed Level 2** | Take the next step from systems to production products |
| **AI Engineers targeting senior roles** | Portfolio-ready advanced projects for Staff/Senior interviews |
| **ML Engineers expanding into LLMs** | Learn agent orchestration, fine-tuning pipelines, and LLM ops |
| **Data Scientists moving to engineering** | Build the production layer around your models |
| **Educators / Instructors** | Ready-made advanced assignment templates |

---

## Skill Level

**Level 3 — Advanced**

You are ready for these projects if you:
- Completed Level 2 projects (or have equivalent experience)
- Are comfortable with FastAPI, LangChain, and LangGraph StateGraph
- Have used Pinecone or another cloud vector store
- Understand the basics of model fine-tuning conceptually

You will learn in these projects:
- CrewAI multi-agent orchestration with role, goal, backstory, and task handoffs
- LoRA and QLoRA fine-tuning with Hugging Face Transformers + PEFT
- OpenAI Fine-tuning API as a production alternative
- W&B for experiment tracking, loss curves, and before/after comparison
- Kafka and AWS Kinesis for real-time streaming inference
- AWS Lambda, SageMaker, GCP Cloud Run/Vertex AI, Azure Container Apps
- LangSmith for tracing multi-agent and multi-step workflows
- Instructor for structured output validation from LLM agents
- python-docx for document generation
- Twilio SMS, Google Calendar API, Shopify Admin API, Serper API

---

## Projects at a Glance

| # | Project | Industry | Stack |
|---|---|---|---|
| 21 | [Radiology Report Multi-Agent System](./project-21-radiology-report-multi-agent-system/) | Healthcare | CrewAI, GPT-4o, AWS Lambda, LangSmith |
| 22 | [Algorithmic Trading Signal Engine](./project-22-algorithmic-trading-signal-engine/) | Finance | LoRA, OpenAI Fine-tuning, GCP Vertex AI, W&B |
| 23 | [Autonomous E-commerce Catalog Manager](./project-23-autonomous-ecommerce-catalog-manager/) | E-Commerce | LangGraph, MCP, Shopify API, GCP Cloud Run |
| 24 | [AI Legal Contract Negotiation Agent](./project-24-ai-legal-contract-negotiation-agent/) | Legal | CrewAI, Claude API, Instructor, Azure, python-docx |
| 25 | [Talent Intelligence Platform](./project-25-talent-intelligence-platform/) | HR / Recruitment | LoRA, OpenAI Fine-tuning, AWS SageMaker, W&B |
| 26 | [Adaptive Learning OS](./project-26-adaptive-learning-os/) | EdTech | LangGraph, Pinecone, Fine-tuning, Next.js, PostgreSQL |
| 27 | [Clinical Decision Support System](./project-27-clinical-decision-support-system/) | Healthcare | LangGraph, RAG, Guardrails, AWS Lambda, W&B |
| 28 | [Real-Time Fraud Detection Pipeline](./project-28-real-time-fraud-detection-pipeline/) | Finance | PyTorch, Kafka, AWS Kinesis, Lambda, W&B |
| 29 | [Autonomous SEO Content Pipeline](./project-29-autonomous-seo-content-pipeline/) | Universal | CrewAI, Serper API, Instructor, GCP Cloud Run |
| 30 | [Intelligent Customer Onboarding Agent](./project-30-intelligent-customer-onboarding-agent/) | Universal | LangGraph, Pinecone, Twilio, DynamoDB, AWS Lambda |

---

## Project Descriptions

### Project 21 — Radiology Report Multi-Agent System
**Industry:** Healthcare
A CrewAI 3-agent pipeline that reads DICOM metadata, drafts a structured radiology report (ACR format), and flags critical findings for urgent review. Deployed as AWS Lambda. All agent steps traced in LangSmith. Teaches multi-agent task handoffs, Instructor validation, and serverless AI deployment in a regulated domain.

### Project 22 — Algorithmic Trading Signal Engine
**Industry:** Finance
Fine-tunes a transformer model on financial news headlines to classify Buy / Sell / Hold signals. Two training paths: LoRA/QLoRA on a free Colab GPU, or the OpenAI Fine-tuning API. Backtests against historical price data and deploys as a FastAPI inference service on GCP Vertex AI. Teaches parameter-efficient fine-tuning, W&B experiment tracking, and GCP deployment.

### Project 23 — Autonomous E-commerce Catalog Manager
**Industry:** E-Commerce
A LangGraph ReAct agent with 4 real tools: price scraper, listing rewriter, inventory updater, and promotion trigger (Shopify Admin API). MCP configures tool access. Webhook-triggered. All tool calls traced in LangSmith. Teaches autonomous agent tool routing, Shopify API integration, and conditional decision-making.

### Project 24 — AI Legal Contract Negotiation Agent
**Industry:** Legal
A CrewAI 3-agent system where Buyer and Seller agents negotiate clause-by-clause and an Arbitrator produces a final redlined DOCX with tracked changes via python-docx. Instructor validates structured negotiation outputs. Deployed on Azure Container Apps. Teaches adversarial agent design, structured output validation, and document generation.

### Project 25 — Talent Intelligence Platform
**Industry:** HR / Recruitment
Fine-tunes a text classification model on synthetic hire outcome data to predict candidate fit (0–100 score). Deployed as a REST API via AWS SageMaker. ATS webhook integration. Full W&B experiment tracking with bias testing across demographic groups. Teaches fine-tuning for classification, SageMaker deployment, and responsible AI evaluation.

### Project 26 — Adaptive Learning OS
**Industry:** EdTech
Full-stack adaptive learning platform: RAG over course materials (Pinecone), fine-tuned tutor model, LangGraph difficulty orchestrator, Next.js dashboard, and PostgreSQL session storage. Backend on GCP Cloud Run, frontend on Vercel. Teaches full-stack AI product architecture combining RAG, fine-tuning, agents, and a production frontend.

### Project 27 — Clinical Decision Support System
**Industry:** Healthcare
A LangGraph multi-node agent that processes patient symptoms against a medical knowledge base (RAG over clinical guidelines), recommends diagnostic steps, checks drug interactions, and enforces safety guardrails (no final diagnoses — human review required). Deployed on AWS Lambda. W&B tracks decision quality. Teaches safety-first agent design in a regulated domain.

### Project 28 — Real-Time Fraud Detection Pipeline
**Industry:** Finance
A complete streaming fraud detection pipeline: PyTorch transformer trained on synthetic transaction data, Kafka producer for local development, AWS Kinesis + Lambda for cloud, and a Streamlit live alert dashboard. Target latency: <200ms. W&B tracks model training metrics. Teaches streaming ML system design and real-time inference architecture.

### Project 29 — Autonomous SEO Content Production Pipeline
**Industry:** Universal
A CrewAI 3-agent pipeline: Researcher (Serper API for keyword + competitor analysis), Writer (1500–2500 word article), Editor (brand voice + SEO polish). Instructor validates ArticleOutput schema. TokenBudget controls cost. Deployed on GCP Cloud Run. Teaches content automation, web search tool integration, and structured output enforcement.

### Project 30 — Intelligent Customer Onboarding Agent
**Industry:** Universal
A LangGraph stateful onboarding agent that personalises welcome flows, answers product questions via Pinecone RAG, sends SMS check-ins via Twilio, schedules follow-up calls via Google Calendar, and tracks milestone completion in DynamoDB. PII guardrails before any external API call. Deployed as AWS Lambda + API Gateway. Teaches complex multi-integration agent design with production safety controls.

---

## How a Student Benefits

### From Systems to Products
Level 3 projects are complete products with multiple integrated services:
- A fine-tuned model trained, evaluated, and deployed to a cloud endpoint
- An agentic orchestration layer managing complex multi-step workflows
- Real integrations with third-party APIs (Shopify, Twilio, Google Calendar, Serper)
- Cloud-deployed, observable, cost-controlled production services

### Learn Multi-Agent Design
Projects 21, 24, and 29 use CrewAI — a production multi-agent framework. You'll learn:
- How to design agents with specific roles, goals, and backstories
- How agents pass context (task outputs) to downstream agents
- How to validate agent outputs with Instructor structured schemas
- How to trace every agent step in LangSmith for debugging

### Learn Fine-Tuning End-to-End
Projects 22, 25, and 26 include full fine-tuning pipelines:
- Data preparation from raw text to JSONL training format
- LoRA/QLoRA training with Hugging Face PEFT (runs on free Colab T4 GPU)
- OpenAI Fine-tuning API as a no-GPU alternative
- W&B experiment tracking: loss curves, F1, AUC, before/after comparison
- Model deployment to GCP Vertex AI and AWS SageMaker

### Learn Streaming ML Systems
Project 28 introduces streaming system design — one of the most commercially valuable skills:
- Kafka producer/consumer for local development
- AWS Kinesis + Lambda for cloud production
- Sub-200ms inference target with latency measurement
- Streamlit live dashboard for real-time alert visualisation

### Portfolio-Ready
Each project includes clean code, a detailed README with step-by-step implementation guide, architecture diagrams, troubleshooting guides, evaluation rubrics, and interview talking points. These are designed to be demonstrable in a Staff Engineer or Senior AI Engineer technical interview.

---

## How to Get Started

### Prerequisites
- Python 3.10 or higher
- An OpenAI API key
- A Pinecone account (for projects 26, 27, 30) — free tier available
- A W&B account (for projects 22, 25, 27, 28) — free tier available
- A LangSmith account (for all projects) — free tier available
- A GCP account (for projects 22, 23, 26, 29) — free tier with $300 credit
- An AWS account (for projects 21, 25, 27, 28, 30) — free tier available
- An Azure account (for project 24) — free tier available

### Running a Project

```bash
# 1. Clone the repository
git clone https://github.com/KKRGENAI-TRAINING/Level-3-Advanced-AI-Projects.git
cd Level-3-Advanced-AI-Projects

# 2. Navigate to a project
cd project-21-radiology-report-multi-agent-system

# 3. Create and activate a virtual environment
python -m venv venv
source venv/bin/activate    # Mac/Linux
venv\Scripts\activate       # Windows

# 4. Install dependencies
pip install -r requirements.txt

# 5. Configure environment variables
cp .env.example .env
# Open .env and add your API keys

# 6. Run the project (varies — check each project's README)
uvicorn app.api:app --reload --port 8000
```

Each project folder contains its own `README.md` with a full step-by-step implementation guide, explaining every design decision, every code choice, and how to debug common issues.

---

## Repository Structure

```
Level-3-Advanced-AI-Projects/
├── README.md                                              ← You are here
├── project-21-radiology-report-multi-agent-system/
│   ├── README.md
│   ├── app/
│   ├── evaluation/
│   ├── infra/
│   ├── tests/
│   ├── samples/
│   └── requirements.txt
├── project-22-algorithmic-trading-signal-engine/
│   └── ...
├── project-23-autonomous-ecommerce-catalog-manager/
│   └── ...
├── project-24-ai-legal-contract-negotiation-agent/
│   └── ...
├── project-25-talent-intelligence-platform/
│   └── ...
├── project-26-adaptive-learning-os/
│   └── ...
├── project-27-clinical-decision-support-system/
│   └── ...
├── project-28-real-time-fraud-detection-pipeline/
│   └── ...
├── project-29-autonomous-seo-content-pipeline/
│   └── ...
└── project-30-intelligent-customer-onboarding-agent/
    └── ...
```

---

## Technology Stack Overview

| Category | Technologies Used |
|---|---|
| **LLM Providers** | OpenAI GPT-4o, Anthropic Claude, OpenAI Fine-tuning API |
| **Agent Frameworks** | CrewAI, LangGraph (StateGraph) |
| **Fine-tuning** | Hugging Face PEFT (LoRA/QLoRA), OpenAI Fine-tuning API |
| **Vector Databases** | Pinecone (cloud, serverless) |
| **Streaming** | Apache Kafka, AWS Kinesis |
| **Cloud Platforms** | AWS Lambda / SageMaker / Kinesis, GCP Cloud Run / Vertex AI, Azure Container Apps |
| **Observability** | LangSmith (tracing), W&B (experiment tracking) |
| **Validation** | Instructor (structured outputs), Pydantic |
| **Backend Frameworks** | FastAPI + Uvicorn |
| **Frontend** | Next.js (React), Streamlit |
| **Document Generation** | python-docx |
| **External APIs** | Shopify Admin, Twilio SMS, Google Calendar, Serper, Airtable |
| **Databases** | DynamoDB, PostgreSQL / SQLite |
| **Cost Control** | TokenBudget (custom guardrail) |
| **Language** | Python 3.10+, TypeScript |

---

## Recommended Learning Path

| Week | Projects | Focus |
|---|---|---|
| 1–2 | 21, 24, 29 | Multi-agent orchestration with CrewAI |
| 3–4 | 22, 25 | Fine-tuning pipelines + W&B experiment tracking |
| 5–6 | 23, 30 | LangGraph stateful agents with real API integrations |
| 7–8 | 26 | Full-stack AI product (RAG + fine-tuning + Next.js) |
| 9–10 | 27 | Safety-first agent design in regulated domains |
| 11–12 | 28 | Real-time streaming ML system design |

---

## Support

Have questions, facing issues, or want guidance on any of these projects?

**Reach out to the KKRGENAI Support Team** — we're happy to help students at every stage.

- **Support Email:** support@kkrgenai.com
- **Community / Discussion:** Open an issue in this repository with your question

Whether you're stuck on GPU setup for LoRA fine-tuning, confused about CrewAI task handoffs, or debugging a Kinesis Lambda handler — don't hesitate to reach out. We're here to support your growth.

---

## License

These projects are provided for educational purposes. Please refer to individual project folders for any specific licensing notes.

---

*Built with care by the KKRGENAI team — empowering the next generation of AI builders, one project at a time.*
