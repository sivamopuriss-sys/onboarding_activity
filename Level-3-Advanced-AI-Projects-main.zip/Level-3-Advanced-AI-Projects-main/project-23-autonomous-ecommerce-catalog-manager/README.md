# Project 23 — Autonomous E-commerce Catalog Manager

![Level](https://img.shields.io/badge/Level-Advanced-purple)
![Industry](https://img.shields.io/badge/Industry-E--commerce-teal)
![Stack](https://img.shields.io/badge/Stack-LangGraph%20%7C%20MCP%20%7C%20Shopify%20API%20%7C%20GCP%20Cloud%20Run-blue)

## Business Problem
E-commerce catalog managers spend hours daily monitoring competitor prices, rewriting
underperforming listings, updating stock levels, and triggering promotions. An autonomous
agent with access to the right tools can run this workflow continuously — reacting to
market changes in near real-time without human intervention.

## Project Objective
Build a LangGraph agent with 4 real tools:
1. **Price Scraper tool** — checks competitor prices for a given product
2. **Listing Rewriter tool** — rewrites a product description to improve conversion
3. **Inventory Updater tool** — updates stock level via Shopify Admin API
4. **Promotion Trigger tool** — creates/activates a Shopify discount code

MCP (Model Context Protocol) configures tool access. Agent deployed on GCP Cloud Run
with a webhook trigger. All runs traced in LangSmith.

## System Architecture
```mermaid
graph TD
    A[Webhook trigger / Schedule] --> B[FastAPI endpoint]
    B --> C[LangGraph Agent]
    C --> D[Tool: Price Scraper]
    C --> E[Tool: Listing Rewriter]
    C --> F[Tool: Inventory Updater]
    C --> G[Tool: Promotion Trigger]
    D --> H{Price gap > 10%?}
    H -- Yes --> E
    E --> F
    F --> G
    C --> I[LangSmith - trace all tool calls]
    C --> J[TokenBudget - cost guard]
    B --> K[GCP Cloud Run]
```

## Folder Structure
```
project-23-autonomous-ecommerce-catalog-manager/
├── app/
│   ├── agent.py            # LangGraph agent + tool definitions
│   ├── tools.py            # 4 tool implementations
│   ├── shopify_client.py   # Shopify Admin API wrapper
│   └── api.py              # FastAPI webhook handler
├── utils/
│   └── cost_tracker.py
├── evaluation/
│   └── langsmith_eval.py
├── infra/
│   ├── Dockerfile
│   ├── cloudbuild.yaml
│   └── service.yaml
├── tests/
│   └── test_tools.py
├── samples/
│   └── sample_products.json
├── langsmith_config.py
├── mcp_config.json         # MCP server configuration
├── .github/workflows/deploy.yml
├── .env.example
├── requirements.txt
└── README.md
```

## Setup
```bash
pip install -r requirements.txt
cp .env.example .env
uvicorn app.api:app --reload

# Deploy to GCP
gcloud builds submit --config infra/cloudbuild.yaml
```

## Observability
- LangSmith traces every tool call and agent decision
- TokenBudget: 60K token max per catalog run (~$0.45)
- View all runs at smith.langchain.com

## Key Concepts
- LangGraph ReAct agent with custom tools
- MCP (Model Context Protocol) for tool configuration
- Shopify Admin API (products, inventory, discounts)
- Conditional tool routing based on data signals
- Webhook-triggered autonomous workflow

## Time Estimate
| Mode | Time |
|---|---|
| Self-paced | 18–24 hours |
| Instructor-guided | 10–14 hours |

---

## Step-by-Step Implementation Guide

This guide walks you through building this project from scratch. Follow each step in order.

---

### Step 1: Project Setup

```bash
mkdir project-23-autonomous-ecommerce-catalog-manager
cd project-23-autonomous-ecommerce-catalog-manager
python -m venv venv && source venv/bin/activate
mkdir -p app utils evaluation infra tests samples
touch app/agent.py app/tools.py app/shopify_client.py app/api.py
touch utils/cost_tracker.py langsmith_config.py mcp_config.json
touch requirements.txt .env.example
```

`requirements.txt`:
```
langgraph>=0.1.0
langchain>=0.2.0
langchain-openai>=0.1.0
langsmith>=0.1.0
openai>=1.30.0
fastapi>=0.110.0
uvicorn>=0.29.0
pydantic>=2.0.0
requests>=2.31.0
python-dotenv>=1.0.0
tiktoken>=0.7.0
pytest>=8.0.0
```

`.env.example`:
```
OPENAI_API_KEY=sk-your-key
SHOPIFY_STORE_URL=https://your-store.myshopify.com
SHOPIFY_ACCESS_TOKEN=shpat_your-token
LANGCHAIN_TRACING_V2=true
LANGCHAIN_API_KEY=ls__your-key
LANGCHAIN_PROJECT=project-23-catalog-manager
TOKEN_BUDGET=60000
```

---

### Step 2: Understand the LangGraph ReAct Architecture

ReAct (Reason + Act) is a prompting strategy where the agent alternates between:
- **Thought:** "The price is 15% above competitors — I should trigger a promotion"
- **Action:** calls `trigger_promotion(product_id="P001", discount_pct=10, reason="price gap")`
- **Observation:** reads the tool return value
- **Thought:** "Promotion created. Now I should rewrite the listing..."

This continues until the agent decides the task is complete. LangGraph's `create_react_agent` implements this loop as a compiled state graph — each node is either the LLM (reasoning) or a tool call (acting).

**Why ReAct over a fixed pipeline?** A fixed pipeline would need you to hardcode: "always scrape, always rewrite, always update inventory." ReAct lets the agent decide which tools to use based on what it observes — if the price is already competitive, it skips the promotion tool. This conditional reasoning is what makes it "autonomous."

---

### Step 3: Build the Shopify Client (`app/shopify_client.py`)

```python
"""shopify_client.py — Shopify Admin API wrapper"""
import os, requests
from dotenv import load_dotenv
load_dotenv()

BASE_URL = os.getenv("SHOPIFY_STORE_URL", "").rstrip("/")
HEADERS  = {
    "X-Shopify-Access-Token": os.getenv("SHOPIFY_ACCESS_TOKEN", ""),
    "Content-Type": "application/json",
}


def get_product(product_id: str) -> dict:
    """Fetch product details from Shopify."""
    resp = requests.get(f"{BASE_URL}/admin/api/2024-01/products/{product_id}.json",
                        headers=HEADERS, timeout=10)
    resp.raise_for_status()
    return resp.json()["product"]


def update_product_description(product_id: str, new_body_html: str) -> dict:
    """Update a product's description in Shopify."""
    resp = requests.put(
        f"{BASE_URL}/admin/api/2024-01/products/{product_id}.json",
        headers=HEADERS,
        json={"product": {"id": product_id, "body_html": new_body_html}},
        timeout=10,
    )
    resp.raise_for_status()
    return {"success": True, "updated_id": product_id}


def update_inventory(inventory_item_id: str, location_id: str, quantity: int) -> dict:
    """Set inventory level for a product variant at a location."""
    resp = requests.post(
        f"{BASE_URL}/admin/api/2024-01/inventory_levels/set.json",
        headers=HEADERS,
        json={"inventory_item_id": inventory_item_id,
              "location_id": location_id,
              "available": quantity},
        timeout=10,
    )
    resp.raise_for_status()
    return {"success": True}


def create_discount(title: str, percentage: float, product_id: str) -> dict:
    """Create a percentage discount code for a specific product."""
    resp = requests.post(
        f"{BASE_URL}/admin/api/2024-01/price_rules.json",
        headers=HEADERS,
        json={"price_rule": {
            "title": title,
            "target_type": "line_item",
            "target_selection": "entitled",
            "allocation_method": "across",
            "value_type": "percentage",
            "value": f"-{percentage}",
            "customer_selection": "all",
            "entitled_product_ids": [int(product_id)],
            "starts_at": "2024-01-01T00:00:00Z",
        }},
        timeout=10,
    )
    if resp.status_code == 201:
        rule_id = resp.json()["price_rule"]["id"]
        # Create the actual discount code
        code_resp = requests.post(
            f"{BASE_URL}/admin/api/2024-01/price_rules/{rule_id}/discount_codes.json",
            headers=HEADERS,
            json={"discount_code": {"code": title}},
            timeout=10,
        )
        code_resp.raise_for_status()
        return {"success": True, "discount_code": title, "rule_id": rule_id}
    return {"success": False, "error": resp.text}
```

**Why wrap Shopify in its own client module?** The tools in `tools.py` should contain business logic (when to trigger a promotion) not HTTP implementation details (how to authenticate with Shopify). Separating them means you can mock `shopify_client` in tests without making real API calls, and you can swap to a different e-commerce platform by replacing only this file.

**Why Shopify Admin API 2024-01?** Shopify versions their API by date. Using a pinned version prevents your integration from breaking when Shopify releases changes. Check for deprecation notices quarterly and update the version string.

---

### Step 4: Implement the 4 Tools (`app/tools.py`)

```python
"""tools.py — 4 LangGraph tool implementations"""
import json, os
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from shopify_client import (get_product, update_product_description,
                             update_inventory, create_discount)

llm = ChatOpenAI(model="gpt-4o", temperature=0.3)


@tool
def scrape_competitor_price(product_name: str, our_price: float) -> str:
    """Scrape competitor prices for a product and return a price comparison JSON."""
    import random
    competitor_prices = {
        "amazon":  round(our_price * random.uniform(0.85, 1.15), 2),
        "ebay":    round(our_price * random.uniform(0.80, 1.20), 2),
        "walmart": round(our_price * random.uniform(0.90, 1.10), 2),
    }
    avg_competitor = sum(competitor_prices.values()) / len(competitor_prices)
    price_gap_pct  = ((our_price - avg_competitor) / avg_competitor) * 100
    return json.dumps({
        "product":              product_name,
        "our_price":            our_price,
        "competitor_prices":    competitor_prices,
        "avg_competitor_price": round(avg_competitor, 2),
        "price_gap_pct":        round(price_gap_pct, 1),
        "recommendation":       "reduce_price" if price_gap_pct > 10 else "maintain",
    })


@tool
def rewrite_product_listing(product_id: str, product_title: str,
                             current_description: str, improvement_focus: str) -> str:
    """Rewrite a product listing description to improve SEO and conversion rate."""
    prompt = (f"Rewrite this product description to improve {improvement_focus}.\n"
              f"Product: {product_title}\n"
              f"Current: {current_description}\n"
              "Focus on: benefits over features, social proof cues, clear CTA.\n"
              "Return ONLY the new description. Max 300 words.")
    resp = llm.invoke(prompt)
    result = update_product_description(product_id, resp.content)
    return json.dumps({
        "product_id": product_id,
        "updated":    result["success"],
        "preview":    resp.content[:200] + "...",
    })


@tool
def update_inventory_level(product_id: str, inventory_item_id: str,
                            location_id: str, new_quantity: int) -> str:
    """Update the inventory level for a product variant in Shopify."""
    result = update_inventory(inventory_item_id, location_id, new_quantity)
    return json.dumps({"product_id": product_id,
                       "updated": result["success"],
                       "new_quantity": new_quantity})


@tool
def trigger_promotion(product_id: str, discount_pct: float, reason: str) -> str:
    """Create and activate a promotional discount for a product."""
    title  = f"PROMO-{product_id[:8].upper()}"
    result = create_discount(title, discount_pct, product_id)
    return json.dumps({"discount_created": result["success"],
                       "discount_code":   result.get("discount_code"),
                       "discount_pct":    discount_pct,
                       "reason":          reason})
```

**Why return JSON strings from tools?** LangGraph tools must return strings (the agent reads them as observation text). Returning structured JSON makes it easy for the LLM to extract specific values ("the price gap is 15.3%") without parsing free-form prose. JSON is also more reliable than plain text for downstream tool calls that depend on the observation.

**Why use the `@tool` decorator?** LangChain's `@tool` decorator creates a `BaseTool` with a name, description (from the docstring), and input schema (from the type hints). The ReAct agent uses the description to decide when to use which tool — the docstring is effectively the tool's specification. Write it clearly because the LLM reads it.

---

### Step 5: Build the LangGraph Agent (`app/agent.py`)

```python
"""agent.py — LangGraph ReAct catalog manager agent"""
import os
from langgraph.prebuilt import create_react_agent
from langchain_openai import ChatOpenAI
from langsmith_config import setup_langsmith
from utils.cost_tracker import TokenBudget, BudgetExceededError
from tools import (scrape_competitor_price, rewrite_product_listing,
                   update_inventory_level, trigger_promotion)
from dotenv import load_dotenv

load_dotenv()
setup_langsmith("project-23-catalog-manager")

llm   = ChatOpenAI(model="gpt-4o", temperature=0.2)
tools = [scrape_competitor_price, rewrite_product_listing,
         update_inventory_level, trigger_promotion]
agent = create_react_agent(llm, tools)


def run_catalog_agent(products: list[dict]) -> dict:
    budget  = TokenBudget(max_tokens=int(os.getenv("TOKEN_BUDGET", 60_000)), model="gpt-4o")
    results = []

    for product in products:
        prompt = f"""You are an autonomous e-commerce catalog manager.
Analyse and optimise this product:

Product ID: {product['id']}
Title: {product['title']}
Current Price: ${product['price']}
Description: {product['description'][:300]}
Inventory: {product['inventory_quantity']} units

Your tasks:
1. Use scrape_competitor_price to check competitiveness
2. If price gap > 10% above competitors: use trigger_promotion (10% off)
3. Use rewrite_product_listing to improve the description
4. If inventory < 10 units: use update_inventory_level to flag for restock

Take all relevant actions. Report what you did and why."""

        try:
            with budget:
                result = agent.invoke({"messages": [{"role":"user","content":prompt}]})
            results.append({
                "product_id":    product["id"],
                "status":        "completed",
                "actions_taken": str(result["messages"][-1].content)[:500],
            })
        except BudgetExceededError as e:
            results.append({"product_id": product["id"], "status": "budget_exceeded"})
            break

    return {"results": results, "token_summary": budget.summary()}
```

**Why `temperature=0.2`?** The agent makes decisions about whether to call tools and which ones. A temperature near 0 makes it deterministic but potentially overly conservative (it might always follow the exact same decision tree). 0.2 allows slight variation in tool-selection reasoning while keeping decisions consistent and sensible.

---

### Step 6: Configure MCP (`mcp_config.json`)

```json
{
  "mcpServers": {
    "catalog-tools": {
      "command": "python",
      "args": ["app/tools.py"],
      "env": {
        "SHOPIFY_STORE_URL": "${SHOPIFY_STORE_URL}",
        "SHOPIFY_ACCESS_TOKEN": "${SHOPIFY_ACCESS_TOKEN}"
      },
      "tools": [
        "scrape_competitor_price",
        "rewrite_product_listing",
        "update_inventory_level",
        "trigger_promotion"
      ]
    }
  }
}
```

**What is MCP?** Model Context Protocol is an open standard for connecting LLMs to external tools and data sources. Instead of hardcoding tools directly in your agent, MCP externalises tool configuration — you can add, remove, or reconfigure tools by editing a JSON file without modifying agent code. It also enables tool access control: you can specify which tools are available to which agents.

---

### Step 7: Build the Webhook Handler (`app/api.py`)

```python
"""api.py — FastAPI webhook handler"""
from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from agent import run_catalog_agent
import uuid, os

app = FastAPI(title="Autonomous E-commerce Catalog Manager")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

job_store: dict = {}  # In production: use Redis or DynamoDB


class CatalogRunRequest(BaseModel):
    products: list[dict]
    dry_run:  bool = False


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/run-catalog-agent")
def run_agent(req: CatalogRunRequest, background_tasks: BackgroundTasks):
    """Trigger the catalog agent for a list of products."""
    job_id = str(uuid.uuid4())
    job_store[job_id] = {"status": "running", "result": None}

    def _run():
        result = run_catalog_agent(req.products)
        job_store[job_id] = {"status": "completed", "result": result}

    background_tasks.add_task(_run)
    return {"job_id": job_id, "status": "queued"}


@app.get("/job/{job_id}")
def get_job(job_id: str):
    job = job_store.get(job_id)
    if not job:
        raise HTTPException(404, "Job not found")
    return job
```

**Why background tasks?** A catalog agent run over 10 products can take 2–5 minutes (each product triggers multiple LLM calls). HTTP clients timeout after 30–60 seconds. A background task pattern: accept the request immediately, return a job ID, run the agent asynchronously, and allow the client to poll `/job/{job_id}` for the result.

---

### Step 8: Run and Test Locally

```bash
uvicorn app.api:app --reload --port 8000

# Trigger a catalog run with sample products
curl -X POST http://localhost:8000/run-catalog-agent \
  -H "Content-Type: application/json" \
  -d @samples/sample_products.json

# Check job status
curl http://localhost:8000/job/YOUR_JOB_ID
```

Check LangSmith at smith.langchain.com — you'll see a trace for each product run showing the ReAct loop: which tools the agent called, in what order, and why.

---

### Step 9: Deploy to GCP Cloud Run

```bash
gcloud builds submit --config infra/cloudbuild.yaml
gcloud run deploy catalog-manager \
  --region us-central1 \
  --min-instances 1 \
  --memory 1Gi \
  --set-env-vars "SHOPIFY_STORE_URL=https://...,TOKEN_BUDGET=60000"
```

**Why `min-instances=1`?** Catalog runs are triggered by webhooks from Shopify. A cold start (0 instances → 1) adds 3–8 seconds to the first request, which can cause Shopify's webhook to timeout and retry. Keeping one warm instance eliminates this.

---

### Step 10: Troubleshooting

| Error | Cause | Fix |
|---|---|---|
| `shopify_client.py: 401 Unauthorized` | Invalid Shopify access token | Regenerate token in Shopify Admin → Apps → API credentials |
| `shopify_client.py: 429 Too Many Requests` | Shopify rate limit (40 req/app/sec) | Add `time.sleep(0.5)` between tool calls |
| Agent runs same tool in an infinite loop | No stopping condition in the prompt | Add "Once you have taken all relevant actions, say DONE." to the prompt |
| `BudgetExceededError` on 5+ products | Each product uses ~8K tokens, 5 products = 40K | Increase `TOKEN_BUDGET` or process products in smaller batches |
| LangSmith shows no traces | `setup_langsmith()` not called before agent creation | Call it at module import time, before `create_react_agent` |
| GCP Cloud Run build fails | Missing system deps for some packages | Add `RUN apt-get install -y build-essential` to Dockerfile |

---

## Evaluation Rubric

| Criteria | Meets | Exceeds |
|---|---|---|
| **Agent Functionality** | All 4 tools implemented and callable | Agent correctly skips unnecessary tools based on observed data |
| **Shopify Integration** | Mock Shopify client returns expected format | Real Shopify API calls working in a dev store |
| **Observability** | LangSmith traces showing tool call sequence | Token usage per product tracked; cost per catalog run logged |
| **Cost Control** | TokenBudget set | Budget enforced mid-run; partial results returned on budget exceeded |
| **Architecture** | Tools separated from agent logic | MCP config externalises tool definitions; shopify_client mockable in tests |

---

## Interview Talking Points

1. **What is the ReAct pattern?** — Reason + Act: the agent alternates between generating a thought (reasoning about what to do next) and executing an action (calling a tool). This allows multi-step decision making where later steps depend on earlier observations — unlike a fixed pipeline where every step runs regardless.

2. **How would you prevent the agent from making destructive Shopify changes?** — Add a `dry_run` mode (flag in the API request) where tool calls log their intended actions but don't execute the real API call. Implement tool-level validation (e.g., `trigger_promotion` validates discount < 50%). Add a human-approval step for promotions over a certain discount threshold.

3. **Why MCP for tool configuration?** — MCP separates tool definitions from agent code, making it easier to add/remove tools, control which agents have access to which tools, and version the tool interface independently. It's becoming the standard for enterprise LLM deployments.

4. **How would you scale this to 10,000 products?** — Replace the sequential loop with a Pub/Sub queue (GCP Pub/Sub or AWS SQS): each product becomes a message, multiple Cloud Run instances consume in parallel, results are written to a database. The current synchronous API would become a trigger that enqueues work.

5. **What monitoring would you add in production?** — Per-product latency and token usage in Cloud Monitoring, discount activation rate vs revenue impact in Looker, agent success/failure rates in LangSmith, Shopify webhook delivery rate in Shopify Admin.

---

## Bonus Extensions

- **Real competitor price scraping:** Replace the mock price data with Playwright-based scraping of Amazon/eBay product pages for actual competitor prices.
- **Image optimization tool:** Add a 5th tool that uses GPT-4o Vision to review product images and suggest improvements (background, lighting, angle).
- **Scheduled runs:** Add a Cloud Scheduler job that triggers the catalog agent every night at 2am, processing the 100 lowest-performing products.
- **Slack notifications:** After each catalog run, post a summary to Slack: products optimised, discounts created, estimated revenue impact.

