"""test_tools.py — tests for tool logic (no API calls)"""
import json

def test_price_gap_logic():
    our_price = 100.0
    avg_competitor = 85.0
    gap_pct = ((our_price - avg_competitor) / avg_competitor) * 100
    assert gap_pct > 10
    assert gap_pct == pytest.approx(17.6, rel=0.01)

def test_discount_creation_mock():
    result = {"success": True, "discount_code": "PROMO-PROD001-DEMO"}
    assert result["success"]
    assert "PROMO" in result["discount_code"]

try:
    import pytest
except ImportError:
    pass
