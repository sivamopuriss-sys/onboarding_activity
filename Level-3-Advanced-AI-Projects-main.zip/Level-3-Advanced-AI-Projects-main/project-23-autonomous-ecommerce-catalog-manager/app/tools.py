"""tools.py — 4 LangGraph tool implementations"""
import json, os, requests
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from shopify_client import get_product, update_product_description, update_inventory, create_discount

llm = ChatOpenAI(model="gpt-4o", temperature=0.3)


@tool
def scrape_competitor_price(product_name: str, our_price: float) -> str:
    """
    Scrape competitor prices for a product and return price comparison.
    In production: use Playwright or a price API. Demo uses mock data.
    """
    # Demo implementation — replace with real scraping in production
    import random
    competitor_prices = {
        "amazon":  round(our_price * random.uniform(0.85, 1.15), 2),
        "ebay":    round(our_price * random.uniform(0.80, 1.20), 2),
        "walmart": round(our_price * random.uniform(0.90, 1.10), 2),
    }
    avg_competitor = sum(competitor_prices.values()) / len(competitor_prices)
    price_gap_pct  = ((our_price - avg_competitor) / avg_competitor) * 100

    return json.dumps({
        "product": product_name,
        "our_price": our_price,
        "competitor_prices": competitor_prices,
        "avg_competitor_price": round(avg_competitor, 2),
        "price_gap_pct": round(price_gap_pct, 1),
        "recommendation": "reduce_price" if price_gap_pct > 10 else "maintain",
    })


@tool
def rewrite_product_listing(product_id: str, product_title: str,
                             current_description: str, improvement_focus: str) -> str:
    """
    Rewrite a product listing description to improve SEO and conversion rate.
    improvement_focus: 'seo' | 'conversion' | 'price_value'
    """
    prompt = f"""Rewrite this product description to improve {improvement_focus}.
Product: {product_title}
Current: {current_description}
Focus on: benefits over features, social proof cues, clear CTA.
Return ONLY the new HTML description (no markdown, no explanation). Max 300 words."""

    resp = llm.invoke(prompt)
    new_description = resp.content

    # Update in Shopify
    result = update_product_description(product_id, new_description)
    return json.dumps({
        "product_id": product_id,
        "updated": result["success"],
        "new_description_preview": new_description[:200] + "...",
    })


@tool
def update_inventory_level(product_id: str, inventory_item_id: str,
                            location_id: str, new_quantity: int) -> str:
    """Update the inventory level for a product variant in Shopify."""
    result = update_inventory(inventory_item_id, location_id, new_quantity)
    return json.dumps({
        "product_id": product_id,
        "updated": result["success"],
        "new_quantity": new_quantity,
    })


@tool
def trigger_promotion(product_id: str, discount_pct: float, reason: str) -> str:
    """
    Create and activate a promotional discount for a product.
    Use when price is above competitors by more than 10%.
    """
    title  = f"PROMO-{product_id[:8].upper()}"
    result = create_discount(title, discount_pct, product_id)
    return json.dumps({
        "discount_created": result["success"],
        "discount_code": result["discount_code"],
        "discount_pct": discount_pct,
        "reason": reason,
    })
