"""shopify_client.py — Shopify Admin API wrapper"""
import os, requests
from dotenv import load_dotenv
load_dotenv()

STORE_URL = os.getenv("SHOPIFY_STORE_URL","https://demo.myshopify.com")
TOKEN     = os.getenv("SHOPIFY_ACCESS_TOKEN","demo-token")
HEADERS   = {"X-Shopify-Access-Token": TOKEN, "Content-Type": "application/json"}


def get_product(product_id: str) -> dict:
    """Fetch product details from Shopify."""
    url = f"{STORE_URL}/admin/api/2024-01/products/{product_id}.json"
    resp = requests.get(url, headers=HEADERS, timeout=10)
    if resp.status_code == 200:
        return resp.json().get("product", {})
    return {"error": resp.status_code, "demo": True,
            "title":"Demo Product","body_html":"<p>Demo description</p>",
            "variants":[{"inventory_quantity":50,"price":"29.99"}]}


def update_product_description(product_id: str, new_description: str) -> dict:
    """Update product description (body_html) in Shopify."""
    url  = f"{STORE_URL}/admin/api/2024-01/products/{product_id}.json"
    data = {"product": {"id": product_id, "body_html": new_description}}
    resp = requests.put(url, json=data, headers=HEADERS, timeout=10)
    return {"success": resp.status_code == 200, "demo": TOKEN == "demo-token"}


def update_inventory(inventory_item_id: str, location_id: str, quantity: int) -> dict:
    """Update inventory level for a product variant."""
    url  = f"{STORE_URL}/admin/api/2024-01/inventory_levels/set.json"
    data = {"location_id": location_id, "inventory_item_id": inventory_item_id,
            "available": quantity}
    resp = requests.post(url, json=data, headers=HEADERS, timeout=10)
    return {"success": resp.status_code == 200, "new_quantity": quantity}


def create_discount(title: str, pct_off: float, product_id: str = None) -> dict:
    """Create a percentage discount code in Shopify."""
    url  = f"{STORE_URL}/admin/api/2024-01/price_rules.json"
    data = {
        "price_rule": {
            "title": title, "value_type": "percentage",
            "value": f"-{pct_off}", "customer_selection": "all",
            "target_type": "line_item", "target_selection": "all",
            "allocation_method": "across", "starts_at": "2024-01-01T00:00:00Z"
        }
    }
    resp = requests.post(url, json=data, headers=HEADERS, timeout=10)
    return {"success": resp.status_code == 201, "discount_code": f"{title}-DEMO"}
