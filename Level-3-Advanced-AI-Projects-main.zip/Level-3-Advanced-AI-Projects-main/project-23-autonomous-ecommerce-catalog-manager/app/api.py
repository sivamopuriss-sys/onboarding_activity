"""api.py — FastAPI webhook handler"""
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from agent import run_catalog_agent

app = FastAPI(title="Autonomous Catalog Manager")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

class CatalogRequest(BaseModel):
    products: list[dict]

@app.get("/health")
def health(): return {"status":"ok"}

@app.post("/run-catalog-agent")
def run_agent(req: CatalogRequest):
    if not req.products:
        raise HTTPException(422, "At least one product required.")
    return run_catalog_agent(req.products)
