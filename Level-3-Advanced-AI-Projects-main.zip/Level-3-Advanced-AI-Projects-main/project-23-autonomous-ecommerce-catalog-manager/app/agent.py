"""agent.py — LangGraph ReAct catalog manager agent"""
import os
from langgraph.prebuilt import create_react_agent
from langchain_openai import ChatOpenAI
from langsmith_config import setup_langsmith
from utils.cost_tracker import TokenBudget, BudgetExceededError
from tools import scrape_competitor_price, rewrite_product_listing, update_inventory_level, trigger_promotion
from dotenv import load_dotenv

load_dotenv()
setup_langsmith("project-23-catalog-manager")

llm   = ChatOpenAI(model="gpt-4o", temperature=0.2)
tools = [scrape_competitor_price, rewrite_product_listing, update_inventory_level, trigger_promotion]
agent = create_react_agent(llm, tools)


def run_catalog_agent(products: list[dict]) -> dict:
    """
    Run the catalog manager agent over a list of products.
    Each product: {id, title, price, description, inventory_quantity}
    """
    budget  = TokenBudget(max_tokens=int(os.getenv("TOKEN_BUDGET",60_000)), model="gpt-4o")
    results = []

    for product in products:
        prompt = f"""You are an autonomous e-commerce catalog manager.
Analyse and optimise the following product:

Product ID: {product['id']}
Title: {product['title']}
Current Price: ${product['price']}
Current Description: {product['description'][:300]}
Inventory: {product['inventory_quantity']} units

Your tasks:
1. Use scrape_competitor_price to check if our price is competitive
2. If price gap > 10% above competitors: use trigger_promotion (10% off)
3. Use rewrite_product_listing to improve the description (focus: conversion)
4. If inventory < 10 units: use update_inventory_level to flag for restock

Be decisive. Take all relevant actions. Report what you did and why."""

        try:
            with budget:
                result = agent.invoke({"messages": [{"role":"user","content":prompt}]})
            results.append({
                "product_id": product["id"],
                "status": "completed",
                "actions_taken": str(result["messages"][-1].content)[:500],
            })
        except BudgetExceededError as e:
            results.append({"product_id": product["id"], "status": "budget_exceeded", "error": str(e)})
            break

    return {"results": results, "token_summary": budget.summary()}
