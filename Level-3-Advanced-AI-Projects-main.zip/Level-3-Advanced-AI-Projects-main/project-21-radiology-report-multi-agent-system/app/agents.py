"""agents.py — CrewAI agent definitions"""
import os
from crewai import Agent
from langchain_openai import ChatOpenAI

llm = ChatOpenAI(model="gpt-4o", temperature=0.1, api_key=os.getenv("OPENAI_API_KEY"))


def build_agents():
    dicom_analyst = Agent(
        role="DICOM Metadata Analyst",
        goal="Extract and interpret all relevant clinical parameters from DICOM metadata",
        backstory=(
            "You are a radiological physicist with 15 years of experience interpreting "
            "medical imaging metadata. You extract patient demographics, scan modality, "
            "acquisition parameters, and any technical quality flags from DICOM data."
        ),
        llm=llm,
        verbose=True,
        allow_delegation=False,
        max_iter=3,
    )

    report_drafter = Agent(
        role="Radiology Report Drafter",
        goal="Generate a structured, clinically accurate radiology report from scan analysis",
        backstory=(
            "You are a board-certified radiologist who writes clear, structured reports "
            "following ACR (American College of Radiology) guidelines. Your reports always "
            "include: Technique, Clinical Indication, Findings, Impression, and Recommendations."
        ),
        llm=llm,
        verbose=True,
        allow_delegation=False,
        max_iter=3,
    )

    anomaly_flagger = Agent(
        role="Critical Finding Reviewer",
        goal="Review radiology reports for critical findings requiring urgent clinical action",
        backstory=(
            "You are a senior radiologist specialising in critical finding communication. "
            "You identify ACR critical findings (pneumothorax, aortic dissection, PE, "
            "intracranial haemorrhage, etc.) and determine urgency level."
        ),
        llm=llm,
        verbose=True,
        allow_delegation=False,
        max_iter=2,
    )

    return dicom_analyst, report_drafter, anomaly_flagger
