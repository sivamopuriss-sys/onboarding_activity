"""crew.py — Crew orchestration with cost tracking"""
import os
from crewai import Crew, Process
from langsmith_config import setup_langsmith
from agents import build_agents
from tasks import build_tasks
from utils.cost_tracker import TokenBudget, BudgetExceededError

setup_langsmith("project-21-radiology-multi-agent")


def run_radiology_crew(dicom_data: dict) -> dict:
    """Run the 3-agent radiology crew on DICOM metadata."""
    budget = TokenBudget(
        max_tokens=int(os.getenv("TOKEN_BUDGET", 80_000)),
        model="gpt-4o"
    )

    dicom_analyst, report_drafter, anomaly_flagger = build_agents()
    task1, task2, task3 = build_tasks(dicom_analyst, report_drafter, anomaly_flagger, dicom_data)

    crew = Crew(
        agents=[dicom_analyst, report_drafter, anomaly_flagger],
        tasks=[task1, task2, task3],
        process=Process.sequential,
        verbose=True,
    )

    try:
        with budget:
            result = crew.kickoff()
    except BudgetExceededError as e:
        return {"error": str(e), "partial_result": str(result)}

    return {
        "report":       str(result),
        "token_summary": budget.summary(),
        "estimated_cost": budget.estimated_cost(),
    }
