"""tasks.py — Task definitions with Instructor-validated outputs"""
import instructor
import openai
from crewai import Task
from pydantic import BaseModel
from typing import Optional, Literal

# Patch OpenAI client with Instructor for structured output validation
client = instructor.patch(openai.OpenAI())


class DicomAnalysis(BaseModel):
    patient_id: str
    modality: str
    body_part: str
    acquisition_date: str
    scan_quality: Literal["good", "acceptable", "poor"]
    clinical_indication: str
    technical_notes: Optional[str] = None


class RadiologyReport(BaseModel):
    technique: str
    clinical_indication: str
    findings: str
    impression: str
    recommendations: str
    report_quality: Literal["complete", "needs_review"]


class AnomalyReview(BaseModel):
    has_critical_finding: bool
    urgency: Literal["routine", "urgent", "emergent"]
    critical_findings: list[str]
    routing: Literal["standard", "urgent_review", "immediate_escalation"]
    reviewer_notes: str


def build_tasks(dicom_analyst, report_drafter, anomaly_flagger, dicom_data: dict):
    task1 = Task(
        description=f"""Analyse the following DICOM metadata and extract all clinically
relevant parameters. Return a structured analysis.

DICOM Data: {dicom_data}

Focus on: modality, body part examined, scan quality, clinical indication,
and any technical parameters that affect diagnostic interpretation.""",
        agent=dicom_analyst,
        expected_output="Structured DICOM analysis with all clinical parameters extracted",
    )

    task2 = Task(
        description="""Using the DICOM analysis from Task 1, generate a complete structured
radiology report following ACR guidelines. The report must include all five sections:
Technique, Clinical Indication, Findings, Impression, and Recommendations.
Be specific, clinical, and precise. Do not speculate beyond what the data supports.""",
        agent=report_drafter,
        expected_output="Complete structured radiology report in ACR format",
        context=[task1],
    )

    task3 = Task(
        description="""Review the radiology report from Task 2 for critical findings.
Identify any findings that require urgent or emergent clinical communication per ACR criteria.
Critical findings include: tension pneumothorax, aortic dissection, massive PE,
intracranial haemorrhage, cord compression, critical lab values embedded in clinical notes.
Determine the urgency level and appropriate routing.""",
        agent=anomaly_flagger,
        expected_output="Anomaly review with urgency classification and routing decision",
        context=[task1, task2],
    )

    return task1, task2, task3
