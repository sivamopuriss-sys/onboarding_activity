"""api.py — FastAPI endpoint"""
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from crew import run_radiology_crew

app = FastAPI(title="Radiology Report Multi-Agent System")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

class DicomRequest(BaseModel):
    patient_id: str
    modality: str
    body_part: str
    acquisition_date: str
    clinical_indication: str
    scan_findings: str
    additional_metadata: dict = {}

@app.get("/health")
def health(): return {"status": "ok"}

@app.post("/generate-report")
def generate_report(req: DicomRequest):
    try:
        result = run_radiology_crew(req.model_dump())
        return result
    except Exception as e:
        raise HTTPException(500, str(e))
