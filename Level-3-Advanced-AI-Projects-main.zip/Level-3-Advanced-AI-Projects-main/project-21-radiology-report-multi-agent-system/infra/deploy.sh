#!/bin/bash
set -e
echo "Building Docker image..."
docker build -t radiology-agent .

echo "Pushing to ECR..."
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin $AWS_ACCOUNT_ID.dkr.ecr.us-east-1.amazonaws.com
docker tag radiology-agent:latest $AWS_ACCOUNT_ID.dkr.ecr.us-east-1.amazonaws.com/radiology-agent:latest
docker push $AWS_ACCOUNT_ID.dkr.ecr.us-east-1.amazonaws.com/radiology-agent:latest

echo "Deploying with SAM..."
sam build && sam deploy --no-confirm-changeset
echo "Deployment complete."
