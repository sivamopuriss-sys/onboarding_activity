# Project 21 — Radiology Report Multi-Agent System

![Level](https://img.shields.io/badge/Level-Advanced-purple)
![Industry](https://img.shields.io/badge/Industry-Healthcare-red)
![Stack](https://img.shields.io/badge/Stack-CrewAI%20%7C%20GPT--4o%20%7C%20AWS%20Lambda%20%7C%20LangSmith-blue)

## Business Problem
Radiologists are in short supply globally. Writing structured radiology reports from DICOM
metadata and scan findings is time-consuming and cognitively demanding. A multi-agent system
where specialised agents handle metadata extraction, report drafting, and anomaly flagging
can reduce reporting time by 40-60% while maintaining a mandatory human review step.

## Project Objective
Build a CrewAI 3-agent pipeline:
- **Agent 1 — DICOM Analyst:** reads DICOM metadata (patient info, scan type, modality, acquisition params)
- **Agent 2 — Report Drafter:** generates a structured radiology report (findings, impression, recommendations)
- **Agent 3 — Anomaly Flagger:** reviews the draft, flags critical findings, routes to human if urgent

Deployed as AWS Lambda. All agent runs traced in LangSmith.

## System Architecture
```mermaid
graph TD
    A[DICOM metadata JSON input] --> B[FastAPI trigger]
    B --> C[CrewAI Crew - 3 agents]
    C --> D[Agent 1: DICOM Analyst]
    D --> E[Agent 2: Report Drafter]
    E --> F[Agent 3: Anomaly Flagger]
    F --> G{Critical finding?}
    G -- Yes --> H[Route to urgent review queue]
    G -- No --> I[Return structured report]
    C --> J[LangSmith - trace all agent steps]
    B --> K[AWS Lambda - serverless deployment]
```

## Folder Structure
```
project-21-radiology-report-multi-agent-system/
├── app/
│   ├── agents.py           # CrewAI agent definitions
│   ├── tasks.py            # Task definitions with Instructor validation
│   ├── crew.py             # Crew orchestration
│   └── api.py              # FastAPI handler
├── utils/
│   └── cost_tracker.py     # Token budget enforcer
├── evaluation/
│   ├── langsmith_eval.py   # LangSmith eval suite
│   └── test_cases.json     # 10 DICOM test scenarios
├── infra/
│   ├── Dockerfile
│   ├── template.yaml       # AWS SAM template
│   └── deploy.sh
├── tests/
│   └── test_agents.py
├── samples/
│   └── sample_dicom_metadata.json
├── langsmith_config.py
├── .github/workflows/deploy.yml
├── .env.example
├── requirements.txt
└── README.md
```

## Setup
```bash
pip install -r requirements.txt
cp .env.example .env
uvicorn app.api:app --reload

# Deploy to AWS Lambda
cd infra && sam build && sam deploy --guided
```

## Observability
- **LangSmith:** every CrewAI agent step is traced. View at smith.langchain.com
- **Cost tracking:** TokenBudget enforces 80K token max per crew run (~$0.60)
- Set `LANGCHAIN_TRACING_V2=true` and `LANGCHAIN_API_KEY` in .env

## Key Concepts
- CrewAI multi-agent orchestration with role/goal/backstory
- Agent-to-agent task handoffs with context passing
- Instructor library for structured report validation
- AWS Lambda serverless deployment with SAM
- LangSmith tracing for multi-agent debugging

## Interview Talking Points
1. How do agents pass context between each other in CrewAI?
2. Why Lambda over a persistent server for this use case?
3. How would you handle HIPAA compliance in production?
4. What happens when Agent 3 flags a critical finding?
5. How would you evaluate report quality at scale?

## Time Estimate
| Mode | Time |
|---|---|
| Self-paced | 18–24 hours |
| Instructor-guided | 10–14 hours |

---

## Step-by-Step Implementation Guide

This guide walks you through building this project from scratch. Follow each step in order.

---

### Step 1: Project Setup

**1.1 — Create your virtual environment**

```bash
mkdir project-21-radiology-report-multi-agent-system
cd project-21-radiology-report-multi-agent-system
python -m venv venv
source venv/bin/activate    # Mac/Linux
venv\Scripts\activate       # Windows
```

**1.2 — Create the folder structure**

```bash
mkdir -p app utils evaluation infra tests samples
touch app/agents.py app/tasks.py app/crew.py app/api.py
touch utils/cost_tracker.py langsmith_config.py
touch requirements.txt .env.example
```

**1.3 — Install dependencies**

Add to `requirements.txt`:
```
crewai>=0.30.0
langchain>=0.2.0
langchain-openai>=0.1.0
langsmith>=0.1.0
instructor>=1.2.0
openai>=1.30.0
fastapi>=0.110.0
uvicorn>=0.29.0
mangum>=0.17.0
pydantic>=2.0.0
python-dotenv>=1.0.0
tiktoken>=0.7.0
pytest>=8.0.0
```

Then install:
```bash
pip install -r requirements.txt
```

**1.4 — Configure environment variables**

`.env.example`:
```
OPENAI_API_KEY=sk-your-key-here
LANGCHAIN_TRACING_V2=true
LANGCHAIN_API_KEY=ls__your-langsmith-key
LANGCHAIN_PROJECT=project-21-radiology-multi-agent
TOKEN_BUDGET=80000
```

```bash
cp .env.example .env
# Open .env and add your keys
```

---

### Step 2: Understand the Multi-Agent Architecture

```
DICOM metadata input
       ↓
Agent 1: DICOM Analyst       ← extracts technical parameters from raw metadata
       ↓ (task1 output becomes task2 context)
Agent 2: Report Drafter      ← writes ACR-format radiology report
       ↓ (task1 + task2 output becomes task3 context)
Agent 3: Anomaly Flagger     ← reviews for critical findings, decides routing
       ↓
FastAPI response + LangSmith trace
```

**Why 3 agents instead of 1 prompt?** Each agent has a distinct clinical role with a different cognitive profile. The DICOM Analyst thinks like a physicist (technical parameters), the Report Drafter thinks like a clinician (structured narrative), and the Anomaly Flagger thinks like a safety reviewer (risk assessment). Combining these into one prompt produces a confused output that does none of them well. Separating them with clear role/goal/backstory definitions lets each agent focus deeply on its specialisation.

**Why CrewAI over plain LangGraph for this?** CrewAI's role-based agent abstraction maps naturally to clinical workflows where human professionals have defined roles. LangGraph is better when you need custom conditional routing logic — here the routing is simple (sequential), so CrewAI's cleaner syntax wins.

---

### Step 3: Build the CrewAI Agents (`app/agents.py`)

```python
"""agents.py — CrewAI agent definitions"""
import os
from crewai import Agent
from langchain_openai import ChatOpenAI

llm = ChatOpenAI(model="gpt-4o", temperature=0.1, api_key=os.getenv("OPENAI_API_KEY"))


def build_agents():
    dicom_analyst = Agent(
        role="DICOM Metadata Analyst",
        goal="Extract and interpret all relevant clinical parameters from DICOM metadata",
        backstory=(
            "You are a radiological physicist with 15 years of experience interpreting "
            "medical imaging metadata. You extract patient demographics, scan modality, "
            "acquisition parameters, and any technical quality flags from DICOM data."
        ),
        llm=llm,
        verbose=True,
        allow_delegation=False,
        max_iter=3,
    )

    report_drafter = Agent(
        role="Radiology Report Drafter",
        goal="Generate a structured, clinically accurate radiology report from scan analysis",
        backstory=(
            "You are a board-certified radiologist who writes clear, structured reports "
            "following ACR (American College of Radiology) guidelines. Your reports always "
            "include: Technique, Clinical Indication, Findings, Impression, and Recommendations."
        ),
        llm=llm,
        verbose=True,
        allow_delegation=False,
        max_iter=3,
    )

    anomaly_flagger = Agent(
        role="Critical Finding Reviewer",
        goal="Review radiology reports for critical findings requiring urgent clinical action",
        backstory=(
            "You are a senior radiologist specialising in critical finding communication. "
            "You identify ACR critical findings (pneumothorax, aortic dissection, PE, "
            "intracranial haemorrhage, etc.) and determine urgency level."
        ),
        llm=llm,
        verbose=True,
        allow_delegation=False,
        max_iter=2,
    )

    return dicom_analyst, report_drafter, anomaly_flagger
```

**Why `temperature=0.1`?** Radiology reports must be reproducible and factual. Low temperature means the model consistently picks the most probable, conservative tokens — the same scan metadata should produce the same clinical language. A temperature of 0.5 would introduce random variation in how the same finding is described, which is clinically dangerous and legally problematic.

**Why `allow_delegation=False`?** Delegation lets an agent spin up a sub-agent to complete parts of its task. For regulated clinical outputs, every step must be traceable to a defined agent with a defined role. If agents self-delegate, your audit trail breaks down — you can't tell which agent produced which part of the report.

**Why `max_iter=3` for analyst/drafter and `max_iter=2` for flagger?** The DICOM Analyst and Report Drafter need iteration to refine clinical language and ensure all ACR sections are complete. The Anomaly Flagger has a binary decision to make (critical/not critical) — giving it more iterations risks overthinking a straightforward safety check.

---

### Step 4: Define the Tasks (`app/tasks.py`)

```python
"""tasks.py — Task definitions with Instructor-validated outputs"""
import instructor
import openai
from crewai import Task
from pydantic import BaseModel
from typing import Optional, Literal

client = instructor.patch(openai.OpenAI())


class DicomAnalysis(BaseModel):
    patient_id: str
    modality: str
    body_part: str
    acquisition_date: str
    scan_quality: Literal["good", "acceptable", "poor"]
    clinical_indication: str
    technical_notes: Optional[str] = None


class RadiologyReport(BaseModel):
    technique: str
    clinical_indication: str
    findings: str
    impression: str
    recommendations: str
    report_quality: Literal["complete", "needs_review"]


class AnomalyReview(BaseModel):
    has_critical_finding: bool
    urgency: Literal["routine", "urgent", "emergent"]
    critical_findings: list[str]
    routing: Literal["standard", "urgent_review", "immediate_escalation"]
    reviewer_notes: str


def build_tasks(dicom_analyst, report_drafter, anomaly_flagger, dicom_data: dict):
    task1 = Task(
        description=f"""Analyse the following DICOM metadata and extract all clinically
relevant parameters. Return a structured analysis.

DICOM Data: {dicom_data}

Focus on: modality, body part examined, scan quality, clinical indication,
and any technical parameters that affect diagnostic interpretation.""",
        agent=dicom_analyst,
        expected_output="Structured DICOM analysis with all clinical parameters extracted",
    )

    task2 = Task(
        description="""Using the DICOM analysis from Task 1, generate a complete structured
radiology report following ACR guidelines. The report must include all five sections:
Technique, Clinical Indication, Findings, Impression, and Recommendations.
Be specific, clinical, and precise. Do not speculate beyond what the data supports.""",
        agent=report_drafter,
        expected_output="Complete structured radiology report in ACR format",
        context=[task1],
    )

    task3 = Task(
        description="""Review the radiology report from Task 2 for critical findings.
Identify any findings that require urgent or emergent clinical communication per ACR criteria.
Critical findings include: tension pneumothorax, aortic dissection, massive PE,
intracranial haemorrhage, cord compression.
Determine the urgency level and appropriate routing.""",
        agent=anomaly_flagger,
        expected_output="Anomaly review with urgency classification and routing decision",
        context=[task1, task2],
    )

    return task1, task2, task3
```

**Why `context=[task1]` on task2 and `context=[task1, task2]` on task3?** CrewAI passes prior task outputs as context to downstream tasks via the `context` parameter. Without this, the Report Drafter would not have access to the structured DICOM analysis from Agent 1 — it would have to re-interpret the raw metadata itself, losing Agent 1's specialised extraction. Chaining the context ensures each agent builds on the previous agent's best work.

**Why Instructor + Pydantic models?** LLM outputs are free-form text. If the Report Drafter returns a report missing the "Impression" section, your API will silently return an incomplete report that reaches the radiologist. Pydantic models with required fields enforce structure — the system fails loudly with a validation error rather than silently returning a malformed report.

---

### Step 5: Orchestrate the Crew (`app/crew.py`)

```python
"""crew.py — Crew orchestration with cost tracking"""
import os
from crewai import Crew, Process
from langsmith_config import setup_langsmith
from agents import build_agents
from tasks import build_tasks
from utils.cost_tracker import TokenBudget, BudgetExceededError

setup_langsmith("project-21-radiology-multi-agent")


def run_radiology_crew(dicom_data: dict) -> dict:
    """Run the 3-agent radiology crew on DICOM metadata."""
    budget = TokenBudget(
        max_tokens=int(os.getenv("TOKEN_BUDGET", 80_000)),
        model="gpt-4o"
    )

    dicom_analyst, report_drafter, anomaly_flagger = build_agents()
    task1, task2, task3 = build_tasks(
        dicom_analyst, report_drafter, anomaly_flagger, dicom_data
    )

    crew = Crew(
        agents=[dicom_analyst, report_drafter, anomaly_flagger],
        tasks=[task1, task2, task3],
        process=Process.sequential,
        verbose=True,
    )

    try:
        with budget:
            result = crew.kickoff()
    except BudgetExceededError as e:
        return {"error": str(e), "partial_result": "Budget exceeded — crew stopped early"}

    return {
        "report":         str(result),
        "token_summary":  budget.summary(),
        "estimated_cost": budget.estimated_cost(),
    }
```

**Why `Process.sequential`?** The three agents have a strict dependency chain — the Report Drafter needs the DICOM Analyst's output, and the Anomaly Flagger needs both. Sequential processing enforces this ordering. `Process.hierarchical` (where a manager agent delegates) would add unnecessary overhead and a fourth LLM call for a pipeline where the ordering is fixed and known in advance.

**Why a TokenBudget?** A 3-agent CrewAI run on GPT-4o can use 20,000–80,000 tokens depending on DICOM complexity and how many iterations each agent takes. At $0.005/1K input + $0.015/1K output, an unbounded run could cost $1.20 per scan. With thousands of daily scans in a radiology department, this multiplies quickly. The 80K token ceiling (~$0.60) provides a hard financial guardrail.

---

### Step 6: Build the FastAPI Handler (`app/api.py`)

```python
"""api.py — FastAPI endpoint"""
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from crew import run_radiology_crew

app = FastAPI(title="Radiology Report Multi-Agent System")
app.add_middleware(
    CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"]
)


class DicomRequest(BaseModel):
    patient_id: str
    modality: str
    body_part: str
    acquisition_date: str
    clinical_indication: str
    scan_findings: str
    additional_metadata: dict = {}


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/generate-report")
def generate_report(req: DicomRequest):
    try:
        result = run_radiology_crew(req.model_dump())
        return result
    except Exception as e:
        raise HTTPException(500, str(e))
```

**Why keep the API thin?** The API's job is to receive an HTTP request, call the crew, and return the result. All intelligence — agent definitions, task chaining, cost control — lives in `crew.py`. This makes the API independently testable: you can `pytest` the crew logic without spinning up a server, and you can replace the HTTP layer with a Lambda handler, a CLI, or a queue consumer without touching the crew logic.

**Why `req.model_dump()` instead of passing the Pydantic object?** `build_tasks` embeds the DICOM data as a string in the task description. Pydantic V2 requires `.model_dump()` to convert the model to a plain dict, which then serialises cleanly into the f-string. Passing the raw Pydantic object would produce `DicomRequest(patient_id=...)` in the task description, which the LLM would need to parse — adding unnecessary complexity.

---

### Step 7: Configure LangSmith (`langsmith_config.py`)

```python
"""langsmith_config.py — LangSmith tracing setup"""
import os
from dotenv import load_dotenv
load_dotenv()


def setup_langsmith(project_name: str = "project-21-radiology-multi-agent"):
    """Configure LangSmith environment variables for tracing."""
    os.environ["LANGCHAIN_TRACING_V2"]  = os.getenv("LANGCHAIN_TRACING_V2", "true")
    os.environ["LANGCHAIN_API_KEY"]     = os.getenv("LANGCHAIN_API_KEY", "")
    os.environ["LANGCHAIN_PROJECT"]     = project_name
    os.environ["LANGCHAIN_ENDPOINT"]    = "https://api.smith.langchain.com"
```

Set these in `.env`:
```
LANGCHAIN_TRACING_V2=true
LANGCHAIN_API_KEY=ls__your-key
LANGCHAIN_PROJECT=project-21-radiology-multi-agent
```

**Why LangSmith for a CrewAI project?** CrewAI uses LangChain under the hood, which means all LLM calls automatically integrate with LangSmith tracing when you set the environment variables. Each crew run appears as a trace tree showing: which agent called the LLM, with what prompt, what the response was, how many tokens were used, and how long each step took. Without this, debugging a 3-agent run that produces an incorrect report is essentially impossible — you can't see which agent introduced the error.

---

### Step 8: Run Locally and Test

```bash
# Terminal 1 — start the API
uvicorn app.api:app --reload --port 8000

# Terminal 2 — send a test request
curl -X POST http://localhost:8000/generate-report \
  -H "Content-Type: application/json" \
  -d '{
    "patient_id": "PT-001",
    "modality": "CT",
    "body_part": "Chest",
    "acquisition_date": "2024-06-15",
    "clinical_indication": "Shortness of breath, rule out pulmonary embolism",
    "scan_findings": "Filling defect in right pulmonary artery. No pleural effusion. Heart size normal.",
    "additional_metadata": {"slice_thickness_mm": 1.25, "contrast": "IV contrast administered"}
  }'
```

Or use `samples/sample_dicom_metadata.json`:
```bash
curl -X POST http://localhost:8000/generate-report \
  -H "Content-Type: application/json" \
  -d @samples/sample_dicom_metadata.json
```

**Expected output:**
```json
{
  "report": "TECHNIQUE: CT pulmonary angiography with IV contrast...\nFINDINGS: Filling defect identified...\nIMPRESSION: Findings consistent with pulmonary embolism...",
  "token_summary": {"input_tokens": 12430, "output_tokens": 2180},
  "estimated_cost": 0.094
}
```

Run tests:
```bash
pytest tests/test_agents.py -v
```

---

### Step 9: Deploy to AWS Lambda

```bash
# Build the Lambda package
cd infra
sam build

# Deploy (first time — guided setup)
sam deploy --guided
# Stack name: radiology-report-system
# Region: us-east-1
# Confirm changes: Y

# Subsequent deploys
sam deploy
```

Set environment variables in `infra/template.yaml` or via the Lambda console:
```
OPENAI_API_KEY=sk-...
LANGCHAIN_TRACING_V2=true
LANGCHAIN_API_KEY=ls__...
TOKEN_BUDGET=80000
```

**Why Lambda over a persistent FastAPI server?** Radiology scans arrive in batches — busy during working hours, quiet overnight. A persistent server wastes money on idle capacity. Lambda scales to zero when not in use (cost: $0) and instantly handles concurrent reports during peak hours. The Mangum adapter wraps FastAPI for Lambda compatibility with zero code changes.

**Lambda sizing for this workload:** Memory 512MB–1024MB (CrewAI + LangChain libraries), Timeout 60s (3-agent run typically completes in 25–45s).

---

### Step 10: Troubleshooting

| Error | Cause | Fix |
|---|---|---|
| `crewai.exceptions.TaskError: Agent reached max_iter` | Agent couldn't complete task in allotted iterations | Increase `max_iter` or simplify the task description |
| `openai.RateLimitError` | 3 agents making parallel LLM calls hitting TPM limit | Add `time.sleep(1)` between agent inits, or use a higher-tier OpenAI plan |
| `BudgetExceededError: Token limit 80000 exceeded` | DICOM data or crew verbose output is very large | Increase `TOKEN_BUDGET` env var or reduce `verbose=True` to `verbose=False` |
| `LangSmith: No traces appearing` | `LANGCHAIN_TRACING_V2` not set before crew init | Call `setup_langsmith()` before `build_agents()` — order matters |
| `Lambda timeout` | 3-agent crew exceeds 30s default timeout | Set Lambda timeout to 60s in `template.yaml` |
| `mangum.exceptions.ConfigurationError` | Lambda handler path wrong | Ensure `Handler: app.api.handler` in `template.yaml` and `handler = Mangum(app)` in `api.py` |
| `instructor.ValidationError` | LLM output missing required Pydantic fields | Add `# Return ONLY valid JSON matching this schema:` to task description |

---

## Evaluation Rubric

| Criteria | Meets | Exceeds |
|---|---|---|
| **Functionality** | All 3 agents run and produce a report | Critical findings correctly identified and routed to urgent queue |
| **Code Quality** | Agents, tasks, crew separated into distinct files | Pydantic models validate all agent outputs; Instructor integration working |
| **Architecture** | CrewAI sequential crew with context passing | TokenBudget enforced; cost per run tracked and logged |
| **Observability** | LangSmith traces visible for each crew run | Trace shows per-agent token usage; cost visible in trace metadata |
| **Business Framing** | Problem + solution stated | Quantified: reports produced per hour vs radiologist baseline |

---

## Interview Talking Points

1. **How do agents pass context in CrewAI?** — Via the `context` parameter on `Task`. Task outputs are stored by CrewAI and passed as additional context to any task that lists the prior task in its `context` list. The downstream agent receives both the original task description and the upstream agent's output string.

2. **Why Lambda over a persistent server for this?** — Radiology scan ingestion is bursty, not continuous. Lambda's cost model ($0 at rest, ~$0.0000002/request) is far cheaper than an always-on server for intermittent workloads. Cold start is 3–5s for this stack, which is acceptable since the crew run itself takes 25–45s.

3. **How would you handle HIPAA compliance in production?** — Encrypt DICOM data at rest (S3 SSE-KMS) and in transit (TLS 1.2+), strip PHI before sending to OpenAI (or use Azure OpenAI with BAA), log all accesses in CloudTrail, implement IAM least-privilege on Lambda execution role, and use VPC endpoints so data never traverses the public internet.

4. **What happens when Agent 3 flags a critical finding?** — The `AnomalyReview` Pydantic model sets `routing="urgent_review"` or `"immediate_escalation"`. The API reads this field and routes to a separate queue (SQS or SNS) that pages the on-call radiologist. The standard report endpoint never returns until the routing decision is made.

5. **How would you evaluate report quality at scale?** — Use LangSmith's evaluation framework: create a test set of 50 DICOM cases with gold-standard radiologist reports, then use GPT-4o as a judge to score generated reports on accuracy, completeness (all ACR sections present), and hallucination rate. Track these metrics in W&B across model/prompt versions.

---

## Bonus Extensions

- **GPT-4o Vision:** Pass actual DICOM images (converted to PNG) to Agent 1 instead of just metadata — enables visual finding detection, not just metadata parsing.
- **HL7 FHIR integration:** Replace the JSON input with a FHIR DiagnosticReport resource and output a FHIR-formatted report — enables direct integration with hospital EHR systems.
- **Human-in-the-loop:** Add a `/review/{report_id}` endpoint where a radiologist can approve, reject, or edit the generated report before it enters the patient record.
- **Multi-language reports:** Add a language parameter and a post-processing translation step using GPT-4o — useful for multinational hospital groups.

