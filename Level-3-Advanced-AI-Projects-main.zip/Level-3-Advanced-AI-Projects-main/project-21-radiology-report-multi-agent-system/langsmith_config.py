"""
langsmith_config.py
Sets up LangSmith tracing for LangChain and LangGraph projects.

LangSmith automatically traces every LLM call, chain, and agent step
when these environment variables are set. No code changes needed in
LangChain/LangGraph projects — just import this file at startup.

For CrewAI projects, use the @traceable decorator from langsmith.

Setup:
1. Sign up at https://smith.langchain.com (free tier available)
2. Create a project and copy your API key
3. Add to .env:
   LANGCHAIN_TRACING_V2=true
   LANGCHAIN_API_KEY=ls__your-key-here
   LANGCHAIN_PROJECT=your-project-name

View traces at: https://smith.langchain.com
Docs: https://docs.smith.langchain.com
"""

import os
from dotenv import load_dotenv

load_dotenv()

def setup_langsmith(project_name: str = None):
    """
    Activate LangSmith tracing. Call once at application startup.
    If LANGCHAIN_API_KEY is not set, tracing is silently skipped.
    """
    api_key = os.getenv("LANGCHAIN_API_KEY")
    if not api_key:
        print("[LangSmith] LANGCHAIN_API_KEY not set — tracing disabled.")
        return False

    os.environ["LANGCHAIN_TRACING_V2"] = "true"
    os.environ["LANGCHAIN_ENDPOINT"]   = "https://api.smith.langchain.com"

    if project_name:
        os.environ["LANGCHAIN_PROJECT"] = project_name
    elif not os.getenv("LANGCHAIN_PROJECT"):
        os.environ["LANGCHAIN_PROJECT"] = "level3-ai-project"

    print(f"[LangSmith] Tracing enabled → project: {os.environ['LANGCHAIN_PROJECT']}")
    print(f"[LangSmith] View traces at: https://smith.langchain.com")
    return True


# Auto-configure when imported
_enabled = setup_langsmith()
