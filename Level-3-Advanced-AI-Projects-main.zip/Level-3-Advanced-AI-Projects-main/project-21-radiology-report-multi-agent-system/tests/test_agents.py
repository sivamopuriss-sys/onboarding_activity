"""test_agents.py"""
import sys; sys.path.insert(0,"app")
from tasks import DicomAnalysis, RadiologyReport, AnomalyReview

def test_dicom_analysis_model():
    d = DicomAnalysis(patient_id="PT001", modality="CT", body_part="Chest",
                      acquisition_date="2024-01-01", scan_quality="good",
                      clinical_indication="Shortness of breath")
    assert d.modality == "CT"
    assert d.scan_quality == "good"

def test_anomaly_review_routing():
    a = AnomalyReview(has_critical_finding=True, urgency="emergent",
                      critical_findings=["tension pneumothorax"],
                      routing="immediate_escalation", reviewer_notes="Urgent action required")
    assert a.routing == "immediate_escalation"
    assert a.has_critical_finding is True

def test_report_quality_field():
    r = RadiologyReport(technique="CT with contrast", clinical_indication="SOB",
                        findings="Filling defect in RPA", impression="Pulmonary embolism",
                        recommendations="Immediate anticoagulation", report_quality="complete")
    assert r.report_quality == "complete"
