"""langsmith_eval.py — LangSmith evaluation suite"""
import json
from langsmith import Client
from langsmith.evaluation import evaluate

client = Client()

def report_completeness(run, example):
    """Check if all 5 ACR report sections are present."""
    output = str(run.outputs.get("report", ""))
    required_sections = ["Technique", "Clinical Indication", "Findings", "Impression", "Recommendations"]
    score = sum(1 for s in required_sections if s.lower() in output.lower()) / len(required_sections)
    return {"key": "report_completeness", "score": score}

def critical_finding_detection(run, example):
    """Check if critical findings are correctly identified."""
    output = str(run.outputs.get("report", ""))
    expected_critical = example.outputs.get("has_critical_finding", False)
    detected = "critical" in output.lower() or "urgent" in output.lower() or "emergent" in output.lower()
    correct = detected == expected_critical
    return {"key": "critical_finding_accuracy", "score": 1.0 if correct else 0.0}

if __name__ == "__main__":
    with open("test_cases.json") as f:
        test_cases = json.load(f)

    dataset = client.create_dataset("radiology-report-eval", description="Radiology report quality evaluation")
    for case in test_cases:
        client.create_example(inputs=case["input"], outputs=case["expected"], dataset_id=dataset.id)

    print("LangSmith dataset created. Run evaluate() to execute the eval suite.")
    print("See: https://docs.smith.langchain.com/evaluation")
