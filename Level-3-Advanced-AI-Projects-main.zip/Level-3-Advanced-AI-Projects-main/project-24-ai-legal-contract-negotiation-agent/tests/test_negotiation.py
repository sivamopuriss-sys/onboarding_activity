"""test_negotiation.py"""
import sys; sys.path.insert(0,"app")
from tasks import NegotiationResult

def test_negotiation_result_model():
    r = NegotiationResult(clause_number=1, clause_title="Payment Terms",
                          buyer_position="Net 60", seller_position="Net 15",
                          agreed_text="Net 30 days from invoice date.",
                          status="compromise", notes="Both parties accepted middle ground")
    assert r.status == "compromise"
    assert "30" in r.agreed_text

def test_status_enum():
    for s in ["agreed","buyer_win","seller_win","compromise"]:
        r = NegotiationResult(clause_number=1, clause_title="Test",
                              buyer_position="X", seller_position="Y",
                              agreed_text="Z", status=s, notes="")
        assert r.status == s
