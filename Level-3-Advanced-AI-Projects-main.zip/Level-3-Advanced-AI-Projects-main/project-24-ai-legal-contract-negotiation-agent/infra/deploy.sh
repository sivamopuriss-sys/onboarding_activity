#!/bin/bash
set -e
RESOURCE_GROUP="ai-projects-rg"
APP_NAME="contract-negotiation-agent"
REGISTRY="your-registry.azurecr.io"
IMAGE="$REGISTRY/$APP_NAME:latest"

echo "Building Docker image..."
docker build -t $IMAGE .
docker push $IMAGE

echo "Deploying ARM template..."
az deployment group create \
  --resource-group $RESOURCE_GROUP \
  --template-file infra/azuredeploy.json \
  --parameters appName=$APP_NAME containerImage=$IMAGE \
               anthropicApiKey=$ANTHROPIC_API_KEY \
               langsmithApiKey=$LANGCHAIN_API_KEY

echo "Deployment complete."
echo "Get URL: az containerapp show --name $APP_NAME --resource-group $RESOURCE_GROUP --query properties.configuration.ingress.fqdn"
