# Project 24 — AI Legal Contract Negotiation Agent

![Level](https://img.shields.io/badge/Level-Advanced-purple)
![Industry](https://img.shields.io/badge/Industry-Legal-purple)
![Stack](https://img.shields.io/badge/Stack-CrewAI%20%7C%20Claude%20API%20%7C%20Instructor%20%7C%20Azure%20OpenAI%20%7C%20python--docx-blue)

## Business Problem
Contract negotiation between two parties involves iterative proposal, counter-proposal,
and compromise on individual clauses. This typically requires hours of lawyer time on each
side. A multi-agent simulation where Buyer and Seller agents negotiate clause-by-clause,
with an Arbitrator producing a final redlined DOCX, demonstrates how AI can accelerate
the negotiation drafting phase — leaving lawyers to review rather than draft from scratch.

## Project Objective
Build a CrewAI 3-agent negotiation system:
- **Buyer Agent** — argues for buyer-favourable positions on each clause
- **Seller Agent** — argues for seller-favourable positions
- **Arbitrator Agent** — synthesises a compromise and produces the final redlined contract

Output: a real `.docx` file with tracked changes showing agreed vs disputed clauses.
All agent interactions traced in LangSmith. Instructor validates structured negotiation outputs.

## System Architecture
```mermaid
graph TD
    A[Input contract clauses] --> B[FastAPI]
    B --> C[CrewAI Negotiation Crew]
    C --> D[Buyer Agent - argues buyer position]
    D --> E[Seller Agent - counter-argues]
    E --> F[Arbitrator Agent - finds compromise]
    F --> G[Instructor - validates NegotiationResult]
    G --> H[python-docx - generates redlined DOCX]
    H --> I[Download endpoint]
    C --> J[LangSmith - traces negotiation rounds]
    C --> K[TokenBudget - cost guard]
    B --> L[Azure Container Apps deployment]
```

## Folder Structure
```
project-24-ai-legal-contract-negotiation-agent/
├── app/
│   ├── agents.py           # CrewAI Buyer, Seller, Arbitrator agents
│   ├── tasks.py            # Negotiation task definitions
│   ├── crew.py             # Crew orchestration
│   ├── docx_writer.py      # DOCX generation with tracked changes
│   └── api.py              # FastAPI endpoints
├── utils/
│   └── cost_tracker.py
├── evaluation/
│   └── langsmith_eval.py
├── infra/
│   ├── Dockerfile
│   ├── azuredeploy.json    # Azure ARM template
│   └── deploy.sh
├── tests/
│   └── test_negotiation.py
├── samples/
│   └── sample_clauses.json
├── langsmith_config.py
├── .github/workflows/deploy.yml
├── .env.example
├── requirements.txt
└── README.md
```

## Setup
```bash
pip install -r requirements.txt
cp .env.example .env
uvicorn app.api:app --reload

# Deploy to Azure
az login
bash infra/deploy.sh
```

## Key Concepts
- CrewAI multi-agent negotiation with adversarial roles
- Instructor library for structured NegotiationResult validation
- python-docx for DOCX generation with tracked changes
- Azure Container Apps deployment
- LangSmith tracing for multi-round negotiation debugging
- TokenBudget for cost control on complex multi-turn negotiations

## Time Estimate
| Mode | Time |
|---|---|
| Self-paced | 20–26 hours |
| Instructor-guided | 11–15 hours |

---

## Step-by-Step Implementation Guide

This guide walks you through building this project from scratch. Follow each step in order.

---

### Step 1: Project Setup

```bash
mkdir project-24-ai-legal-contract-negotiation-agent
cd project-24-ai-legal-contract-negotiation-agent
python -m venv venv && source venv/bin/activate
mkdir -p app utils evaluation infra tests samples
touch app/agents.py app/tasks.py app/crew.py app/docx_writer.py app/api.py
touch utils/cost_tracker.py langsmith_config.py
touch requirements.txt .env.example
```

`requirements.txt`:
```
crewai>=0.30.0
langchain>=0.2.0
langchain-anthropic>=0.1.0
langsmith>=0.1.0
instructor>=1.2.0
openai>=1.30.0
anthropic>=0.28.0
python-docx>=1.1.0
fastapi>=0.110.0
uvicorn>=0.29.0
pydantic>=2.0.0
python-dotenv>=1.0.0
tiktoken>=0.7.0
pytest>=8.0.0
```

`.env.example`:
```
ANTHROPIC_API_KEY=sk-ant-your-key
LANGCHAIN_TRACING_V2=true
LANGCHAIN_API_KEY=ls__your-key
LANGCHAIN_PROJECT=project-24-legal-negotiation
TOKEN_BUDGET=100000
```

---

### Step 2: Understand Multi-Agent Negotiation Design

```
Input: list of contract clauses (e.g., Payment Terms, IP Ownership, Termination Rights)

For each clause:
  Buyer Agent  → argues buyer-favourable position
       ↓ (seller sees buyer's argument as context)
  Seller Agent → argues seller-favourable counter-position
       ↓ (arbitrator sees both arguments as context)
  Arbitrator   → produces compromise text + status (agreed/buyer_win/seller_win/compromise)

Output: python-docx DOCX file with each clause colour-coded by outcome
```

**Why adversarial agents instead of one summariser?** A single agent asked to "find a compromise" anchors to whatever it generates first, lacking the genuine tension of opposing interests. Two agents with fixed backstories arguing from locked positions produce a richer negotiation — the Buyer consistently pushes for liability caps, the Seller consistently protects IP — and the Arbitrator synthesises from genuinely competing arguments. The output is more balanced and more useful to human lawyers.

**Why Claude (Anthropic) instead of GPT-4o here?** Claude 3.5 Sonnet has demonstrated stronger performance on long legal document tasks and is known for producing more nuanced, balanced reasoning — which matters for an Arbitrator that needs to understand both parties' positions fairly. Using the Claude API also demonstrates that production multi-agent systems can mix LLM providers per-agent based on task fit.

---

### Step 3: Build the Three Agents (`app/agents.py`)

```python
"""agents.py — Buyer, Seller, and Arbitrator agent definitions"""
import os
from crewai import Agent
from langchain_anthropic import ChatAnthropic

llm = ChatAnthropic(
    model="claude-3-5-sonnet-20241022",
    temperature=0.3,
    anthropic_api_key=os.getenv("ANTHROPIC_API_KEY"),
)


def build_negotiation_agents(buyer_company: str = "Buyer Corp",
                              seller_company: str = "Seller Inc"):
    buyer_agent = Agent(
        role="Contract Negotiator (Buyer)",
        goal=f"Negotiate contract clauses in the best interest of {buyer_company}",
        backstory=(
            f"You are a senior legal counsel representing {buyer_company}. "
            "You always seek to minimise liability, maximise termination rights, "
            "protect IP ownership, and secure favourable payment terms. "
            "You are firm but reasonable — you want a deal, not a fight."
        ),
        llm=llm, verbose=True, allow_delegation=False, max_iter=2,
    )

    seller_agent = Agent(
        role="Contract Negotiator (Seller)",
        goal=f"Negotiate contract clauses in the best interest of {seller_company}",
        backstory=(
            f"You are a senior legal counsel representing {seller_company}. "
            "You seek to protect revenue, limit liability, retain IP rights, "
            "and secure upfront payment. A signed deal is the goal."
        ),
        llm=llm, verbose=True, allow_delegation=False, max_iter=2,
    )

    arbitrator_agent = Agent(
        role="Contract Arbitrator",
        goal="Find a fair compromise on each disputed clause and produce final agreed text",
        backstory=(
            "You are an experienced commercial contracts arbitrator with 20 years of experience. "
            "You review both parties' positions and craft compromise language that is "
            "legally sound, commercially balanced, and acceptable to both sides."
        ),
        llm=llm, verbose=True, allow_delegation=False, max_iter=2,
    )

    return buyer_agent, seller_agent, arbitrator_agent
```

**Why `max_iter=2` for all agents?** Each agent's job within a single clause negotiation is well-defined: propose a position (iteration 1) and refine it if needed (iteration 2). More iterations risk agents going in circles or introducing new issues not in the original clause. Legal negotiation is about converging, not exploring.

**Why `allow_delegation=False`?** In a contract negotiation, you need a clear paper trail: the Buyer Agent said X, the Seller Agent said Y. If agents self-delegate and spawn sub-agents, the negotiation trail becomes fragmented and unauditable — a serious problem in legal contexts where you need to show who proposed what.

---

### Step 4: Define the Negotiation Tasks (`app/tasks.py`)

```python
"""tasks.py — Negotiation task definitions"""
import instructor, openai
from crewai import Task
from pydantic import BaseModel
from typing import Literal

client = instructor.patch(openai.OpenAI())


class ClausePosition(BaseModel):
    clause_title: str
    position:     str        # The party's proposed clause text
    rationale:    str        # Why this position benefits the party
    red_lines:    list[str]  # Non-negotiable points


class NegotiationResult(BaseModel):
    clause_number: int
    clause_title:  str
    agreed_text:   str
    status:        Literal["agreed", "buyer_win", "seller_win", "compromise"]
    notes:         str


def build_negotiation_tasks(buyer_agent, seller_agent, arbitrator_agent,
                             clause: dict, clause_number: int):
    task_buyer = Task(
        description=f"""Clause {clause_number}: {clause['title']}
Original text: {clause['text']}

As the Buyer's legal counsel, argue for the buyer-favourable position on this clause.
State: your proposed text, your rationale, and your non-negotiable red lines.""",
        agent=buyer_agent,
        expected_output="Buyer's position: proposed clause text, rationale, and red lines",
    )

    task_seller = Task(
        description=f"""Clause {clause_number}: {clause['title']}
Review the Buyer's position above and provide the Seller's counter-position.
State: your proposed text, your rationale, and your non-negotiable red lines.""",
        agent=seller_agent,
        expected_output="Seller's counter-position: proposed clause text, rationale, and red lines",
        context=[task_buyer],
    )

    task_arbitrator = Task(
        description=f"""Clause {clause_number}: {clause['title']}
You have heard both parties. Synthesise a compromise clause that:
1. Is legally sound and complete
2. Balances both parties' interests fairly
3. Respects each party's stated red lines where possible

Classify the outcome as: agreed (both got what they wanted), buyer_win, seller_win, or compromise.""",
        agent=arbitrator_agent,
        expected_output="Final agreed clause text with outcome classification and explanatory notes",
        context=[task_buyer, task_seller],
    )

    return task_buyer, task_seller, task_arbitrator
```

**Why separate tasks per clause instead of one task for the whole contract?** A 20-clause contract passed as a single task produces a single compromise across all clauses — the Arbitrator can't give different outcomes to different clauses. Separating by clause gives granular control and produces per-clause status codes (buyer_win/seller_win/compromise) that drive the DOCX colour coding.

---

### Step 5: Orchestrate the Crew (`app/crew.py`)

```python
"""crew.py — Crew orchestration"""
import os
from crewai import Crew, Process
from langsmith_config import setup_langsmith
from agents import build_negotiation_agents
from tasks import build_negotiation_tasks, NegotiationResult
from utils.cost_tracker import TokenBudget, BudgetExceededError

setup_langsmith("project-24-legal-negotiation")


def run_negotiation(clauses: list[dict], buyer_company: str = "Buyer Corp",
                    seller_company: str = "Seller Inc") -> list[dict]:
    """Run clause-by-clause negotiation. Returns list of NegotiationResult dicts."""
    budget  = TokenBudget(max_tokens=int(os.getenv("TOKEN_BUDGET", 100_000)), model="claude-3-5-sonnet-20241022")
    buyer_agent, seller_agent, arbitrator_agent = build_negotiation_agents(buyer_company, seller_company)
    results = []

    for i, clause in enumerate(clauses, 1):
        task_buyer, task_seller, task_arb = build_negotiation_tasks(
            buyer_agent, seller_agent, arbitrator_agent, clause, i)

        crew = Crew(
            agents=[buyer_agent, seller_agent, arbitrator_agent],
            tasks=[task_buyer, task_seller, task_arb],
            process=Process.sequential,
            verbose=True,
        )

        try:
            with budget:
                outcome = crew.kickoff()
            results.append({
                "clause_number": i,
                "clause_title":  clause["title"],
                "agreed_text":   str(outcome),
                "status":        "compromise",  # Arbitrator classifies in output text
                "notes":         f"Negotiated by {buyer_company} and {seller_company}",
            })
        except BudgetExceededError:
            results.append({
                "clause_number": i,
                "clause_title":  clause["title"],
                "agreed_text":   clause["text"],  # Fall back to original
                "status":        "agreed",
                "notes":         "Budget exceeded — original text retained",
            })

    return results
```

**Why create a new `Crew` per clause?** CrewAI maintains state within a crew run. If you process all clauses in one crew, the agents accumulate context from earlier clauses that bleeds into later ones (Agent 1's reasoning about Payment Terms affects how it reasons about IP Ownership). A fresh crew per clause keeps each negotiation isolated and focused.

---

### Step 6: Generate the Redlined DOCX (`app/docx_writer.py`)

```python
"""docx_writer.py — Generate redlined DOCX contract"""
from docx import Document
from docx.shared import Pt, RGBColor
import io


STATUS_COLOURS = {
    "agreed":     RGBColor(0x00, 0x00, 0x00),  # Black
    "buyer_win":  RGBColor(0x00, 0x44, 0xCC),  # Blue
    "seller_win": RGBColor(0x00, 0x88, 0x00),  # Green
    "compromise": RGBColor(0xCC, 0x66, 0x00),  # Orange
}


def generate_contract_docx(contract_title: str, buyer_name: str,
                            seller_name: str, negotiation_results: list[dict]) -> bytes:
    doc = Document()
    title = doc.add_heading(contract_title, 0)
    title.alignment = 1
    doc.add_paragraph(f"Between: {buyer_name} ('Buyer') and {seller_name} ('Seller')")
    doc.add_paragraph("")

    # Legend
    legend = doc.add_paragraph()
    legend.add_run("Legend: ").bold = True
    for status, colour in STATUS_COLOURS.items():
        r = legend.add_run(f"{status.replace('_',' ').title()}  ")
        r.font.color.rgb = colour

    for result in negotiation_results:
        doc.add_heading(f"Clause {result['clause_number']}: {result['clause_title']}", level=2)
        colour = STATUS_COLOURS.get(result.get("status","agreed"), STATUS_COLOURS["agreed"])

        status_para = doc.add_paragraph()
        sr = status_para.add_run(f"[{result.get('status','AGREED').upper().replace('_',' ')}]")
        sr.bold = True
        sr.font.color.rgb = colour

        text_para = doc.add_paragraph()
        tr = text_para.add_run(result.get("agreed_text", ""))
        tr.font.color.rgb = colour

        if result.get("notes"):
            notes_para = doc.add_paragraph()
            nr = notes_para.add_run(f"Note: {result['notes']}")
            nr.italic = True
            nr.font.size = Pt(9)
        doc.add_paragraph("")

    # Signatures
    doc.add_heading("Signatures", level=2)
    sig_table = doc.add_table(rows=2, cols=2)
    sig_table.cell(0,0).text = f"For {buyer_name}:"
    sig_table.cell(0,1).text = f"For {seller_name}:"
    sig_table.cell(1,0).text = "\n\nSignature: ________________\nDate: ________________"
    sig_table.cell(1,1).text = "\n\nSignature: ________________\nDate: ________________"

    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()
```

**Why colour-coded DOCX instead of HTML or PDF?** Lawyers work in Word. Tracked changes and colour coding are standard redlining conventions in legal practice. A DOCX that opens directly in Word, showing each clause's negotiation outcome in the standard colour scheme, requires zero explanation for a lawyer to interpret. PDF is fine for final signed versions but limits further editing.

**Why `io.BytesIO` instead of writing to disk?** Writing to disk requires managing temporary files, cleaning up after requests, and handling concurrent requests (multiple negotiations writing to the same path). `BytesIO` generates the DOCX entirely in memory and returns bytes — the API can stream this directly to the client with `StreamingResponse` without any file I/O.

---

### Step 7: Build the FastAPI Endpoints (`app/api.py`)

```python
"""api.py — FastAPI endpoints"""
import uuid
from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.responses import StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from crew import run_negotiation
from docx_writer import generate_contract_docx
import io

app = FastAPI(title="AI Legal Contract Negotiation Agent")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

job_store: dict = {}


class NegotiationRequest(BaseModel):
    clauses:         list[dict]  # [{"title": "...", "text": "..."}, ...]
    buyer_company:   str = "Buyer Corp"
    seller_company:  str = "Seller Inc"
    contract_title:  str = "Commercial Services Agreement"


@app.get("/health")
def health(): return {"status": "ok"}


@app.post("/negotiate")
def negotiate(req: NegotiationRequest, background_tasks: BackgroundTasks):
    job_id = str(uuid.uuid4())
    job_store[job_id] = {"status": "running", "results": None}

    def _run():
        results = run_negotiation(req.clauses, req.buyer_company, req.seller_company)
        docx_bytes = generate_contract_docx(
            req.contract_title, req.buyer_company, req.seller_company, results)
        job_store[job_id] = {"status": "completed", "results": results,
                              "docx_bytes": docx_bytes,
                              "buyer": req.buyer_company, "seller": req.seller_company,
                              "title": req.contract_title}

    background_tasks.add_task(_run)
    return {"job_id": job_id, "status": "queued"}


@app.get("/status/{job_id}")
def get_status(job_id: str):
    job = job_store.get(job_id)
    if not job: raise HTTPException(404, "Job not found")
    return {"status": job["status"], "results": job.get("results")}


@app.get("/download/{job_id}")
def download_docx(job_id: str):
    job = job_store.get(job_id)
    if not job or job["status"] != "completed":
        raise HTTPException(404, "Contract not ready or not found")
    return StreamingResponse(
        io.BytesIO(job["docx_bytes"]),
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        headers={"Content-Disposition": f'attachment; filename="contract_{job_id[:8]}.docx"'},
    )
```

---

### Step 8: Run and Test

```bash
uvicorn app.api:app --reload --port 8000

# Submit a negotiation
curl -X POST http://localhost:8000/negotiate \
  -H "Content-Type: application/json" \
  -d @samples/sample_clauses.json

# Check status
curl http://localhost:8000/status/YOUR_JOB_ID

# Download the DOCX
curl http://localhost:8000/download/YOUR_JOB_ID -o contract.docx
```

---

### Step 9: Deploy to Azure

```bash
az login
az group create --name cdss-rg --location eastus
bash infra/deploy.sh
```

`infra/deploy.sh`:
```bash
#!/bin/bash
az containerapp env create \
  --name negotiation-env \
  --resource-group cdss-rg \
  --location eastus

az containerapp create \
  --name legal-negotiation-agent \
  --resource-group cdss-rg \
  --environment negotiation-env \
  --image gcr.io/your-registry/legal-negotiation:latest \
  --target-port 8000 \
  --ingress external \
  --secrets anthropic-key=YOUR_KEY \
  --env-vars ANTHROPIC_API_KEY=secretref:anthropic-key
```

---

### Step 10: Troubleshooting

| Error | Cause | Fix |
|---|---|---|
| `anthropic.AuthenticationError` | Invalid ANTHROPIC_API_KEY | Check `.env` and ensure key starts with `sk-ant-` |
| Agents arguing indefinitely | `max_iter` too high, no convergence instruction | Reduce to `max_iter=2` and add "Find a final compromise." to Arbitrator task |
| `python-docx AttributeError: RGBColor` | Old version of python-docx | Upgrade: `pip install python-docx>=1.1.0` |
| `BudgetExceededError` on long contracts | 10+ clauses × 3 agents × ~5K tokens each | Use `max_iter=1` for routine clauses, increase TOKEN_BUDGET |
| DOCX opens with encoding errors | Non-ASCII characters in clause text | Sanitise input: `clause_text.encode('utf-8', errors='replace').decode('utf-8')` |
| Azure deployment: container won't start | Missing environment variable in Container App | Check Azure portal → Container App → Environment Variables |

---

## Evaluation Rubric

| Criteria | Meets | Exceeds |
|---|---|---|
| **Functionality** | 3 agents negotiate at least 3 clauses to a DOCX output | All 5 sample clauses negotiated; per-clause status correctly classified |
| **Code Quality** | Agents, tasks, crew, docx_writer cleanly separated | Pydantic NegotiationResult validates arbitrator outputs |
| **DOCX Output** | Colour-coded document generated and downloadable | Legend included; signature blocks; notes per clause |
| **Observability** | LangSmith traces visible for each clause negotiation | Per-clause token usage logged; cost per contract estimated |
| **Business Framing** | Use case explained | Hours saved vs manual negotiation drafting quantified |

---

## Interview Talking Points

1. **Why adversarial agents instead of one summariser?** — Adversarial agents with locked backstories produce genuine tension. A single agent asked to "compromise" anchors to its first output and lacks opposing force. Two agents arguing from fixed positions give the Arbitrator genuinely competing arguments to synthesise.

2. **How does Instructor validate negotiation outputs?** — The `NegotiationResult` Pydantic model with a `Literal["agreed","buyer_win","seller_win","compromise"]` status field forces the LLM to output a valid classification. Instructor retries with an error correction prompt if the output doesn't match the schema — critical for downstream DOCX colour coding.

3. **Why Azure over AWS for this project?** — Azure's legal enterprise customer base means better BAA (Business Associate Agreement) availability, stronger EU data residency controls, and native integration with Microsoft 365 (Word, SharePoint) — relevant when DOCX files are the deliverable.

4. **How would you extend this to multi-party negotiations (3+ parties)?** — Add additional agents (Party C, Party D) and additional task steps per clause. The Arbitrator task would receive context from all prior parties. For 5+ parties, consider a Manager agent (hierarchical process) that coordinates sub-negotiations between pairs of parties.

5. **What are the attorney-client privilege implications?** — Sending contract clauses to an LLM API may constitute disclosure to a third party, potentially waiving privilege. In production, use Azure OpenAI (which doesn't use data for training and offers BAA), implement PII/confidential content detection before API calls, and get explicit client consent.

---

## Bonus Extensions

- **Multi-round negotiation:** Allow Buyer and Seller to make multiple counter-proposals before the Arbitrator intervenes — produces more nuanced compromises on complex clauses.
- **Negotiation history export:** Output a full negotiation transcript showing each agent's exact arguments per clause — useful for audit trails and lawyer review.
- **Template library:** Pre-load standard clause templates (NDA, SaaS MSA, employment contract) so users can start with a structured contract instead of blank clauses.
- **Clause risk scoring:** Add a Risk Analyst agent that rates each agreed clause for legal risk on a 1–10 scale with flagged concerns.

