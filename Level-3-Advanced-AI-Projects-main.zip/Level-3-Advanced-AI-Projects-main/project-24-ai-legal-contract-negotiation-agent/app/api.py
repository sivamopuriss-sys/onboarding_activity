"""api.py — FastAPI endpoints"""
import io
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from crew import run_negotiation
from docx_writer import generate_contract_docx

app = FastAPI(title="AI Legal Contract Negotiation Agent")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

class NegotiationRequest(BaseModel):
    contract_title: str = "Service Agreement"
    buyer_name: str = "Buyer Corp"
    seller_name: str = "Seller Inc"
    clauses: list[dict]

@app.get("/health")
def health(): return {"status":"ok"}

@app.post("/negotiate")
def negotiate(req: NegotiationRequest):
    if not req.clauses:
        raise HTTPException(422,"At least one clause required.")
    return run_negotiation(req.clauses, req.buyer_name, req.seller_name)

@app.post("/negotiate-and-download")
def negotiate_and_download(req: NegotiationRequest):
    result = run_negotiation(req.clauses, req.buyer_name, req.seller_name)
    # Parse result into structured clauses (simplified — extend for production)
    mock_results = [{"clause_number":i+1,"clause_title":c.get("title","Clause"),
                     "agreed_text":c.get("text",""),"status":"compromise","notes":""}
                    for i,c in enumerate(req.clauses)]
    docx_bytes = generate_contract_docx(req.contract_title, req.buyer_name,
                                         req.seller_name, mock_results)
    return StreamingResponse(
        io.BytesIO(docx_bytes),
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        headers={"Content-Disposition": f"attachment; filename={req.contract_title.replace(' ','_')}.docx"}
    )
