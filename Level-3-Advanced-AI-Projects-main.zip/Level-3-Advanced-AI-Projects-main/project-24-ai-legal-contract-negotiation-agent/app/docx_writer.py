"""docx_writer.py — Generate redlined DOCX contract"""
from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_COLOR_INDEX
import io


def generate_contract_docx(
    contract_title: str,
    buyer_name: str,
    seller_name: str,
    negotiation_results: list[dict],
) -> bytes:
    """
    Generate a Word document with negotiation results.
    Agreed clauses shown in black. Buyer wins in blue. Seller wins in green. Compromises in orange.
    """
    doc = Document()

    # Title
    title = doc.add_heading(contract_title, 0)
    title.alignment = 1  # Centre

    doc.add_paragraph(f"Between: {buyer_name} ('Buyer') and {seller_name} ('Seller')")
    doc.add_paragraph("")

    # Colour legend
    legend = doc.add_paragraph()
    legend.add_run("Legend: ").bold = True
    r1 = legend.add_run("Agreed  ")
    r1.font.color.rgb = RGBColor(0x00, 0x00, 0x00)
    r2 = legend.add_run("Buyer position  ")
    r2.font.color.rgb = RGBColor(0x00, 0x44, 0xCC)
    r3 = legend.add_run("Seller position  ")
    r3.font.color.rgb = RGBColor(0x00, 0x88, 0x00)
    r4 = legend.add_run("Compromise")
    r4.font.color.rgb = RGBColor(0xCC, 0x66, 0x00)

    STATUS_COLOURS = {
        "agreed":      RGBColor(0x00, 0x00, 0x00),
        "buyer_win":   RGBColor(0x00, 0x44, 0xCC),
        "seller_win":  RGBColor(0x00, 0x88, 0x00),
        "compromise":  RGBColor(0xCC, 0x66, 0x00),
    }

    for result in negotiation_results:
        doc.add_heading(f"Clause {result.get('clause_number','?')}: {result.get('clause_title','')}", level=2)
        status  = result.get("status", "agreed")
        colour  = STATUS_COLOURS.get(status, STATUS_COLOURS["agreed"])

        status_para = doc.add_paragraph()
        sr = status_para.add_run(f"[{status.upper().replace('_',' ')}]")
        sr.bold = True
        sr.font.color.rgb = colour

        text_para = doc.add_paragraph()
        tr = text_para.add_run(result.get("agreed_text", ""))
        tr.font.color.rgb = colour

        if result.get("notes"):
            notes_para = doc.add_paragraph()
            nr = notes_para.add_run(f"Note: {result['notes']}")
            nr.italic = True
            nr.font.size = Pt(9)

        doc.add_paragraph("")

    # Signature blocks
    doc.add_heading("Signatures", level=2)
    sig_table = doc.add_table(rows=2, cols=2)
    sig_table.cell(0,0).text = f"For {buyer_name}:"
    sig_table.cell(0,1).text = f"For {seller_name}:"
    sig_table.cell(1,0).text = "\n\nSignature: ________________\nDate: ________________"
    sig_table.cell(1,1).text = "\n\nSignature: ________________\nDate: ________________"

    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()
