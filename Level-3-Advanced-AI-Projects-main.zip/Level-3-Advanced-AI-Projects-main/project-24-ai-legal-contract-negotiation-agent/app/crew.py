"""crew.py — Crew orchestration with cost tracking"""
import os
from crewai import Crew, Process
from langsmith_config import setup_langsmith
from agents import build_negotiation_agents
from tasks import build_negotiation_tasks
from utils.cost_tracker import TokenBudget, BudgetExceededError
from dotenv import load_dotenv

load_dotenv()
setup_langsmith("project-24-contract-negotiation")


def run_negotiation(
    clauses: list[dict],
    buyer_name: str = "Buyer Corp",
    seller_name: str = "Seller Inc",
) -> dict:
    budget = TokenBudget(max_tokens=int(os.getenv("TOKEN_BUDGET",100_000)), model="claude-3-5-sonnet")
    buyer_agent, seller_agent, arbitrator_agent = build_negotiation_agents(buyer_name, seller_name)
    task1, task2, task3 = build_negotiation_tasks(buyer_agent, seller_agent, arbitrator_agent, clauses)

    crew = Crew(
        agents=[buyer_agent, seller_agent, arbitrator_agent],
        tasks=[task1, task2, task3],
        process=Process.sequential,
        verbose=True,
    )

    try:
        with budget:
            result = crew.kickoff()
    except BudgetExceededError as e:
        return {"error": str(e)}

    return {
        "negotiation_result": str(result),
        "token_summary": budget.summary(),
        "clauses_processed": len(clauses),
    }
