"""agents.py — Buyer, Seller, and Arbitrator agent definitions"""
import os
from crewai import Agent
from langchain_anthropic import ChatAnthropic

llm = ChatAnthropic(model="claude-3-5-sonnet-20241022", temperature=0.3,
                    anthropic_api_key=os.getenv("ANTHROPIC_API_KEY"))


def build_negotiation_agents(buyer_company: str = "Buyer Corp",
                              seller_company: str = "Seller Inc"):
    buyer_agent = Agent(
        role="Contract Negotiator (Buyer)",
        goal=f"Negotiate contract clauses in the best interest of {buyer_company}",
        backstory=(
            f"You are a senior legal counsel representing {buyer_company}. "
            "You always seek to minimise liability, maximise termination rights, "
            "protect IP ownership, and secure favourable payment terms. "
            "You are firm but reasonable — you want a deal, not a fight."
        ),
        llm=llm, verbose=True, allow_delegation=False, max_iter=2,
    )

    seller_agent = Agent(
        role="Contract Negotiator (Seller)",
        goal=f"Negotiate contract clauses in the best interest of {seller_company}",
        backstory=(
            f"You are a senior legal counsel representing {seller_company}. "
            "You seek to protect your company's revenue, limit liability, "
            "retain IP rights, and secure upfront payment. "
            "You are professional and pragmatic — a signed deal is the goal."
        ),
        llm=llm, verbose=True, allow_delegation=False, max_iter=2,
    )

    arbitrator_agent = Agent(
        role="Contract Arbitrator",
        goal="Find a fair compromise on each disputed clause and produce the final agreed text",
        backstory=(
            "You are an experienced commercial contracts arbitrator with 20 years of experience. "
            "You review both parties' positions and craft compromise language that is "
            "legally sound, commercially balanced, and acceptable to both sides. "
            "Your output becomes the final binding contract text."
        ),
        llm=llm, verbose=True, allow_delegation=False, max_iter=2,
    )

    return buyer_agent, seller_agent, arbitrator_agent
