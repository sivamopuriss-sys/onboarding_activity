"""tasks.py — Negotiation tasks with Instructor-validated output"""
import instructor
import anthropic
from crewai import Task
from pydantic import BaseModel
from typing import Literal

# Instructor-patched Anthropic client for structured output validation
client = instructor.from_anthropic(anthropic.Anthropic())


class ClausePosition(BaseModel):
    clause_number: int
    clause_title: str
    proposed_text: str
    reasoning: str
    red_lines: list[str]        # Non-negotiable points
    concessions: list[str]      # Points willing to concede


class NegotiationResult(BaseModel):
    clause_number: int
    clause_title: str
    buyer_position: str
    seller_position: str
    agreed_text: str
    status: Literal["agreed", "buyer_win", "seller_win", "compromise"]
    notes: str


def build_negotiation_tasks(buyer_agent, seller_agent, arbitrator_agent, clauses: list[dict]):
    """Build negotiation tasks for each clause."""
    clauses_text = "\n\n".join(
        f"Clause {c['number']}: {c['title']}\n{c['text']}"
        for c in clauses
    )

    task_buyer = Task(
        description=f"""Review the following contract clauses and state your position as the Buyer.
For each clause, provide: your proposed text, your reasoning, your red lines (non-negotiable),
and points you are willing to concede.

Clauses to negotiate:
{clauses_text}

Be specific and clause-by-clause. Reference specific legal risks or commercial impacts.""",
        agent=buyer_agent,
        expected_output="Buyer's position on each clause with proposed text and reasoning",
    )

    task_seller = Task(
        description=f"""Review the following contract clauses and the Buyer's position.
State your position as the Seller for each clause.
Provide: your counter-proposed text, your reasoning, your red lines, and concessions.

Clauses:
{clauses_text}

Respond to the Buyer's position directly — acknowledge any acceptable points and push back on others.""",
        agent=seller_agent,
        expected_output="Seller's counter-position on each clause",
        context=[task_buyer],
    )

    task_arbitrator = Task(
        description=f"""Review both parties' positions and produce a final negotiated text for each clause.
Your output must be the actual contract language — not a summary of positions.
For each clause, produce the final agreed text that both parties can accept.
Mark each clause as: agreed (both sides accepted), buyer_win, seller_win, or compromise.

Be practical. A workable contract is better than a perfect one that neither side will sign.""",
        agent=arbitrator_agent,
        expected_output="Final negotiated contract text for each clause with status",
        context=[task_buyer, task_seller],
    )

    return task_buyer, task_seller, task_arbitrator
