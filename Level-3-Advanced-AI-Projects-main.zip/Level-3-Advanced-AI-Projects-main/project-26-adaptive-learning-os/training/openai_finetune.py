"""openai_finetune.py — OpenAI Fine-tuning API for tutor model"""
import os, json, argparse, wandb
from openai import OpenAI
from dotenv import load_dotenv
load_dotenv()
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

SUBJECTS = ["Machine Learning","Python","Statistics","SQL","Data Structures"]

def prepare(output: str = "data/tutor_qa.jsonl"):
    os.makedirs("data", exist_ok=True)
    examples = [
        {"q":"What is the difference between supervised and unsupervised learning?",
         "a":"Supervised learning uses labelled data — you provide input-output pairs and the model learns the mapping. Unsupervised learning finds patterns in unlabelled data, like clustering similar items without being told what the groups should be."},
        {"q":"Explain gradient descent in simple terms.",
         "a":"Imagine you are on a foggy hill and want to reach the lowest point. Gradient descent takes small steps in the direction that goes downhill most steeply. The model does this with its error — it adjusts weights step by step to reduce mistakes."},
        {"q":"What is a primary key in SQL?",
         "a":"A primary key is a column (or combination of columns) that uniquely identifies each row in a table. No two rows can have the same primary key value, and it cannot be NULL. Think of it like a student ID — every student has a unique one."},
    ]
    with open(output,"w") as f:
        for ex in examples:
            record = {"messages":[
                {"role":"system","content":"You are a patient, encouraging AI tutor. Explain concepts clearly with examples."},
                {"role":"user","content":ex["q"]},
                {"role":"assistant","content":ex["a"]},
            ]}
            f.write(json.dumps(record)+"\n")
    print(f"Dataset saved: {output}")

def train():
    wandb.init(project="adaptive-learning-os", name="openai-tutor-finetune")
    with open("data/tutor_qa.jsonl","rb") as f:
        file_resp = client.files.create(file=f, purpose="fine-tune")
    job = client.fine_tuning.jobs.create(
        training_file=file_resp.id, model="gpt-4o-mini-2024-07-18",
        hyperparameters={"n_epochs":3})
    wandb.config.update({"job_id":job.id})
    with open("data/job_id.txt","w") as f: f.write(job.id)
    print(f"Fine-tuning job: {job.id}")
    wandb.finish()

if __name__=="__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--prepare",action="store_true")
    p.add_argument("--train",  action="store_true")
    args = p.parse_args()
    if args.prepare: prepare()
    elif args.train: train()
