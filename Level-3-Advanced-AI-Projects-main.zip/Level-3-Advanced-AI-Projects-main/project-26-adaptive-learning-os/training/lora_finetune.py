"""lora_finetune.py — LoRA fine-tuning for personalised tutor model"""
import os, wandb
from dotenv import load_dotenv
load_dotenv()

wandb.init(project=os.getenv("WANDB_PROJECT","adaptive-learning-os"),
           name="tutor-lora-finetune", tags=["lora","education","tutor"])

try:
    from transformers import AutoTokenizer, AutoModelForCausalLM, TrainingArguments
    from peft import LoraConfig, get_peft_model, TaskType
    from trl import SFTTrainer
    from datasets import load_dataset
except ImportError:
    print("Install: pip install torch transformers peft trl datasets accelerate")
    raise

BASE_MODEL = "microsoft/phi-2"
OUTPUT_DIR = "./model_weights/tutor-lora"

lora_config = LoraConfig(
    task_type=TaskType.CAUSAL_LM, r=16, lora_alpha=32,
    lora_dropout=0.05, bias="none",
)

training_args = TrainingArguments(
    output_dir=OUTPUT_DIR, num_train_epochs=3,
    per_device_train_batch_size=2, gradient_accumulation_steps=8,
    learning_rate=1e-4, report_to="wandb",
    evaluation_strategy="epoch", fp16=True,
)

print("Prepare your tutor Q&A dataset and configure SFTTrainer.")
print("W&B tracking enabled — view training progress at wandb.ai")
print(f"Model will be saved to: {OUTPUT_DIR}")
wandb.finish()
