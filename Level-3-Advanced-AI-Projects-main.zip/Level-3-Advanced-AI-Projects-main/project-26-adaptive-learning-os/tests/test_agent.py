"""test_agent.py"""
import sys; sys.path.insert(0,".")
from backend.app.db import get_student_level, MILESTONES_ORDER

def test_default_level():
    level = get_student_level("brand-new-student-xyz-12345","Unknown Topic")
    assert level == "easy"

def test_milestones_defined():
    assert isinstance(MILESTONES_ORDER, list)
    assert len(MILESTONES_ORDER) > 0
