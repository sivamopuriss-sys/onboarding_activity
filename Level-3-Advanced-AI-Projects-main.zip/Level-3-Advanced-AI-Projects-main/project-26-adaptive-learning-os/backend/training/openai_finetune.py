"""openai_finetune.py — OpenAI Fine-tuning API for tutor"""
import os, json, argparse, wandb
from openai import OpenAI
from dotenv import load_dotenv
load_dotenv()
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def prepare(output="data/tutor_qa.jsonl"):
    os.makedirs("data",exist_ok=True)
    examples=[
        {"q":"What is supervised learning?","a":"Supervised learning trains a model on labelled data — input-output pairs — so it can predict outputs for new inputs. Examples: spam detection, image classification."},
        {"q":"Explain gradient descent simply.","a":"Gradient descent finds the lowest point of an error function by taking small steps downhill. It adjusts model weights step-by-step to reduce prediction errors."},
    ]
    with open(output,"w") as f:
        for ex in examples:
            f.write(json.dumps({"messages":[
                {"role":"system","content":"You are a patient AI tutor. Explain concepts clearly with examples."},
                {"role":"user","content":ex["q"]},
                {"role":"assistant","content":ex["a"]},
            ]})+"\n")
    print(f"Saved: {output}")

def train():
    wandb.init(project="adaptive-learning-os",name="openai-tutor")
    with open("data/tutor_qa.jsonl","rb") as f:
        fr = client.files.create(file=f, purpose="fine-tune")
    job = client.fine_tuning.jobs.create(training_file=fr.id, model="gpt-4o-mini-2024-07-18")
    with open("data/job_id.txt","w") as f: f.write(job.id)
    print(f"Job: {job.id}")
    wandb.finish()

if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("--prepare",action="store_true")
    p.add_argument("--train",action="store_true")
    args=p.parse_args()
    if args.prepare: prepare()
    elif args.train: train()
