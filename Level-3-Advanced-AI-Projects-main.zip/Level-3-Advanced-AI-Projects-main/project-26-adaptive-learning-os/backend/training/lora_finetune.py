"""lora_finetune.py — LoRA fine-tuning for personalised tutor"""
import os, wandb
from dotenv import load_dotenv
load_dotenv()
wandb.init(project=os.getenv("WANDB_PROJECT","adaptive-learning-os"),
           name="tutor-lora", tags=["lora","education"])
print("Configure your tutor Q&A dataset and run SFTTrainer.")
print("W&B tracking enabled at wandb.ai")
wandb.finish()
