"""rag.py — Pinecone RAG for course content"""
import os
from langchain_openai import OpenAIEmbeddings, ChatOpenAI
from langchain_pinecone import PineconeVectorStore
from langchain.chains import RetrievalQA
from langchain.prompts import PromptTemplate
from dotenv import load_dotenv
load_dotenv()

INDEX_NAME = os.getenv("PINECONE_INDEX","learning-os-materials")
PROMPT     = """You are a patient, encouraging AI tutor at {difficulty} level.
Answer using the course material below. Use examples and step-by-step breakdowns.

Course Material: {context}
Question: {question}
Answer:"""

def get_rag_chain(difficulty: str = "medium"):
    embeddings  = OpenAIEmbeddings(model="text-embedding-3-small")
    vectorstore = PineconeVectorStore(index_name=INDEX_NAME, embedding=embeddings)
    llm         = ChatOpenAI(model=os.getenv("FINE_TUNED_MODEL","gpt-4o-mini"), temperature=0.4)
    prompt      = PromptTemplate(template=PROMPT, input_variables=["context","question","difficulty"])
    return RetrievalQA.from_chain_type(
        llm=llm, chain_type="stuff",
        retriever=vectorstore.as_retriever(search_kwargs={"k":4}),
        return_source_documents=True,
        chain_type_kwargs={"prompt":prompt,"document_variable_name":"context"},
    )
