"""agent.py — LangGraph tutor orchestrator"""
import os
from typing import TypedDict, Annotated, Optional
import operator
from langgraph.graph import StateGraph, END
from langsmith_config import setup_langsmith
from backend.app.rag import get_rag_chain
from backend.app.db import log_session, get_student_level, update_progress
from dotenv import load_dotenv
load_dotenv()
setup_langsmith("project-26-adaptive-learning-os")

class TutorState(TypedDict):
    student_id: str
    topic: str
    question: str
    difficulty: str
    rag_response: str
    final_response: str
    history: Annotated[list, operator.add]

def node_get_difficulty(state): return {"difficulty": get_student_level(state["student_id"], state["topic"])}

def node_rag_retrieve(state):
    chain  = get_rag_chain(state["difficulty"])
    result = chain.invoke({"query":state["question"],"difficulty":state["difficulty"]})
    return {"rag_response": result["result"]}

def node_format_response(state):
    response = state["rag_response"]
    log_session(state["student_id"],state["topic"],state["question"],response,state["difficulty"])
    return {"final_response": response}

def build_tutor_agent():
    g = StateGraph(TutorState)
    g.add_node("get_difficulty",  node_get_difficulty)
    g.add_node("rag_retrieve",    node_rag_retrieve)
    g.add_node("format_response", node_format_response)
    g.set_entry_point("get_difficulty")
    g.add_edge("get_difficulty","rag_retrieve")
    g.add_edge("rag_retrieve","format_response")
    g.add_edge("format_response",END)
    return g.compile()

agent = build_tutor_agent()

def ask_tutor(student_id: str, topic: str, question: str) -> dict:
    result = agent.invoke({"student_id":student_id,"topic":topic,"question":question,
                           "difficulty":"easy","rag_response":"","final_response":"","history":[]})
    return {"response":result["final_response"],"difficulty":result["difficulty"]}
