"""db.py — Session management"""
import os
from datetime import datetime
from sqlalchemy import create_engine, Column, String, Integer, Float, DateTime, Text
from sqlalchemy.orm import declarative_base, sessionmaker
from dotenv import load_dotenv
load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL","sqlite:///./learning_os.db")
engine       = create_engine(DATABASE_URL, connect_args={"check_same_thread":False} if "sqlite" in DATABASE_URL else {})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base         = declarative_base()
MILESTONES_ORDER = ["enrolled","first_session","quiz_passed","module_complete"]

class StudentSession(Base):
    __tablename__ = "student_sessions"
    id           = Column(Integer, primary_key=True, index=True)
    student_id   = Column(String, index=True)
    topic        = Column(String)
    question     = Column(Text)
    response     = Column(Text)
    difficulty   = Column(String)
    created_at   = Column(DateTime, default=datetime.utcnow)

class StudentProgress(Base):
    __tablename__ = "student_progress"
    student_id    = Column(String, primary_key=True)
    topic         = Column(String, primary_key=True)
    sessions_count= Column(Integer, default=0)
    avg_score     = Column(Float, default=0.0)
    current_level = Column(String, default="easy")
    last_active   = Column(DateTime, default=datetime.utcnow)

Base.metadata.create_all(bind=engine)

def get_student_level(student_id: str, topic: str) -> str:
    db = SessionLocal()
    try:
        p = db.query(StudentProgress).filter_by(student_id=student_id, topic=topic).first()
        return p.current_level if p else "easy"
    finally:
        db.close()

def log_session(student_id, topic, question, response, difficulty):
    db = SessionLocal()
    try:
        db.add(StudentSession(student_id=student_id, topic=topic,
                               question=question, response=response, difficulty=difficulty))
        db.commit()
    finally:
        db.close()

def update_progress(student_id: str, topic: str, score: float):
    db = SessionLocal()
    try:
        p = db.query(StudentProgress).filter_by(student_id=student_id, topic=topic).first()
        if not p:
            p = StudentProgress(student_id=student_id, topic=topic)
            db.add(p)
        p.sessions_count += 1
        p.avg_score = (p.avg_score + score) / 2
        if p.avg_score >= 0.8:   p.current_level = "hard"
        elif p.avg_score >= 0.6: p.current_level = "medium"
        else:                     p.current_level = "easy"
        p.last_active = datetime.utcnow()
        db.commit()
    finally:
        db.close()
