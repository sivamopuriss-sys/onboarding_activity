"""api.py — FastAPI endpoints"""
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from backend.app.agent import ask_tutor
from backend.app.db import get_student_level, update_progress

app = FastAPI(title="Adaptive Learning OS")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

class AskRequest(BaseModel):
    student_id: str
    topic: str
    question: str

class ProgressUpdate(BaseModel):
    student_id: str
    topic: str
    quiz_score: float

@app.get("/health")
def health(): return {"status":"ok"}

@app.post("/ask")
def ask(req: AskRequest):
    try: return ask_tutor(req.student_id, req.topic, req.question)
    except Exception as e: raise HTTPException(500, str(e))

@app.get("/progress/{student_id}/{topic}")
def progress(student_id: str, topic: str):
    return {"current_level": get_student_level(student_id, topic)}

@app.post("/update-progress")
def update(req: ProgressUpdate):
    update_progress(req.student_id, req.topic, req.quiz_score)
    return {"updated": True}
