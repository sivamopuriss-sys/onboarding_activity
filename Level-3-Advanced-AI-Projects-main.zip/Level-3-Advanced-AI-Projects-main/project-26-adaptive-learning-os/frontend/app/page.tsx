'use client'
import { useState } from 'react'
const BACKEND = process.env.BACKEND_URL || 'http://localhost:8000'
const TOPICS  = ['Machine Learning','Python','Statistics','Data Structures','SQL']

export default function Dashboard() {
  const [topic, setTopic]       = useState(TOPICS[0])
  const [question, setQuestion] = useState('')
  const [response, setResponse] = useState('')
  const [difficulty, setDiff]   = useState('')
  const [loading, setLoading]   = useState(false)

  async function ask() {
    setLoading(true)
    try {
      const res  = await fetch(`${BACKEND}/ask`, {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({student_id:'student-001', topic, question})})
      const data = await res.json()
      setResponse(data.response); setDiff(data.difficulty)
    } finally { setLoading(false) }
  }

  return (
    <main style={{maxWidth:800,margin:'40px auto',padding:'0 24px',fontFamily:'system-ui'}}>
      <h1>Adaptive Learning OS</h1>
      {difficulty && <p>Current level: <b>{difficulty}</b></p>}
      <select value={topic} onChange={e=>setTopic(e.target.value)} style={{width:'100%',padding:8,marginBottom:12}}>
        {TOPICS.map(t=><option key={t}>{t}</option>)}
      </select>
      <textarea value={question} onChange={e=>setQuestion(e.target.value)} rows={3}
        placeholder="Ask your tutor..." style={{width:'100%',padding:8,marginBottom:12}}/>
      <button onClick={ask} disabled={loading} style={{padding:'10px 24px',background:'#1a237e',color:'white',border:'none',borderRadius:6,cursor:'pointer'}}>
        {loading ? 'Thinking...' : 'Ask Tutor'}
      </button>
      {response && <div style={{marginTop:24,padding:16,background:'#f5f5f5',borderRadius:8}}>
        <b>Tutor ({difficulty}):</b><p style={{whiteSpace:'pre-wrap'}}>{response}</p></div>}
    </main>
  )
}
