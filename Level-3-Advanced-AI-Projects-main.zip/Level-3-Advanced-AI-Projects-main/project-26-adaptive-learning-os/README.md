# Project 26 — Adaptive Learning OS

![Level](https://img.shields.io/badge/Level-Advanced-purple)
![Industry](https://img.shields.io/badge/Industry-Education-blue)
![Stack](https://img.shields.io/badge/Stack-LangGraph%20%7C%20Pinecone%20%7C%20Fine--tuning%20%7C%20Next.js%20%7C%20PostgreSQL-blue)

## Business Problem
Modern EdTech platforms serve all students with identical static content. True adaptive
learning adjusts content difficulty, pacing, and teaching style based on each student's
performance — requiring RAG, fine-tuning, and stateful orchestration working together.

## Project Objective
Full-stack adaptive learning platform combining:
- RAG pipeline over course materials (Pinecone)
- Fine-tuned tutor model (personalised explanations)
- LangGraph orchestrator (tracks difficulty + session state)
- Next.js dashboard (student progress + real-time chat)
- PostgreSQL/SQLite (stores progress, quiz results)
- Deployed: Next.js on Vercel + FastAPI backend on GCP Cloud Run

## System Architecture
```mermaid
graph TD
    A[Student question] --> B[Next.js Frontend]
    B --> C[FastAPI Backend]
    C --> D[LangGraph Tutor Orchestrator]
    D --> E[RAG - Pinecone course materials]
    D --> F[Fine-tuned Tutor Model]
    D --> G[Difficulty Adjuster]
    E --> F
    F --> H[Personalised response]
    H --> I[SQLite/PostgreSQL - log session]
    H --> B
    C --> J[LangSmith - trace all interactions]
```

## Folder Structure
```
project-26-adaptive-learning-os/
├── backend/
│   ├── app/
│   │   ├── agent.py        # LangGraph tutor orchestrator
│   │   ├── rag.py          # Pinecone RAG pipeline
│   │   ├── db.py           # Session management
│   │   └── api.py          # FastAPI endpoints
│   └── training/
│       ├── lora_finetune.py
│       └── openai_finetune.py
├── frontend/
│   ├── app/page.tsx
│   ├── package.json
│   └── next.config.js
├── evaluation/
│   └── langsmith_eval.py
├── infra/
│   ├── Dockerfile
│   ├── cloudbuild.yaml
│   └── service.yaml
├── tests/
│   └── test_agent.py
├── samples/
│   └── sample_course_materials.txt
├── langsmith_config.py
├── .github/workflows/deploy.yml
├── .env.example
├── requirements.txt
└── README.md
```

## Setup

### Backend
```bash
pip install -r requirements.txt && cp .env.example .env
python -c "from backend.app.db import Base, engine; Base.metadata.create_all(engine)"
uvicorn backend.app.api:app --reload
```

### Frontend
```bash
cd frontend && npm install && npm run dev
```

### Deploy
```bash
gcloud builds submit --config infra/cloudbuild.yaml  # Backend
vercel --prod                                         # Frontend
```

## Time Estimate
| Mode | Time |
|---|---|
| Self-paced | 24–32 hours |
| Instructor-guided | 14–18 hours |

---

## Step-by-Step Implementation Guide

This guide walks you through building this project from scratch. Follow each step in order.

---

### Step 1: Project Setup (Backend + Frontend)

```bash
mkdir project-26-adaptive-learning-os
cd project-26-adaptive-learning-os

# Backend
python -m venv venv && source venv/bin/activate
mkdir -p backend/app backend/training evaluation infra tests samples
touch backend/app/agent.py backend/app/rag.py backend/app/db.py backend/app/api.py
touch training/lora_finetune.py training/openai_finetune.py
touch requirements.txt .env.example langsmith_config.py

# Frontend
npx create-next-app@latest frontend --typescript --tailwind --app
cd frontend && npm install
```

`requirements.txt`:
```
langgraph>=0.1.0
langchain>=0.2.0
langchain-openai>=0.1.0
langchain-pinecone>=0.1.0
langsmith>=0.1.0
openai>=1.30.0
torch>=2.2.0
transformers>=4.40.0
peft>=0.10.0
pinecone-client>=3.0.0
sqlalchemy>=2.0.0
fastapi>=0.110.0
uvicorn>=0.29.0
pydantic>=2.0.0
python-dotenv>=1.0.0
pytest>=8.0.0
```

`.env.example`:
```
OPENAI_API_KEY=sk-your-key
PINECONE_API_KEY=your-pinecone-key
PINECONE_INDEX=course-materials
LANGCHAIN_TRACING_V2=true
LANGCHAIN_API_KEY=ls__your-key
LANGCHAIN_PROJECT=project-26-adaptive-learning-os
DATABASE_URL=sqlite:///./learning.db
NEXT_PUBLIC_API_URL=http://localhost:8000
```

---

### Step 2: Understand the Full-Stack Architecture

```
Student asks a question
        ↓
Next.js Frontend (TypeScript)
        ↓ HTTP POST /ask
FastAPI Backend
        ↓
LangGraph Tutor Orchestrator
  ├── Node 1: get_difficulty  → reads student's level from SQLite (Easy/Medium/Hard)
  ├── Node 2: rag_retrieve    → retrieves relevant course material from Pinecone
  └── Node 3: format_response → generates personalised answer, logs session to DB
        ↓
Response returned to Next.js + rendered in chat UI
```

**Why Next.js instead of Streamlit for a production EdTech product?** Streamlit is a rapid prototyping tool — it's synchronous, single-user, and difficult to style professionally. Next.js is a production React framework: it handles concurrent users, supports real-time updates via SSE/WebSocket, allows custom UI components (progress bars, quiz cards, charts), and can be deployed to Vercel's global CDN. For an EdTech product that students use daily, the UX quality that Next.js enables directly impacts engagement and retention.

**Why SQLite for development, PostgreSQL for production?** SQLite requires zero setup and runs as a file — you can start developing immediately. PostgreSQL handles concurrent writes and scales to thousands of students. SQLAlchemy abstracts the difference: `DATABASE_URL=sqlite:///./learning.db` in dev, `DATABASE_URL=postgresql://user:pass@host/db` in production — no code changes required.

---

### Step 3: Build the Pinecone RAG Pipeline (`backend/app/rag.py`)

```python
"""rag.py — Pinecone RAG pipeline for course material retrieval"""
import os
from langchain_openai import OpenAIEmbeddings, ChatOpenAI
from langchain_pinecone import PineconeVectorStore
from langchain.chains import RetrievalQA
from langchain.prompts import PromptTemplate
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import TextLoader
from pinecone import Pinecone, ServerlessSpec
from dotenv import load_dotenv
load_dotenv()

INDEX_NAME = os.getenv("PINECONE_INDEX","course-materials")

PROMPT_TEMPLATE = """\
You are a personalised tutor. Answer the student's question using ONLY the course material below.
Difficulty level: {difficulty} (Easy = simple language, analogies; Hard = technical depth, no simplification)

Course material:
{context}

Student question: {question}

Answer (tailored to {difficulty} level):"""


def _get_vectorstore():
    pc = Pinecone(api_key=os.getenv("PINECONE_API_KEY"))
    if INDEX_NAME not in [i.name for i in pc.list_indexes()]:
        pc.create_index(name=INDEX_NAME, dimension=1536, metric="cosine",
                        spec=ServerlessSpec(cloud="aws", region="us-east-1"))
    embeddings = OpenAIEmbeddings(model="text-embedding-3-small")
    return PineconeVectorStore(index_name=INDEX_NAME, embedding=embeddings)


def ingest_course_materials(source_path: str = "samples/sample_course_materials.txt"):
    """Ingest course materials into Pinecone."""
    docs = TextLoader(source_path).load()
    splitter = RecursiveCharacterTextSplitter(chunk_size=600, chunk_overlap=100)
    chunks = splitter.split_documents(docs)
    vs = _get_vectorstore()
    vs.add_documents(chunks)
    print(f"Ingested {len(chunks)} chunks from {source_path}")


def get_rag_chain(difficulty: str = "easy"):
    """Build a RetrievalQA chain tuned to the student's difficulty level."""
    vs   = _get_vectorstore()
    llm  = ChatOpenAI(model="gpt-4o", temperature=0.2)
    prompt = PromptTemplate(
        template=PROMPT_TEMPLATE,
        input_variables=["context","question","difficulty"],
    )
    chain = RetrievalQA.from_chain_type(
        llm=llm,
        retriever=vs.as_retriever(search_kwargs={"k": 4}),
        return_source_documents=True,
        chain_type_kwargs={"prompt": prompt},
    )
    return chain
```

**Why pass difficulty into the RAG prompt?** The same retrieved course material can be explained at different levels. By injecting the student's current difficulty level into the prompt, GPT-4o tailors its explanation style: Easy uses analogies and simple vocabulary, Hard uses technical terminology and deeper coverage. The retrieval is the same; the explanation adapts to the student.

---

### Step 4: Set Up the Database (`backend/app/db.py`)

```python
"""db.py — SQLAlchemy session management"""
import os
from datetime import datetime
from sqlalchemy import create_engine, Column, String, Float, Integer, DateTime
from sqlalchemy.orm import DeclarativeBase, Session
from dotenv import load_dotenv
load_dotenv()

engine = create_engine(os.getenv("DATABASE_URL","sqlite:///./learning.db"),
                       connect_args={"check_same_thread": False})


class Base(DeclarativeBase):
    pass


class StudentSession(Base):
    __tablename__ = "sessions"
    id         = Column(Integer, primary_key=True, autoincrement=True)
    student_id = Column(String, index=True)
    topic      = Column(String)
    question   = Column(String)
    response   = Column(String)
    difficulty = Column(String, default="easy")
    score      = Column(Float, default=0.0)
    created_at = Column(DateTime, default=datetime.utcnow)


class StudentProgress(Base):
    __tablename__ = "progress"
    student_id     = Column(String, primary_key=True)
    topic          = Column(String, primary_key=True)
    level          = Column(String, default="easy")
    correct_streak = Column(Integer, default=0)
    total_questions= Column(Integer, default=0)
    last_updated   = Column(DateTime, default=datetime.utcnow)


# Create tables on import
Base.metadata.create_all(engine)


def get_student_level(student_id: str, topic: str) -> str:
    with Session(engine) as s:
        prog = s.get(StudentProgress, (student_id, topic))
        if not prog:
            return "easy"
        return prog.level


def log_session(student_id: str, topic: str, question: str,
                response: str, difficulty: str) -> None:
    with Session(engine) as s:
        s.add(StudentSession(student_id=student_id, topic=topic,
                             question=question, response=response, difficulty=difficulty))
        s.commit()


def update_progress(student_id: str, topic: str, correct: bool) -> str:
    """Update student level based on quiz performance. Returns new level."""
    with Session(engine) as s:
        prog = s.get(StudentProgress, (student_id, topic))
        if not prog:
            prog = StudentProgress(student_id=student_id, topic=topic)
            s.add(prog)

        prog.total_questions += 1
        if correct:
            prog.correct_streak += 1
        else:
            prog.correct_streak = 0

        # Level up after 3 consecutive correct answers
        if prog.correct_streak >= 3:
            if prog.level == "easy":   prog.level = "medium"
            elif prog.level == "medium": prog.level = "hard"
            prog.correct_streak = 0

        # Level down after 3 incorrect
        if not correct and prog.total_questions >= 5:
            if prog.level == "hard":   prog.level = "medium"
            elif prog.level == "medium": prog.level = "easy"

        prog.last_updated = datetime.utcnow()
        s.commit()
        return prog.level
```

**Why composite primary key on StudentProgress?** Each student has one progress record per topic (e.g., student "alice" has separate difficulty levels for "Python basics" vs "Machine Learning"). A composite key `(student_id, topic)` enforces this cleanly — no risk of accidentally mixing progress across topics.

---

### Step 5: Build the LangGraph Tutor Orchestrator (`backend/app/agent.py`)

```python
"""agent.py — LangGraph tutor orchestrator"""
import os
from typing import TypedDict, Annotated
import operator
from langgraph.graph import StateGraph, END
from langsmith_config import setup_langsmith
from backend.app.rag import get_rag_chain
from backend.app.db import log_session, get_student_level
from dotenv import load_dotenv
load_dotenv()
setup_langsmith("project-26-adaptive-learning-os")


class TutorState(TypedDict):
    student_id:    str
    topic:         str
    question:      str
    difficulty:    str
    rag_response:  str
    final_response: str
    history:       Annotated[list, operator.add]


def node_get_difficulty(state):
    return {"difficulty": get_student_level(state["student_id"], state["topic"])}


def node_rag_retrieve(state):
    chain  = get_rag_chain(state["difficulty"])
    result = chain.invoke({"query": state["question"], "difficulty": state["difficulty"]})
    return {"rag_response": result["result"]}


def node_format_response(state):
    response = state["rag_response"]
    log_session(state["student_id"], state["topic"], state["question"],
                response, state["difficulty"])
    return {"final_response": response}


def build_tutor_agent():
    g = StateGraph(TutorState)
    g.add_node("get_difficulty",  node_get_difficulty)
    g.add_node("rag_retrieve",    node_rag_retrieve)
    g.add_node("format_response", node_format_response)
    g.set_entry_point("get_difficulty")
    g.add_edge("get_difficulty",  "rag_retrieve")
    g.add_edge("rag_retrieve",    "format_response")
    g.add_edge("format_response", END)
    return g.compile()


agent = build_tutor_agent()


def ask_tutor(student_id: str, topic: str, question: str) -> dict:
    result = agent.invoke({
        "student_id": student_id, "topic": topic, "question": question,
        "difficulty": "easy", "rag_response": "", "final_response": "", "history": [],
    })
    return {"response": result["final_response"], "difficulty": result["difficulty"]}
```

**Why LangGraph over a simple function chain?** Each node in the graph is independently testable, and the graph structure is visualisable — you can render it with `agent.get_graph().draw_mermaid()`. As the tutor evolves (adding quiz generation, spaced repetition scheduling, emotion detection), you add nodes without refactoring the existing flow. A simple function chain becomes hard to maintain and extend as complexity grows.

---

### Step 6: Build the FastAPI Backend (`backend/app/api.py`)

```python
"""api.py — FastAPI backend"""
import os
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from backend.app.agent import ask_tutor
from backend.app.db import update_progress, get_student_level
from backend.app.rag import ingest_course_materials

app = FastAPI(title="Adaptive Learning OS")
app.add_middleware(CORSMiddleware,
    allow_origins=[os.getenv("NEXT_PUBLIC_API_URL","http://localhost:3000")],
    allow_methods=["*"], allow_headers=["*"])


class AskRequest(BaseModel):
    student_id: str
    topic:      str
    question:   str


class QuizResult(BaseModel):
    student_id: str
    topic:      str
    correct:    bool


@app.get("/health")
def health(): return {"status": "ok"}


@app.post("/ask")
def ask(req: AskRequest):
    try:
        return ask_tutor(req.student_id, req.topic, req.question)
    except Exception as e:
        raise HTTPException(500, str(e))


@app.post("/quiz-result")
def submit_quiz_result(req: QuizResult):
    new_level = update_progress(req.student_id, req.topic, req.correct)
    return {"new_difficulty": new_level, "message": f"Level updated to {new_level}"}


@app.get("/progress/{student_id}/{topic}")
def get_progress(student_id: str, topic: str):
    return {"difficulty": get_student_level(student_id, topic)}


@app.post("/ingest")
def ingest(source_path: str = "samples/sample_course_materials.txt"):
    ingest_course_materials(source_path)
    return {"status": "ok"}
```

---

### Step 7: Build the Next.js Frontend (`frontend/app/page.tsx`)

```typescript
'use client';
import { useState } from 'react';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

interface Message { role: 'user' | 'tutor'; content: string; difficulty?: string; }

export default function Home() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [question, setQuestion] = useState('');
  const [topic, setTopic] = useState('Python basics');
  const [loading, setLoading] = useState(false);
  const studentId = 'student-001';  // Replace with auth in production

  const askTutor = async () => {
    if (!question.trim()) return;
    const userMsg: Message = { role: 'user', content: question };
    setMessages(prev => [...prev, userMsg]);
    setQuestion('');
    setLoading(true);

    const resp = await fetch(`${API_URL}/ask`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ student_id: studentId, topic, question }),
    });
    const data = await resp.json();
    setMessages(prev => [...prev,
      { role: 'tutor', content: data.response, difficulty: data.difficulty }]);
    setLoading(false);
  };

  return (
    <main className="max-w-2xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-4">Adaptive Learning Tutor</h1>
      <select value={topic} onChange={e => setTopic(e.target.value)}
              className="border rounded p-2 mb-4 w-full">
        <option>Python basics</option>
        <option>Machine Learning</option>
        <option>Data Structures</option>
      </select>
      <div className="border rounded h-96 overflow-y-auto p-4 mb-4 bg-gray-50">
        {messages.map((m, i) => (
          <div key={i} className={`mb-3 ${m.role === 'user' ? 'text-right' : 'text-left'}`}>
            <span className={`inline-block rounded p-2 max-w-xs ${
              m.role === 'user' ? 'bg-blue-500 text-white' : 'bg-white border'}`}>
              {m.content}
            </span>
            {m.difficulty && <p className="text-xs text-gray-400 mt-1">Level: {m.difficulty}</p>}
          </div>
        ))}
        {loading && <p className="text-gray-400">Tutor is thinking...</p>}
      </div>
      <div className="flex gap-2">
        <input value={question} onChange={e => setQuestion(e.target.value)}
               onKeyDown={e => e.key === 'Enter' && askTutor()}
               placeholder="Ask your question..." className="border rounded p-2 flex-1" />
        <button onClick={askTutor} disabled={loading}
                className="bg-blue-500 text-white rounded px-4 py-2 disabled:opacity-50">
          Ask
        </button>
      </div>
    </main>
  );
}
```

**Why Tailwind CSS?** Tailwind's utility classes produce professional-looking UI with minimal code. A Streamlit equivalent would require 5x more configuration for custom styling. Tailwind also tree-shakes unused classes, so the production CSS bundle is minimal — important for fast page loads on student devices.

---

### Step 8: Run Locally

```bash
# Terminal 1 — ingest course materials and start backend
source venv/bin/activate
python -c "from backend.app.rag import ingest_course_materials; ingest_course_materials()"
uvicorn backend.app.api:app --reload --port 8000

# Terminal 2 — start Next.js frontend
cd frontend && npm run dev
# Open http://localhost:3000
```

---

### Step 9: Deploy (GCP Cloud Run + Vercel)

**Backend:**
```bash
gcloud builds submit --config infra/cloudbuild.yaml
gcloud run deploy adaptive-learning-backend \
  --region us-central1 --memory 2Gi \
  --set-env-vars "PINECONE_API_KEY=...,OPENAI_API_KEY=..."
```

**Frontend:**
```bash
cd frontend
# Set NEXT_PUBLIC_API_URL to your Cloud Run URL
echo "NEXT_PUBLIC_API_URL=https://adaptive-learning-backend-xyz.run.app" > .env.production
vercel --prod
```

**Why split deployment (GCP + Vercel)?** FastAPI runs Python — GCP Cloud Run handles Python containers natively with auto-scaling. Next.js is a Node.js/React app — Vercel is purpose-built for Next.js, offering edge caching and zero-config deployment. Using the right platform for each service is better than forcing both onto one platform.

---

### Step 10: Troubleshooting

| Error | Cause | Fix |
|---|---|---|
| `Pinecone: index not found` | `ingest_course_materials()` not run | Call `POST /ingest` first or run the ingest script |
| `sqlalchemy.exc.OperationalError: no such table` | DB tables not created | Call `Base.metadata.create_all(engine)` at startup — it's in `db.py` |
| CORS error in Next.js | `allow_origins` doesn't include frontend URL | Add `NEXT_PUBLIC_API_URL` to FastAPI CORS middleware |
| `gcloud builds: Dockerfile not found` | `cloudbuild.yaml` references wrong path | Ensure Dockerfile is in the project root, not `infra/` |
| Vercel env vars not loading | `.env.production` not committed or set in Vercel dashboard | Set env vars in Vercel dashboard → Settings → Environment Variables |

---

## Evaluation Rubric

| Criteria | Meets | Exceeds |
|---|---|---|
| **Backend** | FastAPI + LangGraph agent running; `/ask` returns personalised response | Difficulty adapts based on quiz results; sessions logged to DB |
| **RAG** | Pinecone ingestion and retrieval working | Difficulty-aware prompt produces noticeably different explanations at Easy vs Hard |
| **Frontend** | Next.js chat UI functional | Progress indicator shows current difficulty level; topic selector works |
| **Database** | SQLite sessions logged | PostgreSQL config documented; schema supports multiple students/topics |
| **Deployment** | Runs locally | Backend on Cloud Run; frontend on Vercel; environment variables properly separated |

---

## Interview Talking Points

1. **Why full-stack (Next.js + FastAPI) over Streamlit?** — Streamlit is single-user, synchronous, and hard to style. Next.js handles concurrent students, real-time SSE/WebSocket updates, custom UI components, and global CDN delivery via Vercel. For a product students use daily, UX quality directly impacts engagement metrics.

2. **How does the adaptive difficulty algorithm work?** — The LangGraph `get_difficulty` node reads the student's current level from the database. The `update_progress` function promotes after 3 consecutive correct quiz answers and demotes after 3 incorrect in a 5-question window. This is a simplified version of IRT (Item Response Theory) used in real adaptive testing systems.

3. **Why Pinecone namespaces for multiple courses?** — Each course's materials can be stored in a separate Pinecone namespace, enabling filtering by course without maintaining multiple indexes. Retrieval queries filter by namespace — a student asking about "Python basics" retrieves only from the Python materials, not Machine Learning content.

4. **How would you personalise further?** — Add a student profile (learning style: visual/text/example-driven), track which retrieved chunks were helpful (thumbs up/down feedback), and fine-tune the explanation style based on feedback. Long-term: build a per-student knowledge graph tracking what they've mastered vs struggled with.

5. **What's the cost model for 1,000 concurrent students?** — Each question: ~4 Pinecone queries (~$0.0001) + 1 GPT-4o call (~$0.005) = ~$0.005/question. At 10 questions/session × 1,000 students/day = $50/day. Cloud Run auto-scales to handle concurrency; Vercel CDN handles the static frontend at effectively zero cost.

---

## Bonus Extensions

- **Spaced repetition scheduler:** Track when students last studied each topic and schedule review sessions using the SM-2 algorithm — proven to maximise long-term retention.
- **Voice interface:** Add a `/ask-voice` endpoint that accepts audio, transcribes with Whisper, and returns a text-to-speech response — makes the tutor accessible for students who prefer speaking.
- **Collaborative learning:** Allow students to compare their progress with peers on the same topic (anonymised) — social motivation increases completion rates.
- **Fine-tuned tutor model:** Use the logged session data to fine-tune a small model on successful explanation patterns — reduces GPT-4o dependency and cost over time.

