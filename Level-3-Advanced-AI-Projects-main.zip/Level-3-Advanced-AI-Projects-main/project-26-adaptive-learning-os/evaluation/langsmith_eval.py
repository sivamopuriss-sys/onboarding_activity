"""langsmith_eval.py — Tutor quality evaluation"""
from langsmith import Client
client = Client()

def answer_relevance(run, example):
    answer   = str(run.outputs.get("response",""))
    question = str(run.inputs.get("question",""))
    q_words  = set(question.lower().split()) - {"what","is","the","a","an","how","why"}
    a_words  = set(answer.lower().split())
    overlap  = len(q_words & a_words) / len(q_words) if q_words else 0
    return {"key":"answer_relevance","score":min(overlap*2, 1.0)}

print("LangSmith evaluators ready.")
