# Project 27 — Clinical Decision Support System

![Level](https://img.shields.io/badge/Level-Advanced-purple)
![Industry](https://img.shields.io/badge/Industry-Healthcare-red)
![Stack](https://img.shields.io/badge/Stack-LangGraph%20%7C%20RAG%20%7C%20Guardrails%20%7C%20AWS%20Lambda%20%7C%20W%26B-blue)

## Business Problem

Clinicians face significant cognitive overload — they must simultaneously recall thousands of clinical guidelines, drug interaction databases, diagnostic protocols, and differential diagnosis criteria while managing patient consultations. Studies show that diagnostic error contributes to 40,000–80,000 deaths annually in the US alone. A clinical decision support system that processes patient symptoms, retrieves relevant guidelines via RAG, checks drug interactions, and suggests diagnostic steps — while enforcing strict safety guardrails — can reduce cognitive load by 40–60% while maintaining clinical safety standards through mandatory human review.

## Project Objective

Build a LangGraph multi-node CDSS agent that:
- **Processes** patient symptom input with PII detection and jailbreak protection
- **Retrieves** relevant clinical guidelines from a Pinecone RAG knowledge base
- **Checks** drug interactions from a curated drug-drug interaction database
- **Generates** differential diagnosis suggestions with recommended diagnostic steps
- **Enforces** safety guardrails (never provides a final diagnosis, always routes to human review for critical cases)
- **Logs** decision quality metrics to W&B for continuous monitoring
- Deployed as **AWS Lambda + API Gateway** for serverless production operation

## System Architecture

```mermaid
graph TD
    A[Patient symptom input] --> B[FastAPI + Mangum - Lambda]
    B --> C[LangGraph CDSS Agent]
    C --> D[Node 1: Retrieve Clinical Guidelines - Pinecone RAG]
    C --> E[Node 2: Check Drug Interactions - knowledge.py]
    C --> F[Node 3: Generate Differential Diagnosis - GPT-4o]
    C --> G[Node 4: Apply Safety Guardrails]
    C --> H[Node 5: Format Response]
    G --> I{Critical finding / PII / Prescribing language?}
    I -- Yes --> J[Requires Human Review flag]
    I -- No --> H
    H --> K[Structured clinical response + disclaimer]
    B --> L[LangSmith - trace full agent pipeline]
    B --> M[W&B - decision quality metrics]
```

## Folder Structure

```
project-27-clinical-decision-support-system/
├── app/
│   ├── agent.py            # LangGraph StateGraph with 5 nodes
│   ├── rag.py              # Pinecone RAG for clinical guidelines
│   ├── api.py              # FastAPI + Mangum Lambda handler
│   └── knowledge.py        # Drug interaction checker
├── guardrails/
│   └── safety.py           # PII detection, jailbreak filter, grounding check
├── utils/
│   └── cost_tracker.py     # Token budget enforcement
├── evaluation/
│   ├── wandb_eval.py       # W&B decision quality metrics
│   └── clinical_accuracy.py # Evaluation against gold-standard cases
├── infra/
│   ├── Dockerfile
│   └── template.yaml       # AWS SAM template
├── tests/
│   └── test_decision_engine.py
├── samples/
│   ├── sample_patient_case.json    # 3 sample patient cases
│   └── sample_guidelines.txt       # Clinical guidelines for ingestion
├── langsmith_config.py
├── .github/workflows/deploy.yml
├── .env.example
├── requirements.txt
└── README.md
```

## Setup

```bash
pip install -r requirements.txt
cp .env.example .env
# Add your Azure OpenAI, Pinecone, LangSmith, and W&B keys

# 1. Ingest clinical guidelines into Pinecone
python -c "from app.rag import ingest_guidelines; ingest_guidelines('samples/')"

# 2. Start the API locally
uvicorn app.api:app --reload --port 8000

# 3. Test with a sample case
curl -X POST http://localhost:8000/analyze \
  -H "Content-Type: application/json" \
  -d @samples/sample_patient_case.json

# Deploy to AWS Lambda
cd infra && sam build && sam deploy --guided
```

## Observability

- **LangSmith:** traces every node in the LangGraph pipeline per patient case
- **W&B:** logs decision quality metrics (differential count, guardrail trigger rate, human review rate)
- Set `LANGCHAIN_TRACING_V2=true`, `LANGCHAIN_API_KEY`, `WANDB_API_KEY` in `.env`

## Key Concepts

- LangGraph StateGraph with sequential clinical reasoning nodes
- Pinecone RAG for grounded guideline retrieval
- Drug interaction checking with partial-match lookups
- Multi-layer guardrails: PII detection, jailbreak filter, output grounding check
- Mandatory human review routing for critical cases
- AWS Lambda + Mangum for serverless production deployment
- Azure OpenAI for HIPAA-aligned LLM access

## Time Estimate

| Mode | Time |
|---|---|
| Self-paced | 22–28 hours |
| Instructor-guided | 12–16 hours |

---

## Step-by-Step Implementation Guide

This guide walks you through building this project from scratch. Follow each step in order.

---

### Step 1: Project Setup

```bash
mkdir project-27-clinical-decision-support-system
cd project-27-clinical-decision-support-system
python -m venv venv && source venv/bin/activate
mkdir -p app guardrails utils evaluation infra tests samples
touch app/agent.py app/rag.py app/api.py app/knowledge.py
touch guardrails/safety.py guardrails/__init__.py
touch utils/cost_tracker.py utils/__init__.py
touch requirements.txt .env.example langsmith_config.py
```

`requirements.txt`:
```
langgraph>=0.1.0
langchain>=0.2.0
langchain-openai>=0.1.0
langchain-community>=0.2.0
langchain-pinecone>=0.1.0
langsmith>=0.1.0
openai>=1.30.0
pinecone-client>=3.0.0
pymupdf>=1.23.0
fastapi>=0.110.0
uvicorn>=0.29.0
mangum>=0.17.0
pydantic>=2.0.0
wandb>=0.17.0
python-dotenv>=1.0.0
pytest>=8.0.0
tiktoken>=0.7.0
```

`.env.example`:
```
AZURE_OPENAI_API_KEY=your-azure-openai-key
AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/
AZURE_OPENAI_DEPLOYMENT=gpt-4o
AZURE_OPENAI_API_VERSION=2024-02-01
PINECONE_API_KEY=your-pinecone-key
PINECONE_INDEX=clinical-guidelines
LANGCHAIN_TRACING_V2=true
LANGCHAIN_API_KEY=ls__your-langsmith-key
LANGCHAIN_PROJECT=project-27-clinical-decision-support
WANDB_API_KEY=your-wandb-key
WANDB_PROJECT=clinical-decision-support
ADMIN_KEY=your-admin-secret-key
```

---

### Step 2: Understand the Safety-First Architecture

Clinical AI operates in a high-stakes domain where errors can harm patients. The architecture follows a principle of **defence in depth**: multiple independent safety layers, each catching different failure modes.

```
Input layer:   Jailbreak detection → block prompt injection attempts
               PII detection      → strip patient identifiable information

Agent layer:   RAG grounding      → answers grounded in clinical guidelines
               Drug interaction   → checked against known interaction database
               Differential only  → never a definitive diagnosis

Output layer:  Definitive language filter → blocks "the diagnosis is..."
               Prescribing language filter → blocks "prescribe X mg of..."
               Grounding check    → flags responses not supported by retrieved context
               Mandatory disclaimer → always appended

Routing layer: Human review flag  → set on any critical finding, drug interaction,
                                    or guardrail trigger
```

**Why this matters:** A single LLM call to GPT-4o with a clinical prompt has ~5–10% hallucination rate on medical questions. With 1,000 queries/day, that's 50–100 potentially dangerous responses. Layered guardrails reduce this to near zero for the most dangerous failure modes (definitive diagnoses, prescribing recommendations).

---

### Step 3: Build the Drug Interaction Checker (`app/knowledge.py`)

```python
"""knowledge.py — Drug interaction checker"""
from __future__ import annotations

DRUG_INTERACTIONS: dict[frozenset, str] = {
    frozenset({"warfarin", "aspirin"}):
        "HIGH RISK: Warfarin + Aspirin significantly increases bleeding risk. Monitor INR closely.",
    frozenset({"ssri", "maoi"}):
        "CRITICAL: SSRIs + MAOIs can cause serotonin syndrome. Contraindicated — 14-day washout required.",
    frozenset({"fluoxetine", "tramadol"}):
        "HIGH RISK: Fluoxetine inhibits CYP2D6, increasing tramadol levels. Risk of serotonin syndrome.",
    frozenset({"metformin", "contrast dye"}):
        "CAUTION: Metformin should be withheld 48h before/after iodinated contrast (lactic acidosis risk).",
    frozenset({"digoxin", "amiodarone"}):
        "HIGH RISK: Amiodarone doubles digoxin plasma levels. Reduce digoxin dose 50% and monitor.",
    frozenset({"simvastatin", "clarithromycin"}):
        "HIGH RISK: Clarithromycin inhibits CYP3A4 — simvastatin levels increase 10-fold. Risk of rhabdomyolysis.",
    frozenset({"lithium", "nsaid"}):
        "HIGH RISK: NSAIDs reduce renal lithium clearance. Monitor lithium levels every 5 days.",
    frozenset({"clopidogrel", "omeprazole"}):
        "MODERATE: Omeprazole inhibits CYP2C19, reducing clopidogrel's active metabolite by ~45%.",
}


def check_interactions(medications: list[str]) -> list[str]:
    """Check a list of medication names for known drug-drug interactions."""
    warnings = []
    normalised = [m.strip().lower() for m in medications]
    for i, drug_a in enumerate(normalised):
        for drug_b in normalised[i + 1:]:
            key = frozenset({drug_a, drug_b})
            if key in DRUG_INTERACTIONS:
                warnings.append(f"⚠ Interaction ({drug_a} + {drug_b}): {DRUG_INTERACTIONS[key]}")
            else:
                # Partial match for "Warfarin 5mg" → "warfarin"
                for pair, warning in DRUG_INTERACTIONS.items():
                    drugs = list(pair)
                    if (any(drug_a.startswith(d) or d in drug_a for d in drugs) and
                            any(drug_b.startswith(d) or d in drug_b for d in drugs)):
                        warnings.append(f"⚠ Possible interaction ({drug_a} + {drug_b}): {warning}")
                        break
    return warnings
```

**Why a local dict instead of an API?** Drug interaction APIs (DrugBank, RxNorm) require subscriptions and add network latency. For demonstration and offline operation, a curated local dict covers the most clinically significant interactions. In production, replace with a real-time API call wrapped in a circuit breaker for reliability.

---

### Step 4: Build the Pinecone RAG Pipeline (`app/rag.py`)

```python
"""rag.py — Pinecone RAG for clinical guideline retrieval"""
import os
from pathlib import Path
from langchain_openai import AzureOpenAIEmbeddings
from langchain_community.vectorstores import Pinecone as LangchainPinecone
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import TextLoader, PyMuPDFLoader
from pinecone import Pinecone, ServerlessSpec
from dotenv import load_dotenv
load_dotenv()

INDEX_NAME = os.getenv("PINECONE_INDEX","clinical-guidelines")


def _get_embeddings():
    return AzureOpenAIEmbeddings(
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
        azure_deployment="text-embedding-3-small",
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION","2024-02-01"),
    )


def ingest_guidelines(source_dir: str = "samples/") -> int:
    """Ingest .txt or .pdf clinical guideline files into Pinecone."""
    docs = []
    for path in Path(source_dir).rglob("*"):
        if path.suffix.lower() == ".pdf":
            docs.extend(PyMuPDFLoader(str(path)).load())
        elif path.suffix.lower() == ".txt":
            docs.extend(TextLoader(str(path)).load())
    if not docs:
        raise FileNotFoundError(f"No .txt or .pdf files found in {source_dir}")

    splitter = RecursiveCharacterTextSplitter(chunk_size=800, chunk_overlap=150)
    chunks   = splitter.split_documents(docs)
    embeddings = _get_embeddings()

    pc = Pinecone(api_key=os.getenv("PINECONE_API_KEY"))
    if INDEX_NAME not in [i.name for i in pc.list_indexes()]:
        pc.create_index(name=INDEX_NAME, dimension=1536, metric="cosine",
                        spec=ServerlessSpec(cloud="aws", region="us-east-1"))

    LangchainPinecone.from_documents(chunks, embeddings, index_name=INDEX_NAME)
    print(f"Indexed {len(chunks)} chunks into '{INDEX_NAME}'")
    return len(chunks)


def retrieve_guidelines(symptoms: str, k: int = 5) -> list[dict]:
    """Retrieve top-k most relevant guidelines for the given symptoms."""
    embeddings  = _get_embeddings()
    vectorstore = LangchainPinecone.from_existing_index(INDEX_NAME, embeddings)
    results     = vectorstore.similarity_search_with_score(symptoms, k=k)
    return [{"content": doc.page_content,
             "source":  doc.metadata.get("source","Unknown"),
             "score":   round(float(score),4)} for doc, score in results]
```

**Why chunk size 800 with overlap 150?** Clinical guidelines have dense, structured paragraphs. At 800 characters, a chunk typically contains one complete clinical protocol step — enough context for meaningful retrieval without diluting the signal with adjacent topics. The 150-character overlap ensures protocol steps that span a paragraph boundary appear in at least one complete chunk.

---

### Step 5: Build the LangGraph Agent (`app/agent.py`)

The agent pipeline is defined as a state machine with five sequential nodes. See `app/agent.py` for the full implementation. Key design decisions:

**State schema (`PatientState`):**
```python
class PatientState(TypedDict):
    symptoms:              str
    patient_history:       str
    current_medications:   list[str]
    retrieved_guidelines:  list[dict]
    drug_interaction_warnings: list[str]
    differential_diagnosis: str
    guardrail_flags:       Annotated[list[str], add]  # Accumulates across nodes
    requires_human_review: bool
    final_response:        str
```

**Node responsibilities:**
1. `retrieve_guidelines` — sanitises input (PII strip, jailbreak check), calls Pinecone
2. `check_drug_interactions` — calls `knowledge.check_interactions()` on current medications
3. `generate_differential` — GPT-4o generates differentials from guidelines + drug warnings
4. `apply_guardrails` — checks for definitive language, prescribing language, and grounding
5. `format_response` — assembles final response with drug warnings, guardrail flags, and disclaimer

**Why `Annotated[list[str], add]` for guardrail_flags?** LangGraph's `Annotated` with `operator.add` means each node can *append* to the list rather than replacing it. The guardrails node can add multiple flags without overwriting flags that might be set by earlier nodes. Without this, only the last node's flags would survive.

---

### Step 6: Build the FastAPI Handler (`app/api.py`)

The API exposes three endpoints. See `app/api.py` for the full implementation:

- `POST /analyze` — accepts `PatientInput` (symptoms, patient_history, current_medications), returns `ClinicalResponse`
- `POST /ingest` — admin endpoint to ingest new guidelines (requires `X-Admin-Key` header)
- `GET /health` — returns service status

**Why Mangum?** Mangum is an ASGI adapter that makes FastAPI work as an AWS Lambda handler. The `handler = Mangum(app)` line at the bottom of `api.py` is the entry point referenced in `template.yaml`. This means the same FastAPI app can run locally with uvicorn and on Lambda with Mangum — zero code changes.

---

### Step 7: Run Locally and Test

```bash
# Step 1: Ingest sample guidelines
curl -X POST http://localhost:8000/ingest \
  -H "X-Admin-Key: your-admin-key" \
  -d '{"source_dir": "samples/"}'

# Step 2: Test with CASE-001 (chest pain — should trigger human review)
curl -X POST http://localhost:8000/analyze \
  -H "Content-Type: application/json" \
  -d '{
    "symptoms": "Chest pain radiating to left arm, diaphoresis, onset 45 minutes ago",
    "patient_history": "72-year-old male, hypertension, previous NSTEMI",
    "current_medications": ["Aspirin 75mg", "Warfarin 5mg"]
  }'
```

**Expected response:**
- `requires_human_review: true` (Aspirin + Warfarin interaction detected)
- `guardrail_flags` includes drug interaction warning
- Disclaimer appended to `final_response`
- 3–5 differentials listed (ACS, NSTEMI, unstable angina...)

Run tests:
```bash
pytest tests/test_decision_engine.py -v
```

---

### Step 8: Deploy to AWS Lambda

```bash
cd infra
sam build
sam deploy --guided
# Stack name: clinical-decision-support
# Region: us-east-1
# Confirm changes: Y
```

Set environment variables in the Lambda console (or via `template.yaml`):
```
AZURE_OPENAI_API_KEY=...
AZURE_OPENAI_ENDPOINT=...
PINECONE_API_KEY=...
LANGCHAIN_API_KEY=...
WANDB_API_KEY=...
ADMIN_KEY=...
```

**Why Azure OpenAI instead of direct OpenAI for Lambda?** Azure OpenAI offers a Business Associate Agreement (BAA) for HIPAA compliance — required for systems that process Protected Health Information (PHI). Direct OpenAI API does not offer a BAA. For any production clinical system handling real patient data, Azure OpenAI (or another HIPAA-eligible provider) is mandatory.

---

### Step 9: Monitor with W&B

```python
# evaluation/wandb_eval.py
import wandb, json

wandb.init(project="clinical-decision-support")

def log_case_result(case_id: str, result: dict):
    wandb.log({
        "case_id":              case_id,
        "requires_human_review": int(result["requires_human_review"]),
        "guardrail_flags_count": len(result["guardrail_flags"]),
        "differentials_count":   result["differentials_count"],
        "has_drug_interaction":  any("interaction" in f.lower()
                                     for f in result["guardrail_flags"]),
    })
```

Key metrics to monitor:
- **Human review rate** — what % of cases trigger mandatory review? (target: >95% of critical cases)
- **Guardrail trigger rate** — how often do safety rails fire? (high rate = model trying to diagnose; tune the prompt)
- **Differential count** — 3–5 is ideal; <2 suggests insufficient retrieval; >8 suggests unfocused output

---

### Step 10: Troubleshooting

| Error | Cause | Fix |
|---|---|---|
| `Pinecone: index not found` | `ingest_guidelines()` not run | `curl -X POST /ingest` or run `python -c "from app.rag import ingest_guidelines; ingest_guidelines()"` |
| `JailbreakAttemptError` in tests | Test input contains keywords like "ignore instructions" | Sanitise test inputs; the guardrail is working correctly |
| `requires_human_review` always True | Drug interaction warnings always trigger review | Expected behaviour — any detected interaction requires clinician review |
| `AzureOpenAI: 404 deployment not found` | `AZURE_OPENAI_DEPLOYMENT` env var wrong | Match exactly to your Azure deployment name in Azure AI Studio |
| Lambda timeout | Agent pipeline takes >30s | Increase Lambda timeout to 60s in `template.yaml` |
| `mangum: handler not found` | Handler path in `template.yaml` incorrect | Ensure `Handler: app.api.handler` and `handler = Mangum(app)` in `api.py` |
| W&B metrics not appearing | `WANDB_API_KEY` not set | Run `wandb login` locally or set env var in Lambda |

---

## Evaluation Rubric

| Criteria | Meets | Exceeds |
|---|---|---|
| **Functionality** | All 5 nodes run; differentials generated for sample cases | Drug interactions correctly detected; human review correctly triggered |
| **Guardrails** | PII detection and jailbreak filter implemented | Output grounding check working; definitive/prescribing language blocked |
| **RAG** | Pinecone ingestion and retrieval working | Retrieved guidelines visible in response; grounding check uses them |
| **Deployment** | Runs locally with uvicorn | Deployed to Lambda; Mangum adapter working; SAM template complete |
| **Observability** | LangSmith traces per case | W&B metrics logged; human review rate monitored |

---

## Interview Talking Points

1. **How do the guardrails work?** — Four layers: (1) Input: jailbreak pattern matching + PII regex redaction. (2) Generation: GPT-4o prompt explicitly forbids diagnoses and prescribing language. (3) Output: post-generation regex check for definitive/prescribing language triggers `requires_human_review=True`. (4) Grounding: word-overlap check between response and retrieved context flags potential hallucination.

2. **Why is a definitive diagnosis prohibited?** — Differential diagnosis (listing possibilities) is within AI's appropriate scope — it assists the clinician's reasoning. A definitive diagnosis is a clinical judgment that requires physical examination, lab results, and clinical experience that an AI cannot replicate. Generating false certainty could cause a patient to refuse further investigation.

3. **Why Azure OpenAI over direct OpenAI for production?** — Azure OpenAI provides a BAA (Business Associate Agreement) required for HIPAA compliance. Patient symptom data constitutes PHI (Protected Health Information) under HIPAA. Any cloud service that processes PHI must be covered by a BAA. Direct OpenAI's standard terms do not provide this.

4. **How would you evaluate CDSS quality at scale?** — Create a gold-standard test set of 50 patient cases with expert-validated differential diagnoses. Use GPT-4o as a judge to score completeness (all key differentials listed) and accuracy (top differential is clinically appropriate). Track these scores in W&B across model/prompt versions. Also track false negative rate for critical findings (these cause harm).

5. **What regulatory approval would this need?** — In the US, a CDSS that influences clinical decisions requires FDA clearance as a Software as a Medical Device (SaMD) under the AI/ML-Based SaMD Action Plan. The specific pathway depends on risk class. This project is intended as educational demonstration — real production deployment requires extensive regulatory validation.

---

## Bonus Extensions

- **Multi-modal input:** Accept patient photos (skin lesions, X-ray images) alongside symptoms using GPT-4o Vision — expands diagnostic scope significantly.
- **EHR integration:** Replace the JSON input with HL7 FHIR resources (`Patient`, `Condition`, `MedicationStatement`) for native EHR system compatibility.
- **Explainability report:** Generate a structured explanation of which guideline supported each differential — creates an audit trail for clinicians and regulators.
- **Feedback loop:** Allow clinicians to rate the quality of each differential (1–5 stars) — log ratings to W&B and use them to identify which guideline chunks are most valuable.
