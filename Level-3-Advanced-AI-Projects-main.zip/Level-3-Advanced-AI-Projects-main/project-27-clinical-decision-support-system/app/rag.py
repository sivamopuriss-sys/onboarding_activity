"""
rag.py — Pinecone RAG pipeline for clinical guideline retrieval.

Ingests clinical guideline documents into Pinecone and retrieves the
most relevant guidelines for a given set of patient symptoms.
"""

import os
from pathlib import Path
from langchain_openai import AzureOpenAIEmbeddings
from langchain_community.vectorstores import Pinecone as LangchainPinecone
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import TextLoader, PyMuPDFLoader
from pinecone import Pinecone, ServerlessSpec
from dotenv import load_dotenv

load_dotenv()

INDEX_NAME    = os.getenv("PINECONE_INDEX", "clinical-guidelines")
CHUNK_SIZE    = 800
CHUNK_OVERLAP = 150
EMBED_MODEL   = "text-embedding-3-small"


def _get_embeddings():
    return AzureOpenAIEmbeddings(
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
        azure_deployment="text-embedding-3-small",
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-01"),
    )


def _get_pinecone_index():
    pc = Pinecone(api_key=os.getenv("PINECONE_API_KEY"))
    if INDEX_NAME not in [idx.name for idx in pc.list_indexes()]:
        pc.create_index(
            name=INDEX_NAME,
            dimension=1536,
            metric="cosine",
            spec=ServerlessSpec(cloud="aws", region="us-east-1"),
        )
    return pc.Index(INDEX_NAME)


def ingest_guidelines(source_dir: str = "samples/") -> int:
    """
    Ingest clinical guideline documents into Pinecone.

    Supports .txt and .pdf files. Chunks documents, embeds them, and
    upserts to the Pinecone index. Returns the number of chunks indexed.

    Usage:
        python -c "from app.rag import ingest_guidelines; ingest_guidelines('samples/')"
    """
    docs = []
    for path in Path(source_dir).rglob("*"):
        if path.suffix.lower() == ".pdf":
            docs.extend(PyMuPDFLoader(str(path)).load())
        elif path.suffix.lower() == ".txt":
            docs.extend(TextLoader(str(path)).load())

    if not docs:
        raise FileNotFoundError(f"No .txt or .pdf files found in {source_dir}")

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=CHUNK_SIZE,
        chunk_overlap=CHUNK_OVERLAP,
        separators=["\n\n", "\n", ". ", " ", ""],
    )
    chunks = splitter.split_documents(docs)
    print(f"Ingesting {len(chunks)} chunks from {len(docs)} document pages...")

    embeddings = _get_embeddings()
    LangchainPinecone.from_documents(
        documents=chunks,
        embedding=embeddings,
        index_name=INDEX_NAME,
    )
    print(f"Indexed {len(chunks)} chunks into Pinecone index '{INDEX_NAME}'")
    return len(chunks)


def retrieve_guidelines(symptoms: str, k: int = 5) -> list[dict]:
    """
    Retrieve the top-k most relevant clinical guidelines for the given symptoms.

    Args:
        symptoms: Patient symptom description string.
        k: Number of guideline chunks to retrieve.

    Returns:
        List of dicts with keys: 'content', 'source', 'score'.
    """
    embeddings = _get_embeddings()
    vectorstore = LangchainPinecone.from_existing_index(
        index_name=INDEX_NAME,
        embedding=embeddings,
    )
    results = vectorstore.similarity_search_with_score(symptoms, k=k)
    return [
        {
            "content": doc.page_content,
            "source":  doc.metadata.get("source", "Unknown guideline"),
            "score":   round(float(score), 4),
        }
        for doc, score in results
    ]


if __name__ == "__main__":
    # Quick test
    ingest_guidelines("samples/")
    hits = retrieve_guidelines("chest pain, shortness of breath, diaphoresis")
    for h in hits:
        print(f"[{h['score']:.3f}] {h['source']}\n{h['content'][:120]}...\n")
