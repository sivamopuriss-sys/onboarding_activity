"""
knowledge.py — Drug interaction checker using a curated interaction dictionary.

In production this would call a drug interaction API (e.g., RxNorm, DrugBank).
For this project we use a static dictionary to demonstrate the pattern without
requiring a third-party API subscription.
"""

from __future__ import annotations

# ── Interaction database ──────────────────────────────────────────────────────
# Key: frozenset of two lowercase drug names
# Value: clinical warning string
DRUG_INTERACTIONS: dict[frozenset, str] = {
    frozenset({"warfarin", "aspirin"}):
        "HIGH RISK: Warfarin + Aspirin significantly increases bleeding risk. "
        "Monitor INR closely. Consider PPI prophylaxis.",
    frozenset({"warfarin", "ibuprofen"}):
        "HIGH RISK: NSAIDs (ibuprofen) can displace warfarin from protein binding, "
        "elevating INR and haemorrhage risk.",
    frozenset({"ssri", "maoi"}):
        "CRITICAL: SSRIs + MAOIs can cause serotonin syndrome (hyperthermia, "
        "rigidity, clonus). Contraindicated — allow 14-day washout.",
    frozenset({"fluoxetine", "tramadol"}):
        "HIGH RISK: Fluoxetine inhibits CYP2D6, increasing tramadol plasma levels "
        "and risk of serotonin syndrome and seizure.",
    frozenset({"metformin", "contrast dye"}):
        "CAUTION: Metformin should be withheld 48 hours before and after iodinated "
        "contrast due to risk of contrast-induced nephropathy and lactic acidosis.",
    frozenset({"digoxin", "amiodarone"}):
        "HIGH RISK: Amiodarone inhibits P-glycoprotein, doubling digoxin plasma "
        "levels. Reduce digoxin dose by 50% and monitor levels.",
    frozenset({"simvastatin", "clarithromycin"}):
        "HIGH RISK: Clarithromycin inhibits CYP3A4, increasing simvastatin levels "
        "up to 10-fold. Risk of rhabdomyolysis. Switch to a non-CYP3A4 statin.",
    frozenset({"lithium", "nsaid"}):
        "HIGH RISK: NSAIDs reduce renal lithium clearance, raising plasma levels "
        "and risk of toxicity. Monitor lithium levels every 5 days.",
    frozenset({"ciprofloxacin", "antacid"}):
        "MODERATE: Divalent cations (Mg, Al, Ca) in antacids chelate ciprofloxacin, "
        "reducing absorption by up to 50%. Separate doses by 2 hours.",
    frozenset({"clopidogrel", "omeprazole"}):
        "MODERATE: Omeprazole inhibits CYP2C19, reducing clopidogrel's active "
        "metabolite by ~45%. Consider pantoprazole as an alternative PPI.",
}


def check_interactions(medications: list[str]) -> list[str]:
    """
    Check a list of medication names for known drug-drug interactions.

    Args:
        medications: List of medication names (case-insensitive).

    Returns:
        List of interaction warning strings. Empty list if no interactions found.
    """
    warnings: list[str] = []
    normalised = [m.strip().lower() for m in medications]

    for i, drug_a in enumerate(normalised):
        for drug_b in normalised[i + 1:]:
            key = frozenset({drug_a, drug_b})
            if key in DRUG_INTERACTIONS:
                warnings.append(
                    f"Interaction ({drug_a} + {drug_b}): {DRUG_INTERACTIONS[key]}"
                )
            # Partial-match check (e.g. "ibuprofen 400mg" matches "ibuprofen")
            else:
                for stored_pair, warning in DRUG_INTERACTIONS.items():
                    drugs_in_pair = list(stored_pair)
                    if any(drug_a.startswith(d) or d in drug_a for d in drugs_in_pair) and \
                       any(drug_b.startswith(d) or d in drug_b for d in drugs_in_pair):
                        warnings.append(
                            f"Possible interaction ({drug_a} + {drug_b}): {warning}"
                        )
                        break

    return warnings


if __name__ == "__main__":
    test_meds = ["Warfarin 5mg", "Aspirin 75mg", "Omeprazole 20mg"]
    results = check_interactions(test_meds)
    for w in results:
        print(w)
