"""
api.py — FastAPI endpoints for the Clinical Decision Support System.

Deployed as:
  - Local: uvicorn app.api:app --reload --port 8000
  - AWS Lambda: Mangum wraps the FastAPI app as a Lambda handler

Endpoints:
  POST /analyze   — run the LangGraph CDSS agent
  POST /ingest    — ingest guidelines into Pinecone (admin only)
  GET  /health    — health check
"""

import os
import logging
from fastapi import FastAPI, HTTPException, Header
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from mangum import Mangum
from dotenv import load_dotenv

from app.agent import run_analysis, get_agent
from app.rag import ingest_guidelines

load_dotenv()
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="Clinical Decision Support System",
    description="LangGraph-based CDSS agent with RAG, drug interaction checking, and safety guardrails.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Request / Response Models ─────────────────────────────────────────────────

class PatientInput(BaseModel):
    symptoms:            str  = Field(..., min_length=10, max_length=2000,
                                      example="Chest pain radiating to left arm, diaphoresis, shortness of breath. Onset 30 minutes ago.")
    patient_history:     str  = Field(default="", max_length=2000,
                                      example="68-year-old male. Hypertension, type 2 diabetes. Current smoker.")
    current_medications: list[str] = Field(default_factory=list,
                                           example=["Aspirin 75mg", "Metformin 500mg", "Amlodipine 5mg"])


class ClinicalResponse(BaseModel):
    final_response:        str
    requires_human_review: bool
    guardrail_flags:       list[str]
    differentials_count:   int


class IngestRequest(BaseModel):
    source_dir: str = Field(default="samples/",
                            description="Directory containing .txt or .pdf guideline files")


# ── Startup ───────────────────────────────────────────────────────────────────

@app.on_event("startup")
def startup():
    """Pre-warm the LangGraph agent to avoid cold-start latency on first request."""
    try:
        get_agent()
        logger.info("LangGraph CDSS agent loaded successfully.")
    except Exception as e:
        logger.warning(f"Agent pre-warm failed (Pinecone index may be empty): {e}")


# ── Endpoints ─────────────────────────────────────────────────────────────────

@app.get("/health")
def health():
    return {"status": "ok", "service": "Clinical Decision Support System"}


@app.post("/analyze", response_model=ClinicalResponse)
def analyze(patient: PatientInput):
    """
    Run the CDSS agent on a patient case.

    The agent:
    1. Retrieves relevant clinical guidelines (RAG)
    2. Checks drug interactions
    3. Generates differential diagnoses
    4. Applies safety guardrails
    5. Returns a structured clinical response
    """
    try:
        result = run_analysis(
            symptoms=patient.symptoms,
            patient_history=patient.patient_history,
            current_medications=patient.current_medications,
        )
        return ClinicalResponse(**result)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Agent error: {e}", exc_info=True)
        raise HTTPException(
            status_code=503,
            detail="CDSS agent unavailable. Ensure Pinecone index is populated (POST /ingest)."
        )


@app.post("/ingest")
def ingest(req: IngestRequest, x_admin_key: str = Header(default="")):
    """
    Admin endpoint: ingest clinical guideline documents into Pinecone.

    Requires X-Admin-Key header matching ADMIN_KEY environment variable.
    """
    expected_key = os.getenv("ADMIN_KEY", "")
    if expected_key and x_admin_key != expected_key:
        raise HTTPException(status_code=403, detail="Invalid admin key")
    try:
        count = ingest_guidelines(req.source_dir)
        return {"status": "ok", "chunks_indexed": count, "source_dir": req.source_dir}
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Ingestion failed: {e}")


# ── AWS Lambda handler ────────────────────────────────────────────────────────
# Mangum wraps FastAPI for AWS Lambda + API Gateway.
# Import and use `handler` in template.yaml Handler field.
handler = Mangum(app, lifespan="off")
