"""wandb_eval.py — Before/after clinical accuracy comparison"""
import wandb

def log_comparison(base_results, ft_results, test_cases):
    wandb.init(project="clinical-decision-support", name="before-after-comparison")
    table = wandb.Table(
        columns=["Case","Base Top-1","FT Top-1","Base Recall@3","FT Recall@3"],
        data=[[c["presentation"][:50]+"...",b["top_1_accuracy"],f["top_1_accuracy"],
               b["recall_at_3"],f["recall_at_3"]]
              for c,b,f in zip(test_cases,base_results,ft_results)])
    wandb.log({"clinical_accuracy_comparison": table})
    wandb.finish()
    print("W&B comparison logged.")
