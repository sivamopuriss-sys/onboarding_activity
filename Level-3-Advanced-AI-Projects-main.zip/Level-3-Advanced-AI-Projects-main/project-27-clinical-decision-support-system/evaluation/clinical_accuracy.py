"""clinical_accuracy.py — Diagnostic accuracy evaluation"""

def evaluate_differentials(predicted: list, gold_standard: list) -> dict:
    pred_lower = [d.lower() for d in predicted]
    gold_lower = [d.lower() for d in gold_standard]
    top1 = gold_lower[0] in pred_lower[0] if predicted and gold_lower else False
    hits = sum(1 for g in gold_lower if any(g in p for p in pred_lower[:3]))
    return {
        "top_1_accuracy": 1.0 if top1 else 0.0,
        "recall_at_3":    hits / len(gold_lower) if gold_lower else 0.0,
        "gold_diagnoses": gold_standard,
        "predicted":      predicted[:3],
    }
