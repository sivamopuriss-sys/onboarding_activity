# Project 29 — Autonomous SEO Content Production Pipeline

![Level](https://img.shields.io/badge/Level-Advanced-purple)
![Industry](https://img.shields.io/badge/Industry-Universal-lightgrey)
![Stack](https://img.shields.io/badge/Stack-CrewAI%20%7C%20Instructor%20%7C%20Serper%20API%20%7C%20GCP%20Cloud%20Run%20%7C%20LangSmith-blue)

## Business Problem
Content marketing teams need a steady flow of SEO-optimised articles — but producing one
quality article takes 3-6 hours. A 3-agent pipeline that researches, writes, and edits
automatically outputs publish-ready content at scale.

## Project Objective
CrewAI 3-agent pipeline:
- **Researcher** — keyword research + competitor analysis (Serper API)
- **Writer** — long-form article (1500-2500 words)
- **Editor** — brand voice enforcement + SEO polish

Output: publish-ready Markdown. Deployed on GCP Cloud Run.
Instructor validates ArticleOutput schema. TokenBudget guards cost.

## System Architecture
```mermaid
graph TD
    A[Topic + keyword input] --> B[FastAPI]
    B --> C[CrewAI 3-agent crew]
    C --> D[Researcher - Serper web search]
    D --> E[Writer - long-form draft]
    E --> F[Editor - brand voice + SEO]
    F --> G[Instructor validates ArticleOutput]
    G --> H[Publish-ready Markdown]
    C --> I[LangSmith traces]
    C --> J[TokenBudget cost guard]
    B --> K[GCP Cloud Run]
```

## Folder Structure
```
project-29-autonomous-seo-content-pipeline/
├── app/
│   ├── agents.py
│   ├── tasks.py
│   ├── tools.py
│   ├── crew.py
│   └── api.py
├── utils/
│   └── cost_tracker.py
├── evaluation/
│   └── langsmith_eval.py
├── infra/
│   ├── Dockerfile
│   ├── cloudbuild.yaml
│   └── service.yaml
├── tests/
│   └── test_crew.py
├── samples/
│   └── sample_article.md
├── langsmith_config.py
├── .github/workflows/deploy.yml
├── .env.example
├── requirements.txt
└── README.md
```

## Setup
```bash
pip install -r requirements.txt && cp .env.example .env
uvicorn app.api:app --reload
gcloud builds submit --config infra/cloudbuild.yaml
```

## Time Estimate
| Mode | Time |
|---|---|
| Self-paced | 18–24 hours |
| Instructor-guided | 10–14 hours |

---

## Step-by-Step Implementation Guide

This guide walks you through building this project from scratch. Follow each step in order.

---

### Step 1: Project Setup

```bash
mkdir project-29-autonomous-seo-content-pipeline
cd project-29-autonomous-seo-content-pipeline
python -m venv venv && source venv/bin/activate
mkdir -p app utils evaluation infra tests samples
touch app/agents.py app/tasks.py app/tools.py app/crew.py app/api.py
touch utils/cost_tracker.py langsmith_config.py
touch requirements.txt .env.example
```

`requirements.txt`:
```
crewai>=0.30.0
langchain>=0.2.0
langchain-openai>=0.1.0
langsmith>=0.1.0
instructor>=1.2.0
openai>=1.30.0
requests>=2.31.0
fastapi>=0.110.0
uvicorn>=0.29.0
pydantic>=2.0.0
python-dotenv>=1.0.0
tiktoken>=0.7.0
pytest>=8.0.0
```

`.env.example`:
```
OPENAI_API_KEY=sk-your-key
SERPER_API_KEY=your-serper-key
LANGCHAIN_TRACING_V2=true
LANGCHAIN_API_KEY=ls__your-key
LANGCHAIN_PROJECT=project-29-seo-pipeline
TOKEN_BUDGET=150000
BRAND_VOICE=professional, data-driven, accessible
```

Get a Serper API key at serper.dev — it provides Google Search results via API. Free tier: 2,500 searches/month.

---

### Step 2: Understand the 3-Agent Content Pipeline

A common mistake is to use one GPT-4o prompt to "write a complete SEO article." The result is generic, poorly researched, and likely hallucinated.

**Why 3 agents?**
- **Researcher** has web search tools — it finds real statistics, real competitor gaps, real search volumes. The Writer cannot access the internet.
- **Writer** focuses entirely on content creation — it receives the research brief as context and writes without the distraction of tool use.
- **Editor** applies a consistent brand voice across all articles, checks SEO mechanics (keyword density, meta description length), and adds the editorial polish that distinguishes professional content.

**The grounding advantage:** Because the Researcher uses Serper to find real statistics and competitor URLs, the Writer cites actual data rather than hallucinating statistics. This is the most important quality difference between this pipeline and a single LLM call.

---

### Step 3: Set Up the Serper Search Tools (`app/tools.py`)

```python
"""tools.py — Serper API web search and keyword analysis tools"""
import os, json, requests
from langchain_core.tools import tool
from dotenv import load_dotenv
load_dotenv()

SERPER_KEY = os.getenv("SERPER_API_KEY","")


@tool
def web_search(query: str) -> str:
    """Search the web for recent articles, statistics, and competitor content on a topic."""
    if not SERPER_KEY:
        # Demo fallback — replace with real API call
        return json.dumps({"organic": [
            {"title": f"Sample result for: {query}",
             "snippet": "This would be real search results from Serper API.",
             "link": "https://example.com"}
        ]})

    resp = requests.post(
        "https://google.serper.dev/search",
        headers={"X-API-KEY": SERPER_KEY, "Content-Type": "application/json"},
        json={"q": query, "num": 10},
        timeout=10,
    )
    resp.raise_for_status()
    data = resp.json()

    results = []
    for r in data.get("organic", [])[:5]:
        results.append({
            "title":   r.get("title"),
            "snippet": r.get("snippet"),
            "link":    r.get("link"),
        })
    return json.dumps(results, indent=2)


@tool
def keyword_analysis(topic: str) -> str:
    """Analyse keyword opportunities for a topic: primary keyword, secondary keywords, search intent."""
    resp = requests.post(
        "https://google.serper.dev/search",
        headers={"X-API-KEY": SERPER_KEY, "Content-Type": "application/json"},
        json={"q": f"{topic} keywords SEO", "num": 10},
        timeout=10,
    ) if SERPER_KEY else None

    # Extract people-also-ask and related searches from Serper
    related = []
    if resp and resp.ok:
        data = resp.json()
        related = [q["question"] for q in data.get("peopleAlsoAsk", [])[:5]]
        related += data.get("relatedSearches", [])[:5]

    return json.dumps({
        "primary_keyword":    topic,
        "secondary_keywords": related or [f"{topic} guide", f"how to {topic}", f"best {topic}"],
        "search_intent":      "informational — user wants to learn about this topic",
        "recommended_h2s":    [f"What is {topic}?", f"Benefits of {topic}",
                               f"How to get started with {topic}", f"Common mistakes to avoid",
                               f"Next steps"],
    }, indent=2)
```

**Why Serper over direct Google search?** Google's search results are blocked for automated scrapers. Serper is an official API that returns Google results in structured JSON — you get the same results as a Google search, returned as Python-friendly data in <500ms. The free tier (2,500 searches/month) is sufficient for a content pipeline producing 10–50 articles/month.

**Why return JSON strings from tools?** The Researcher agent reads tool outputs as text observations in the ReAct loop. Structured JSON makes it easy for GPT-4o to extract specific values ("the top competitor is example.com") rather than parsing free-form prose — reducing hallucination in the research brief.

---

### Step 4: Define the Three Agents (`app/agents.py`)

```python
"""agents.py — 3 CrewAI agent definitions"""
import os
from crewai import Agent
from langchain_openai import ChatOpenAI
from app.tools import web_search, keyword_analysis
from dotenv import load_dotenv
load_dotenv()

BRAND_VOICE = os.getenv("BRAND_VOICE","professional, data-driven, accessible")
llm = ChatOpenAI(model="gpt-4o", temperature=0.4, api_key=os.getenv("OPENAI_API_KEY"))


def build_content_agents():
    researcher = Agent(
        role="SEO Content Researcher",
        goal="Research keywords, competitor gaps, and supporting data for the target topic",
        backstory="Expert SEO strategist who finds impactful keywords and data-driven insights.",
        tools=[web_search, keyword_analysis],
        llm=llm, verbose=True, allow_delegation=False, max_iter=4,
    )

    writer = Agent(
        role="Long-Form Content Writer",
        goal="Write a comprehensive, engaging, SEO-optimised 1800-2500 word article",
        backstory="Professional content writer specialising in long-form SEO articles that rank on Google.",
        llm=llm, verbose=True, allow_delegation=False, max_iter=3,
    )

    editor = Agent(
        role="Brand Voice Editor",
        goal=f"Edit for brand voice ({BRAND_VOICE}), readability, and final SEO polish",
        backstory="Senior editor who ensures all content matches brand voice and SEO best practices.",
        llm=llm, verbose=True, allow_delegation=False, max_iter=2,
    )

    return researcher, writer, editor
```

**Why temperature=0.4?** Content writing benefits from some creative variation — a fully deterministic output (temperature=0) produces formulaic prose. 0.4 allows the Writer to make interesting word choices and varied sentence structures while keeping the factual content consistent. The Editor at the end enforces structural consistency regardless of the Writer's creative variation.

**Why `max_iter=4` for the Researcher but `max_iter=2` for the Editor?** The Researcher may need multiple search iterations to cover different angles: primary keyword search, competitor analysis, statistics search, people-also-ask queries. The Editor's task is well-scoped (apply a checklist) — it doesn't need multiple passes.

---

### Step 5: Define the Tasks (`app/tasks.py`)

```python
"""tasks.py — Tasks with Instructor-validated ArticleOutput"""
import instructor, openai
from crewai import Task
from pydantic import BaseModel

client = instructor.patch(openai.OpenAI())


class ArticleOutput(BaseModel):
    title:                str
    meta_description:     str    # Max 155 chars
    word_count:           int
    primary_keyword:      str
    content_markdown:     str
    keyword_density_pct:  float
    readability_notes:    str


def build_content_tasks(researcher, writer, editor, topic: str, keyword: str):
    t1 = Task(
        description=f"""Research: Topic="{topic}", Keyword="{keyword}".
Find: primary + secondary keywords, search intent, competitor gaps, 3-5 real statistics.
Use web_search (at least 3 different queries) and keyword_analysis tools.
Output a structured research brief.""",
        agent=researcher,
        expected_output="Research brief: keywords, statistics, competitor gaps, recommended article structure",
    )

    t2 = Task(
        description=f"""Write a 1800-2500 word SEO article on "{topic}" targeting "{keyword}".
Use Markdown. Include: compelling hook, 4-6 H2 sections, practical example, conclusion with CTA.
Include the keyword naturally in: title, first paragraph, at least 2 H2 headings.
Base your statistics and claims ONLY on the research brief from the Researcher.""",
        agent=writer,
        expected_output="Complete 1800-2500 word Markdown article with all required SEO elements",
        context=[t1],
    )

    t3 = Task(
        description=f"""Edit the article for quality and SEO:
1. Improve the introduction hook (first 2-3 sentences must compel reading)
2. Check keyword density is 1-2% for "{keyword}" (count occurrences / total words)
3. Write a compelling meta description (EXACTLY under 155 characters)
4. Improve readability: vary sentence length, use active voice
5. Ensure conclusion has a clear, specific CTA
Output the complete final article in Markdown.""",
        agent=editor,
        expected_output="Final polished Markdown article with meta description and readability notes",
        context=[t1, t2],
    )

    return t1, t2, t3
```

**Why `ArticleOutput` Pydantic schema?** The Editor's raw output is free-form Markdown with mixed metadata. Without schema validation, your API would need to parse unstructured text to extract the meta description, word count, and keyword density. The `ArticleOutput` schema forces the LLM to separate these into typed fields — your API can directly access `result.meta_description` without string parsing.

**Why does the Writer use ONLY the research brief?** Without this constraint, GPT-4o will supplement with its training knowledge — producing statistics that may be outdated or hallucinated. The research brief contains real, current data from Google search. Confining the Writer to this context ensures every claim in the article is grounded in real search results.

---

### Step 6: Orchestrate the Crew (`app/crew.py`)

```python
"""crew.py — Crew orchestration"""
import os
from crewai import Crew, Process
from langsmith_config import setup_langsmith
from agents import build_content_agents
from tasks import build_content_tasks
from utils.cost_tracker import TokenBudget, BudgetExceededError

setup_langsmith("project-29-seo-pipeline")


def run_content_crew(topic: str, keyword: str) -> dict:
    budget     = TokenBudget(max_tokens=int(os.getenv("TOKEN_BUDGET",150_000)), model="gpt-4o")
    researcher, writer, editor = build_content_agents()
    t1, t2, t3 = build_content_tasks(researcher, writer, editor, topic, keyword)

    crew = Crew(
        agents=[researcher, writer, editor],
        tasks=[t1, t2, t3],
        process=Process.sequential,
        verbose=True,
    )

    try:
        with budget:
            result = crew.kickoff()
        return {
            "status":            "completed",
            "content_markdown":  str(result),
            "topic":             topic,
            "keyword":           keyword,
            "token_summary":     budget.summary(),
            "estimated_cost":    budget.estimated_cost(),
        }
    except BudgetExceededError as e:
        return {"status": "budget_exceeded", "error": str(e)}
```

**Why TOKEN_BUDGET=150,000?** A typical crew run for a 2,000-word article uses:
- Researcher: 3–4 tool calls × ~2K tokens each = ~8K
- Writer: ~15K prompt + ~8K output = ~23K
- Editor: ~25K prompt (article + research) + ~10K output = ~35K
- Total: ~66K per article

Setting 150K gives 2× headroom for verbose reasoning chains and ensures cost is bounded at ~$1.10/article.

---

### Step 7: Build the FastAPI Endpoint (`app/api.py`)

```python
"""api.py — FastAPI content generation endpoint"""
import uuid
from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from crew import run_content_crew

app = FastAPI(title="Autonomous SEO Content Pipeline")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

job_store: dict = {}


class ContentRequest(BaseModel):
    topic:   str
    keyword: str


@app.get("/health")
def health(): return {"status": "ok"}


@app.post("/generate")
def generate(req: ContentRequest, background_tasks: BackgroundTasks):
    """Start a content generation job. Returns job_id for polling."""
    job_id = str(uuid.uuid4())
    job_store[job_id] = {"status": "running"}

    def _run():
        result = run_content_crew(req.topic, req.keyword)
        job_store[job_id] = {"status": result["status"], "result": result}

    background_tasks.add_task(_run)
    return {"job_id": job_id, "status": "queued",
            "message": f"Generating article on '{req.topic}'. Estimated time: 3-8 minutes."}


@app.get("/status/{job_id}")
def get_status(job_id: str):
    job = job_store.get(job_id)
    if not job: raise HTTPException(404, "Job not found")
    return {"status": job["status"],
            "result": job.get("result") if job["status"] == "completed" else None}
```

**Why background tasks instead of synchronous processing?** A CrewAI run with 3 agents, 3+ tool calls, and a 2000-word article takes 3–8 minutes. HTTP clients default to 30–60 second timeouts. Background tasks immediately return a job ID, allowing the client to poll `/status/{job_id}` until complete — preventing timeout errors on long-running content generation.

---

### Step 8: Run and Test

```bash
uvicorn app.api:app --reload --port 8000

# Submit a content generation request
curl -X POST http://localhost:8000/generate \
  -H "Content-Type: application/json" \
  -d '{"topic": "AI in content marketing", "keyword": "AI content marketing tools"}'

# Poll for status (repeat every 30 seconds)
curl http://localhost:8000/status/YOUR_JOB_ID
```

Check LangSmith — you'll see 3 agent runs per article, with all Serper tool calls visible, token usage per agent, and the context passed from Researcher to Writer to Editor.

---

### Step 9: Deploy to GCP Cloud Run

```bash
gcloud builds submit --config infra/cloudbuild.yaml

gcloud run deploy seo-content-pipeline \
  --region us-central1 \
  --min-instances 1 \
  --memory 2Gi \
  --timeout 900 \
  --set-env-vars "OPENAI_API_KEY=...,SERPER_API_KEY=...,TOKEN_BUDGET=150000"
```

**Why `--timeout 900` (15 minutes)?** Cloud Run's default request timeout is 60 seconds. Crew runs take 3–8 minutes. The background task pattern means the HTTP request returns in <1s, but Cloud Run still needs a long enough timeout for the underlying process. Set `--timeout 900` for the service, and the background task will complete well within that window.

---

### Step 10: Troubleshooting

| Error | Cause | Fix |
|---|---|---|
| `SerperAPIError: 403 Forbidden` | Invalid or expired SERPER_API_KEY | Regenerate key at serper.dev → Dashboard → API Keys |
| Researcher uses no tools (only writes) | Tools not bound to agent | Ensure `tools=[web_search, keyword_analysis]` in Researcher agent init |
| `instructor.ValidationError: ArticleOutput` | Editor output doesn't match schema | Add "Output valid JSON matching this schema:" + schema to Editor task description |
| `BudgetExceededError` after Researcher | Researcher's search loop uses too many tokens | Set `max_iter=3` on Researcher to limit search iterations |
| Article has no citations (hallucinated stats) | Writer ignoring research brief | Add "IMPORTANT: Use ONLY the statistics from the Researcher's brief." to Writer task |
| GCP Cloud Run: `DEADLINE_EXCEEDED` | Request times out before job starts | The background task pattern means the HTTP response is immediate; Cloud Run timeout only needs to be long enough for the process to stay alive |

---

## Evaluation Rubric

| Criteria | Meets | Exceeds |
|---|---|---|
| **Functionality** | 3 agents complete; article generated in Markdown | Article is 1800–2500 words; keyword appears in title, intro, and H2s |
| **Research quality** | Serper search results used | Statistics cited from search results; competitor gaps identified |
| **SEO compliance** | Keyword density 1–2%; meta description present | Meta description under 155 chars; readability notes from Editor |
| **Cost control** | TokenBudget set | Estimated cost per article logged; token breakdown per agent |
| **Observability** | LangSmith traces visible | All 3 agent runs visible with context passing; tool calls logged |

---

## Interview Talking Points

1. **Why 3 agents instead of 1 GPT-4o prompt?** — A single prompt produces generic content because GPT-4o can't search the web mid-generation. The Researcher uses Serper to find real statistics and competitor gaps, giving the Writer grounded facts rather than hallucinated statistics. The Editor enforces consistency across all articles. Each agent has a single well-defined job.

2. **How does Instructor validate the ArticleOutput?** — `instructor.patch(openai.OpenAI())` wraps the OpenAI client to automatically retry with an error correction prompt if the output doesn't match the Pydantic schema. For `ArticleOutput`, this ensures `meta_description` is always a string and `word_count` is always an int — the API can safely access these fields without parsing.

3. **What does keyword density mean and why does 1–2% matter?** — Keyword density is (keyword occurrences / total words) × 100. Below 1% suggests the keyword isn't adequately featured for search engines. Above 3% is "keyword stuffing" — Google penalises this and it reads unnaturally for humans. 1–2% is the sweet spot for natural-sounding, SEO-friendly content.

4. **How would you scale this to 100 articles per day?** — Replace the in-memory job store with Redis, use a Celery task queue for background processing, and deploy multiple Cloud Run instances. Each crew run is stateless and independent — horizontal scaling is straightforward. Cost at 100 articles/day at ~$1/article = $100/day = $3,000/month.

5. **How would you evaluate content quality automatically?** — Use GPT-4o as a judge to score each article on: factual accuracy (cross-check statistics against search results), readability (Flesch-Kincaid score), keyword compliance (count occurrences), and brand voice alignment (compare against a style guide embedding). Log all scores to a W&B table for trend analysis.

---

## Bonus Extensions

- **CMS publishing:** Add a WordPress or Contentful API integration that automatically publishes the approved article — creating a fully autonomous end-to-end content pipeline.
- **Image generation:** Add a DALL·E 3 call to generate a custom header image for each article based on the title — the complete package for publishing.
- **Content calendar scheduler:** Add a Cron-triggered endpoint that pulls topics from a Google Sheets calendar and triggers article generation automatically — zero manual intervention.
- **SEO performance tracking:** After publishing, track each article's Google ranking position weekly using the Search Console API — feeds back into the Researcher's keyword selection for future articles.

