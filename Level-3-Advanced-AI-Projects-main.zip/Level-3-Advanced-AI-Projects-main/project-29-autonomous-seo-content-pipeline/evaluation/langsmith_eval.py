"""langsmith_eval.py — Content quality evaluation"""
from langsmith import Client
client = Client()

def seo_quality(run, example):
    content = str(run.outputs.get("article",""))
    keyword = run.inputs.get("target_keyword","")
    score = 0
    if len(content.split()) >= 1500:     score += 0.25
    if "# " in content:                  score += 0.25
    if "## " in content:                 score += 0.25
    if keyword.lower() in content.lower(): score += 0.25
    return {"key":"seo_quality","score":score}
