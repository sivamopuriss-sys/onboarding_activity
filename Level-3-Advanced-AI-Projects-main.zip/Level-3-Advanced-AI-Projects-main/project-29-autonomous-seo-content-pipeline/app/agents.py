"""agents.py — 3 CrewAI agent definitions"""
import os
from crewai import Agent
from langchain_openai import ChatOpenAI
from app.tools import web_search, keyword_analysis
from dotenv import load_dotenv
load_dotenv()

BRAND_VOICE = os.getenv("BRAND_VOICE","professional, data-driven, accessible")
llm = ChatOpenAI(model="gpt-4o", temperature=0.4, api_key=os.getenv("OPENAI_API_KEY"))

def build_content_agents():
    researcher = Agent(
        role="SEO Content Researcher",
        goal="Research keywords, competitor gaps, and supporting data for the target topic",
        backstory="Expert SEO strategist who finds impactful keywords and data-driven insights.",
        tools=[web_search, keyword_analysis], llm=llm, verbose=True, allow_delegation=False, max_iter=4,
    )
    writer = Agent(
        role="Long-Form Content Writer",
        goal="Write a comprehensive, engaging, SEO-optimised 1800-2500 word article",
        backstory="Professional content writer specialising in long-form SEO articles that rank on Google.",
        llm=llm, verbose=True, allow_delegation=False, max_iter=3,
    )
    editor = Agent(
        role="Brand Voice Editor",
        goal=f"Edit for brand voice ({BRAND_VOICE}), readability, and final SEO polish",
        backstory="Senior editor who ensures all content matches brand voice and SEO best practices.",
        llm=llm, verbose=True, allow_delegation=False, max_iter=2,
    )
    return researcher, writer, editor
