"""tools.py — Serper API search tool"""
import os, requests, json
from langchain_core.tools import tool
from dotenv import load_dotenv
load_dotenv()

SERPER_KEY = os.getenv("SERPER_API_KEY","")

@tool
def web_search(query: str) -> str:
    """Search the web for keywords, stats, and competitor content."""
    if not SERPER_KEY:
        return json.dumps([{"title":f"Demo result for: {query}","snippet":"Demo snippet.","url":"https://example.com"}])
    headers = {"X-API-KEY":SERPER_KEY,"Content-Type":"application/json"}
    resp    = requests.post("https://google.serper.dev/search",json={"q":query,"num":5},headers=headers,timeout=10)
    results = resp.json().get("organic",[])
    return json.dumps([{"title":r.get("title",""),"snippet":r.get("snippet",""),"url":r.get("link","")} for r in results[:5]])

@tool
def keyword_analysis(seed_keyword: str) -> str:
    """Analyse search intent and related keywords."""
    return json.dumps({
        "seed_keyword": seed_keyword,
        "search_intent": "informational",
        "related_keywords": [f"{seed_keyword} guide", f"best {seed_keyword}", f"how to {seed_keyword}"],
        "recommended_length": "1800-2500 words",
        "competitor_gaps": "Most top content lacks practical examples and case studies",
    })
