"""crew.py — Crew orchestration"""
import os
from crewai import Crew, Process
from langsmith_config import setup_langsmith
from app.agents import build_content_agents
from app.tasks import build_content_tasks
from utils.cost_tracker import TokenBudget, BudgetExceededError
from dotenv import load_dotenv
load_dotenv()
setup_langsmith("project-29-seo-content-pipeline")

def run_content_crew(topic: str, keyword: str) -> dict:
    budget = TokenBudget(max_tokens=int(os.getenv("TOKEN_BUDGET",120_000)), model="gpt-4o")
    researcher, writer, editor = build_content_agents()
    t1, t2, t3 = build_content_tasks(researcher, writer, editor, topic, keyword)
    crew = Crew(agents=[researcher,writer,editor], tasks=[t1,t2,t3],
                process=Process.sequential, verbose=True)
    try:
        with budget:
            result = crew.kickoff()
    except BudgetExceededError as e:
        return {"error":str(e)}
    return {"topic":topic,"keyword":keyword,"article":str(result),
            "word_count":len(str(result).split()),"token_summary":budget.summary(),
            "estimated_cost":budget.estimated_cost()}
