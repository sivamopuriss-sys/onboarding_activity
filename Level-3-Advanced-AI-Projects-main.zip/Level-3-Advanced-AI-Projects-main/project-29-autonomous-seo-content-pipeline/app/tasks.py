"""tasks.py — Tasks with Instructor-validated ArticleOutput"""
import instructor, openai
from crewai import Task
from pydantic import BaseModel
from typing import Optional

client = instructor.patch(openai.OpenAI())

class ArticleOutput(BaseModel):
    title: str
    meta_description: str
    word_count: int
    primary_keyword: str
    content_markdown: str
    keyword_density_pct: float
    readability_notes: str

def build_content_tasks(researcher, writer, editor, topic: str, keyword: str):
    t1 = Task(
        description=f"""Research: Topic="{topic}", Keyword="{keyword}".
Find: primary + secondary keywords, search intent, competitor gaps, 3-5 statistics.
Use web_search and keyword_analysis tools.""",
        agent=researcher,
        expected_output="Research brief with keywords, stats, gaps, and article structure",
    )
    t2 = Task(
        description=f"""Write a 1800-2500 word SEO article on "{topic}" targeting "{keyword}".
Use Markdown. Include: hook introduction, 4-6 H2 sections, practical example, conclusion with CTA.
Include keyword naturally in title, first paragraph, 2-3 H2s.""",
        agent=writer,
        expected_output="Complete 1800-2500 word Markdown article",
        context=[t1],
    )
    t3 = Task(
        description=f"""Edit the article for brand voice and SEO:
1. Improve introduction hook  2. Check keyword density (1-2% for "{keyword}")
3. Write meta description (max 155 chars)  4. Improve readability
5. Ensure clear CTA in conclusion""",
        agent=editor,
        expected_output="Final polished Markdown article ready for publication",
        context=[t1,t2],
    )
    return t1, t2, t3
