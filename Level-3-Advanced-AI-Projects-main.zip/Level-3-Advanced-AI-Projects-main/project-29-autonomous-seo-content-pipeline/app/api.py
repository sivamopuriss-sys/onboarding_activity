"""api.py — FastAPI endpoint"""
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from app.crew import run_content_crew

app = FastAPI(title="Autonomous SEO Content Production Pipeline")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

class ContentRequest(BaseModel):
    topic: str
    target_keyword: str

@app.get("/health")
def health(): return {"status":"ok"}

@app.post("/generate-article")
def generate(req: ContentRequest):
    if not req.topic.strip(): raise HTTPException(422,"Topic required.")
    return run_content_crew(req.topic, req.target_keyword)
