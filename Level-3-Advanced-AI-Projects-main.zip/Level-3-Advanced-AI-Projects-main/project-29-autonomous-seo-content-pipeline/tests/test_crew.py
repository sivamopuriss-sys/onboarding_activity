"""test_crew.py"""
import sys; sys.path.insert(0,".")
from app.tasks import ArticleOutput

def test_article_output_model():
    a = ArticleOutput(title="Test",meta_description="Under 155.",
                      word_count=2000,primary_keyword="test",
                      content_markdown="# Test\n\nContent.",
                      keyword_density_pct=1.5,readability_notes="Good.")
    assert a.word_count == 2000
    assert len(a.meta_description) <= 155

def test_meta_max_length():
    meta = "A" * 155
    assert len(meta) <= 155
