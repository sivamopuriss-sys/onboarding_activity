"""test_scoring.py"""

def test_label_mapping():
    label2id = {"rejected":0,"hired":1}
    assert label2id["hired"] == 1
    assert label2id["rejected"] == 0

def test_score_range():
    # Fit score should always be 0-100
    score = 75
    assert 0 <= score <= 100

def test_synthetic_data_balance():
    import json
    labels = []
    try:
        with open("samples/synthetic_hire_data.jsonl") as f:
            for line in f:
                labels.append(json.loads(line)["label"])
        hired    = sum(labels)
        rejected = len(labels) - hired
        assert hired > 0 and rejected > 0
    except FileNotFoundError:
        pass  # File not present in CI
