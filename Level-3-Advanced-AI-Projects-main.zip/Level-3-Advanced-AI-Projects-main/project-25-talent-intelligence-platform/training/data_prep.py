"""data_prep.py — Generate synthetic hire outcome data"""
import json, random
import pandas as pd
from pathlib import Path

random.seed(42)

SKILLS_POOL = ["Python","SQL","Machine Learning","Data Analysis","Communication",
               "Leadership","Project Management","Java","AWS","Excel","R","Tableau",
               "Deep Learning","NLP","Computer Vision","FastAPI","React","Docker"]

POSITIVE_INDICATORS = ["led","delivered","increased","reduced","built","launched",
                       "managed","optimised","grew","achieved"]

def generate_synthetic_resume(fit_label: str) -> str:
    n_skills  = random.randint(4,8) if fit_label=="hired" else random.randint(1,4)
    n_years   = random.randint(3,10) if fit_label=="hired" else random.randint(0,3)
    skills    = random.sample(SKILLS_POOL, n_skills)
    n_achiev  = random.randint(3,6) if fit_label=="hired" else random.randint(0,2)
    verbs     = random.sample(POSITIVE_INDICATORS, min(n_achiev, len(POSITIVE_INDICATORS)))
    achievements = [f"{v} key project initiative with measurable results" for v in verbs]
    return (f"Candidate with {n_years} years of experience. "
            f"Skills: {', '.join(skills)}. "
            f"Achievements: {'. '.join(achievements)}.")

def generate_dataset(n_samples: int = 500, output_dir: str = "data/") -> str:
    Path(output_dir).mkdir(exist_ok=True)
    records = []
    for _ in range(n_samples):
        label = "hired" if random.random() > 0.4 else "rejected"
        records.append({
            "resume_text": generate_synthetic_resume(label),
            "outcome":     label,
            "label":       1 if label=="hired" else 0,
        })

    random.shuffle(records)
    df   = pd.DataFrame(records)
    n    = len(df)
    path = f"{output_dir}/hire_outcomes.jsonl"
    df.to_json(path, orient="records", lines=True)

    print(f"Generated {n} samples: {df['outcome'].value_counts().to_dict()}")
    print(f"Saved to {path}")
    return path

def prepare_openai_format(input_path: str, output_path: str = "data/openai_hire.jsonl"):
    with open(input_path) as f:
        records = [json.loads(l) for l in f]
    with open(output_path,"w") as out:
        for r in records:
            example = {"messages":[
                {"role":"system","content":"You are a talent assessment AI. Classify candidate fit as 'hired' or 'rejected'."},
                {"role":"user",  "content":f"Resume:\n{r['resume_text']}"},
                {"role":"assistant","content":r["outcome"]},
            ]}
            out.write(json.dumps(example)+"\n")
    print(f"OpenAI format saved: {output_path}")

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--openai", action="store_true")
    args = parser.parse_args()
    path = generate_dataset()
    if args.openai:
        prepare_openai_format(path)
