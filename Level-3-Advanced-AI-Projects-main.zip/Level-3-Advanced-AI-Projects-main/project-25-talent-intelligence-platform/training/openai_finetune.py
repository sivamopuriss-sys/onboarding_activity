"""openai_finetune.py — OpenAI Fine-tuning API for talent classification"""
import os, argparse, wandb
from openai import OpenAI
from dotenv import load_dotenv
load_dotenv()
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def train():
    wandb.init(project=os.getenv("WANDB_PROJECT","talent-intelligence-platform"),
               name="openai-talent-classifier", tags=["openai","hr"])
    with open("data/openai_hire.jsonl","rb") as f:
        file_resp = client.files.create(file=f, purpose="fine-tune")
    job = client.fine_tuning.jobs.create(
        training_file=file_resp.id, model="gpt-4o-mini-2024-07-18",
        hyperparameters={"n_epochs":3})
    wandb.config.update({"job_id":job.id,"model":"gpt-4o-mini","epochs":3})
    with open("data/openai_job_id.txt","w") as f: f.write(job.id)
    print(f"Job submitted: {job.id}")
    wandb.finish()

def status():
    try:
        with open("data/openai_job_id.txt") as f: job_id = f.read().strip()
    except: print("Run --train first."); return
    job = client.fine_tuning.jobs.retrieve(job_id)
    print(f"Status: {job.status}")
    if job.status=="succeeded": print(f"Model: {job.fine_tuned_model}")

if __name__=="__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--train",  action="store_true")
    p.add_argument("--status", action="store_true")
    args = p.parse_args()
    if args.train: train()
    elif args.status: status()
    else: p.print_help()
