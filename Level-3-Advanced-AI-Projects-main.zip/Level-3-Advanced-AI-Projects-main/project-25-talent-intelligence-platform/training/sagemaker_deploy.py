"""sagemaker_deploy.py — Deploy fine-tuned model to AWS SageMaker"""
import os, boto3, sagemaker
from sagemaker.huggingface import HuggingFaceModel
from dotenv import load_dotenv
load_dotenv()

ROLE         = os.getenv("SAGEMAKER_ROLE_ARN","arn:aws:iam::YOUR_ACCOUNT:role/SageMakerRole")
ENDPOINT_NAME= os.getenv("SAGEMAKER_ENDPOINT_NAME","talent-fit-predictor")
REGION       = os.getenv("AWS_REGION","us-east-1")

def deploy_to_sagemaker(model_s3_uri: str):
    """
    Deploy a fine-tuned Hugging Face model to SageMaker.
    model_s3_uri: S3 path to model.tar.gz (upload with: aws s3 cp model_weights/ s3://... --recursive)
    """
    sess = sagemaker.Session(boto_session=boto3.Session(region_name=REGION))

    huggingface_model = HuggingFaceModel(
        model_data=model_s3_uri,
        role=ROLE,
        transformers_version="4.37",
        pytorch_version="2.1",
        py_version="py310",
        env={"HF_TASK": "text-classification"},
    )

    predictor = huggingface_model.deploy(
        initial_instance_count=1,
        instance_type="ml.m5.large",
        endpoint_name=ENDPOINT_NAME,
    )
    print(f"Endpoint deployed: {ENDPOINT_NAME}")
    print("Test with: predictor.predict({'inputs': 'candidate resume text here'})")
    return predictor


def delete_endpoint():
    client = boto3.client("sagemaker", region_name=REGION)
    client.delete_endpoint(EndpointName=ENDPOINT_NAME)
    print(f"Endpoint {ENDPOINT_NAME} deleted.")


if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("--model-s3", help="S3 URI of model artifact")
    p.add_argument("--delete", action="store_true")
    args = p.parse_args()
    if args.delete: delete_endpoint()
    elif args.model_s3: deploy_to_sagemaker(args.model_s3)
    else: print("Provide --model-s3 s3://... or --delete")
