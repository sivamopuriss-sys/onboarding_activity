"""lora_finetune.py — LoRA fine-tuning for talent classification"""
import os, wandb
from dotenv import load_dotenv
load_dotenv()

wandb.init(project=os.getenv("WANDB_PROJECT","talent-intelligence-platform"),
           name="lora-talent-classifier", tags=["lora","hr","classification"])

try:
    import torch, numpy as np
    from transformers import (AutoTokenizer, AutoModelForSequenceClassification,
                              TrainingArguments, Trainer, DataCollatorWithPadding)
    from peft import LoraConfig, get_peft_model, TaskType
    from datasets import load_dataset
    from sklearn.metrics import f1_score, roc_auc_score, accuracy_score
except ImportError:
    print("Install: pip install torch transformers peft datasets accelerate")
    raise

BASE_MODEL = "distilbert-base-uncased"
OUTPUT_DIR = "./model_weights/talent-lora"
LABEL2ID   = {"rejected":0,"hired":1}
ID2LABEL   = {0:"rejected",1:"hired"}

tokenizer = AutoTokenizer.from_pretrained(BASE_MODEL)
model     = AutoModelForSequenceClassification.from_pretrained(
    BASE_MODEL, num_labels=2, label2id=LABEL2ID, id2label=ID2LABEL)

lora_config = LoraConfig(
    task_type=TaskType.SEQ_CLS, r=8, lora_alpha=16, lora_dropout=0.1,
    target_modules=["q_lin","k_lin","v_lin"], bias="none")
model = get_peft_model(model, lora_config)
model.print_trainable_parameters()

def tokenize(examples):
    return tokenizer(examples["resume_text"], truncation=True, max_length=256)

dataset = load_dataset("json", data_files={"train":"data/hire_outcomes.jsonl"})
dataset = dataset["train"].train_test_split(test_size=0.2, seed=42)
dataset = dataset.map(tokenize, batched=True)
dataset = dataset.rename_column("label","labels")

def compute_metrics(eval_pred):
    logits, labels = eval_pred
    preds = logits.argmax(-1)
    return {
        "accuracy":  accuracy_score(labels, preds),
        "f1_hired":  f1_score(labels, preds, pos_label=1),
        "f1_macro":  f1_score(labels, preds, average="macro"),
    }

training_args = TrainingArguments(
    output_dir=OUTPUT_DIR, num_train_epochs=5,
    per_device_train_batch_size=16, per_device_eval_batch_size=32,
    evaluation_strategy="epoch", save_strategy="epoch",
    load_best_model_at_end=True, metric_for_best_model="f1_macro",
    report_to="wandb", logging_steps=10, learning_rate=2e-4,
)
Trainer(model=model, args=training_args, train_dataset=dataset["train"],
        eval_dataset=dataset["test"], tokenizer=tokenizer,
        data_collator=DataCollatorWithPadding(tokenizer),
        compute_metrics=compute_metrics).train()

import os; os.makedirs(OUTPUT_DIR, exist_ok=True)
model.save_pretrained(OUTPUT_DIR)
print(f"Model saved to {OUTPUT_DIR}")
wandb.finish()
