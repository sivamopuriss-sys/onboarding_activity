"""api.py — FastAPI inference endpoint"""
import os
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from openai import OpenAI
from langsmith_config import setup_langsmith
from dotenv import load_dotenv

load_dotenv()
setup_langsmith("project-25-talent-platform")
client        = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
FINE_TUNED    = os.getenv("FINE_TUNED_MODEL","gpt-4o-mini")
ENDPOINT_NAME = os.getenv("SAGEMAKER_ENDPOINT_NAME","talent-fit-predictor")

app = FastAPI(title="Talent Intelligence Platform")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

class ScoreRequest(BaseModel):
    resume_text: str
    job_description: str = ""

@app.get("/health")
def health(): return {"status":"ok","model":FINE_TUNED}

@app.post("/score-candidate")
def score_candidate(req: ScoreRequest):
    try:
        resp = client.chat.completions.create(
            model=FINE_TUNED,
            messages=[
                {"role":"system","content":"You are a talent assessment AI. Score candidate fit 0-100 and predict outcome. Return JSON: {fit_score, prediction, reasoning, top_strengths, gaps}"},
                {"role":"user","content":f"Resume:\n{req.resume_text}\n\nJob Description:\n{req.job_description}"},
            ],
            response_format={"type":"json_object"},
            temperature=0.1,
        )
        return {"result": resp.choices[0].message.content}
    except Exception as e:
        raise HTTPException(500, str(e))
