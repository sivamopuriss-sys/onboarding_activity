"""wandb_eval.py — Before/after model comparison"""
import wandb
from sklearn.metrics import classification_report, roc_auc_score

def log_comparison(base_preds, ft_preds, true_labels, base_proba=None, ft_proba=None):
    wandb.init(project="talent-intelligence-platform", name="before-after-comparison")
    base = classification_report(true_labels, base_preds, target_names=["rejected","hired"], output_dict=True)
    ft   = classification_report(true_labels, ft_preds,   target_names=["rejected","hired"], output_dict=True)

    table = wandb.Table(
        columns=["Metric","Base Model","Fine-tuned","Delta"],
        data=[
            ["Accuracy",      base["accuracy"],                  ft["accuracy"],                  ft["accuracy"]-base["accuracy"]],
            ["Hired F1",      base["hired"]["f1-score"],         ft["hired"]["f1-score"],         ft["hired"]["f1-score"]-base["hired"]["f1-score"]],
            ["Rejected F1",   base["rejected"]["f1-score"],      ft["rejected"]["f1-score"],      ft["rejected"]["f1-score"]-base["rejected"]["f1-score"]],
            ["Macro F1",      base["macro avg"]["f1-score"],     ft["macro avg"]["f1-score"],     ft["macro avg"]["f1-score"]-base["macro avg"]["f1-score"]],
        ]
    )
    if base_proba and ft_proba:
        base_auc = roc_auc_score(true_labels, [p[1] for p in base_proba])
        ft_auc   = roc_auc_score(true_labels, [p[1] for p in ft_proba])
        table.add_data("AUC-ROC", base_auc, ft_auc, ft_auc-base_auc)

    wandb.log({"before_after_comparison": table})
    print("Comparison logged to W&B.")
    wandb.finish()
