# Project 25 — Talent Intelligence Platform

![Level](https://img.shields.io/badge/Level-Advanced-purple)
![Industry](https://img.shields.io/badge/Industry-HR-pink)
![Stack](https://img.shields.io/badge/Stack-Hugging%20Face%20%7C%20LoRA%20%7C%20OpenAI%20Fine--tuning%20%7C%20AWS%20SageMaker%20%7C%20W%26B-blue)

## Business Problem
Most ATS (Applicant Tracking Systems) score candidates using keyword matching — a crude approach
that misses strong candidates with non-standard backgrounds and passes weak ones who keyword-stuffed.
A model fine-tuned on a company's own historical hire success/failure data predicts candidate fit
far more accurately than generic scoring — and improves over time as more hiring data accumulates.

## Project Objective
Fine-tune a text classification model on synthetic hire outcome data (hired/rejected, with
subsequent performance rating). Deploy the model as a REST API via AWS SageMaker. Integrate
with an ATS via webhook. Full W&B experiment tracking and before/after accuracy comparison.

## System Architecture
```mermaid
graph TD
    A[Candidate resume text] --> B[FastAPI inference endpoint]
    B --> C[Fine-tuned model - SageMaker endpoint]
    C --> D[Fit score 0-100 + reasoning]
    D --> E[ATS webhook response]
    F[Training data - hire outcomes] --> G[Data prep pipeline]
    G --> H{Fine-tuning approach}
    H -- LoRA --> I[Hugging Face Trainer + W&B]
    H -- OpenAI --> J[OpenAI Fine-tuning API + W&B]
    I --> K[Model artifact - SageMaker]
    J --> K
    K --> B
```

## Folder Structure
```
project-25-talent-intelligence-platform/
├── app/
│   └── api.py              # FastAPI inference API
├── training/
│   ├── data_prep.py        # Synthetic hire data generation + prep
│   ├── lora_finetune.py    # LoRA fine-tuning script
│   ├── openai_finetune.py  # OpenAI API alternative
│   └── sagemaker_deploy.py # SageMaker deployment script
├── evaluation/
│   ├── wandb_eval.py       # W&B experiment tracking
│   └── metrics.py          # Before/after F1, AUC, precision/recall
├── infra/
│   ├── Dockerfile
│   └── template.yaml       # AWS SAM template
├── tests/
│   └── test_scoring.py
├── samples/
│   └── synthetic_hire_data.jsonl
├── langsmith_config.py
├── .github/workflows/deploy.yml
├── .env.example
├── requirements.txt
└── README.md
```

## Setup

### Option A — LoRA Fine-tuning
```bash
pip install -r requirements.txt
python training/data_prep.py          # Generate synthetic dataset
python training/lora_finetune.py      # Fine-tune (GPU recommended)
python training/sagemaker_deploy.py   # Deploy to SageMaker
```

### Option B — OpenAI Fine-tuning
```bash
python training/data_prep.py --openai
python training/openai_finetune.py --train
python training/openai_finetune.py --status
```

## Observability
- W&B tracks training loss, F1, AUC, precision/recall per class per epoch
- LangSmith traces inference API calls
- Before/after comparison table auto-generated in W&B

## Key Concepts
- Fine-tuning for binary/multi-class HR classification
- Synthetic data generation for sensitive domains
- AWS SageMaker model deployment and endpoint management
- ATS webhook integration pattern
- Evaluation: F1, AUC, bias testing across demographic groups

## Time Estimate
| Mode | Time |
|---|---|
| Self-paced | 20–28 hours |
| Instructor-guided | 12–16 hours |

---

## Step-by-Step Implementation Guide

This guide walks you through building this project from scratch. Follow each step in order.

---

### Step 1: Project Setup

```bash
mkdir project-25-talent-intelligence-platform
cd project-25-talent-intelligence-platform
python -m venv venv && source venv/bin/activate
mkdir -p app training evaluation infra tests samples data model_weights
touch training/data_prep.py training/lora_finetune.py training/openai_finetune.py training/sagemaker_deploy.py
touch app/api.py requirements.txt .env.example
```

`requirements.txt`:
```
torch>=2.2.0
transformers>=4.40.0
peft>=0.10.0
datasets>=2.19.0
accelerate>=0.29.0
openai>=1.30.0
wandb>=0.17.0
boto3>=1.34.0
sagemaker>=2.210.0
pandas>=2.0.0
scikit-learn>=1.4.0
fastapi>=0.110.0
uvicorn>=0.29.0
pydantic>=2.0.0
python-dotenv>=1.0.0
pytest>=8.0.0
```

`.env.example`:
```
OPENAI_API_KEY=sk-your-key
WANDB_API_KEY=your-wandb-key
WANDB_PROJECT=talent-intelligence-platform
AWS_REGION=us-east-1
SAGEMAKER_ROLE_ARN=arn:aws:iam::YOUR_ACCOUNT:role/SageMakerRole
SAGEMAKER_ENDPOINT_NAME=talent-scoring-endpoint
FINE_TUNED_MODEL_PATH=./model_weights/talent-scorer-lora
```

---

### Step 2: Why Fine-tune for HR?

Most ATS (Applicant Tracking Systems) use keyword matching: a candidate with "Python, Machine Learning" keywords in their resume scores higher regardless of context. A fine-tuned model on historical hire outcomes learns the actual patterns of successful vs unsuccessful candidates — including action verbs, achievement density, experience progression, and skill combinations that correlate with success at your specific company.

**Why synthetic data?** Real hire outcome data contains sensitive PII (names, addresses, demographic information) and is governed by employment law. Synthetic data that mimics the statistical patterns of real hire decisions allows you to build and test the model pipeline safely, before replacing it with real (de-identified) data in production.

**Responsible AI note:** Any model trained on hire outcome data must be tested for bias across demographic groups before deployment. A model that learns patterns from biased historical hiring decisions will perpetuate those biases at scale.

---

### Step 3: Generate and Prepare the Dataset (`training/data_prep.py`)

```python
"""data_prep.py — Generate synthetic hire outcome data"""
import json, random
import pandas as pd
from pathlib import Path

random.seed(42)

SKILLS_POOL = ["Python","SQL","Machine Learning","Data Analysis","Communication",
               "Leadership","Project Management","Java","AWS","Excel","R","Tableau",
               "Deep Learning","NLP","Computer Vision","FastAPI","React","Docker"]

POSITIVE_INDICATORS = ["led","delivered","increased","reduced","built","launched",
                        "managed","optimised","grew","achieved"]


def generate_synthetic_resume(fit_label: str) -> str:
    n_skills     = random.randint(4, 8) if fit_label == "hired" else random.randint(1, 4)
    n_years      = random.randint(3, 10) if fit_label == "hired" else random.randint(0, 3)
    skills       = random.sample(SKILLS_POOL, n_skills)
    n_achiev     = random.randint(3, 6)  if fit_label == "hired" else random.randint(0, 2)
    verbs        = random.sample(POSITIVE_INDICATORS, min(n_achiev, len(POSITIVE_INDICATORS)))
    achievements = [f"{v} key project initiative with measurable results" for v in verbs]
    return (
        f"Candidate with {n_years} years of experience. "
        f"Skills: {', '.join(skills)}. "
        f"Achievements: {'. '.join(achievements)}."
    )


def generate_dataset(n_samples: int = 500, output_dir: str = "data/") -> str:
    Path(output_dir).mkdir(exist_ok=True)
    records = []
    for _ in range(n_samples):
        label = "hired" if random.random() > 0.4 else "rejected"
        records.append({
            "resume_text": generate_synthetic_resume(label),
            "outcome":     label,
            "label":       1 if label == "hired" else 0,
        })
    random.shuffle(records)
    df   = pd.DataFrame(records)
    path = f"{output_dir}/hire_outcomes.jsonl"
    df.to_json(path, orient="records", lines=True)
    print(f"Generated {n_samples} samples: {df['outcome'].value_counts().to_dict()}")
    return path


def prepare_openai_format(input_path: str, output_path: str = "data/openai_hire.jsonl"):
    with open(input_path) as f:
        records = [json.loads(l) for l in f]
    with open(output_path, "w") as out:
        for r in records:
            example = {"messages": [
                {"role": "system",    "content": "You are a talent assessment AI. Classify candidate fit as 'hired' or 'rejected'."},
                {"role": "user",      "content": f"Resume:\n{r['resume_text']}"},
                {"role": "assistant", "content": r["outcome"]},
            ]}
            out.write(json.dumps(example) + "\n")
    print(f"OpenAI format saved: {output_path}")
```

Usage:
```bash
python training/data_prep.py              # LoRA format
python training/data_prep.py --openai     # OpenAI fine-tuning format
```

**Why 60% hired / 40% rejected?** Real-world hiring data is imbalanced — more candidates are interviewed than hired. This 60/40 split mimics a typical pipeline where ~40% of interviewed candidates are rejected. Training on a 90/10 imbalance would produce a model that predicts "hired" for almost everything.

---

### Step 4: Fine-tune with LoRA (`training/lora_finetune.py`)

```python
"""lora_finetune.py — LoRA fine-tuning for hire outcome classification"""
import os, wandb
from dotenv import load_dotenv
load_dotenv()

wandb.init(project=os.getenv("WANDB_PROJECT","talent-intelligence-platform"),
           name="lora-hire-classifier", tags=["lora","hr","classification"])

import torch
import numpy as np
from transformers import (AutoTokenizer, AutoModelForSequenceClassification,
                          TrainingArguments, Trainer, DataCollatorWithPadding)
from peft import LoraConfig, get_peft_model, TaskType
from datasets import load_dataset
from sklearn.metrics import f1_score, roc_auc_score, accuracy_score

BASE_MODEL = os.getenv("BASE_MODEL", "distilbert-base-uncased")
OUTPUT_DIR = os.getenv("FINE_TUNED_MODEL_PATH", "./model_weights/talent-scorer-lora")
LABEL2ID   = {"rejected": 0, "hired": 1}
ID2LABEL   = {0: "rejected", 1: "hired"}

tokenizer = AutoTokenizer.from_pretrained(BASE_MODEL)
model = AutoModelForSequenceClassification.from_pretrained(
    BASE_MODEL, num_labels=2, label2id=LABEL2ID, id2label=ID2LABEL)

lora_config = LoraConfig(
    task_type=TaskType.SEQ_CLS, r=8, lora_alpha=16, lora_dropout=0.1,
    target_modules=["q_lin","k_lin","v_lin"], bias="none",
)
model = get_peft_model(model, lora_config)
model.print_trainable_parameters()


def tokenize(examples):
    return tokenizer(examples["resume_text"], truncation=True, max_length=256)

dataset = load_dataset("json", data_files={"train": "data/train.jsonl",
                                            "validation": "data/val.jsonl"})
dataset = dataset.map(tokenize, batched=True).rename_column("label","labels")


def compute_metrics(eval_pred):
    logits, labels = eval_pred
    preds = np.argmax(logits, axis=-1)
    probs = torch.softmax(torch.tensor(logits, dtype=torch.float), dim=-1)[:,1].numpy()
    return {
        "accuracy": accuracy_score(labels, preds),
        "f1":       f1_score(labels, preds, average="binary"),
        "auc_roc":  roc_auc_score(labels, probs),
    }


training_args = TrainingArguments(
    output_dir=OUTPUT_DIR,
    num_train_epochs=5,
    per_device_train_batch_size=16,
    per_device_eval_batch_size=32,
    evaluation_strategy="epoch",
    save_strategy="epoch",
    load_best_model_at_end=True,
    metric_for_best_model="auc_roc",
    report_to="wandb",
    learning_rate=2e-4,
    warmup_ratio=0.1,
    weight_decay=0.01,
)

trainer = Trainer(model=model, args=training_args,
                  train_dataset=dataset["train"], eval_dataset=dataset["validation"],
                  tokenizer=tokenizer, data_collator=DataCollatorWithPadding(tokenizer),
                  compute_metrics=compute_metrics)
trainer.train()
trainer.save_model(OUTPUT_DIR)
wandb.finish()
```

**Why `max_length=256` instead of 128?** Resumes contain more text than financial news headlines. At 128 tokens, many resumes would be truncated mid-sentence, losing important skills and achievements in the latter part of the document. 256 captures most resumes fully while staying within DistilBERT's 512-token limit.

**Why AUC-ROC as the best-model metric?** AUC-ROC measures the model's ability to rank candidates — a hired candidate should score higher than a rejected one, regardless of where you set the decision threshold. This is more meaningful than accuracy for HR: recruiters don't just want "hired/rejected", they want a ranked shortlist. Higher AUC = better ranking ability.

---

### Step 5: Fine-tune with OpenAI API (`training/openai_finetune.py`)

```python
"""openai_finetune.py — OpenAI Fine-tuning API for hire classification"""
import os, time
from openai import OpenAI
from dotenv import load_dotenv
load_dotenv()

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))


def train(dataset_path: str = "data/openai_hire.jsonl"):
    with open(dataset_path, "rb") as f:
        file_obj = client.files.create(file=f, purpose="fine-tune")
    print(f"Uploaded: {file_obj.id}")

    job = client.fine_tuning.jobs.create(
        training_file=file_obj.id,
        model="gpt-4o-mini-2024-07-18",
        hyperparameters={"n_epochs": 4},
    )
    print(f"Job started: {job.id}")

    while True:
        status = client.fine_tuning.jobs.retrieve(job.id)
        print(f"Status: {status.status}")
        if status.status == "succeeded":
            print(f"Model ready: {status.fine_tuned_model}")
            with open(".env", "a") as f:
                f.write(f"\nOPENAI_FINE_TUNED_MODEL={status.fine_tuned_model}")
            return status.fine_tuned_model
        elif status.status in ("failed", "cancelled"):
            raise RuntimeError(f"Fine-tuning failed: {status.status}")
        time.sleep(60)


if __name__ == "__main__":
    import sys
    if "--train" in sys.argv:
        train()
    elif "--status" in sys.argv:
        job_id = sys.argv[sys.argv.index("--status") + 1]
        print(client.fine_tuning.jobs.retrieve(job_id))
```

---

### Step 6: Deploy to AWS SageMaker (`training/sagemaker_deploy.py`)

```python
"""sagemaker_deploy.py — Deploy fine-tuned model to SageMaker endpoint"""
import os, tarfile, boto3, sagemaker
from sagemaker.huggingface import HuggingFaceModel
from dotenv import load_dotenv
load_dotenv()

sess   = sagemaker.Session()
role   = os.getenv("SAGEMAKER_ROLE_ARN")
region = os.getenv("AWS_REGION","us-east-1")
s3     = boto3.client("s3", region_name=region)

MODEL_DIR      = os.getenv("FINE_TUNED_MODEL_PATH","./model_weights/talent-scorer-lora")
S3_BUCKET      = os.getenv("S3_MODEL_BUCKET","your-ml-models-bucket")
ENDPOINT_NAME  = os.getenv("SAGEMAKER_ENDPOINT_NAME","talent-scoring-endpoint")


def package_and_upload_model() -> str:
    """Package model directory as model.tar.gz and upload to S3."""
    tar_path = "model.tar.gz"
    with tarfile.open(tar_path,"w:gz") as tar:
        tar.add(MODEL_DIR, arcname=".")
    s3_key = f"talent-intelligence/model.tar.gz"
    s3.upload_file(tar_path, S3_BUCKET, s3_key)
    s3_uri = f"s3://{S3_BUCKET}/{s3_key}"
    print(f"Model uploaded to {s3_uri}")
    return s3_uri


def deploy_endpoint(s3_model_uri: str) -> str:
    """Create a SageMaker real-time inference endpoint."""
    hub = {"HF_MODEL_ID": "__local__", "HF_TASK": "text-classification"}
    model = HuggingFaceModel(
        model_data=s3_model_uri,
        role=role,
        transformers_version="4.36",
        pytorch_version="2.1",
        py_version="py310",
        env=hub,
    )
    predictor = model.deploy(
        initial_instance_count=1,
        instance_type="ml.m5.xlarge",
        endpoint_name=ENDPOINT_NAME,
    )
    print(f"Endpoint deployed: {ENDPOINT_NAME}")
    return ENDPOINT_NAME


if __name__ == "__main__":
    s3_uri = package_and_upload_model()
    deploy_endpoint(s3_uri)
```

**Why SageMaker over Lambda for this model?** A DistilBERT model is ~250MB. Lambda has a 250MB deployment package limit (512MB with container), making large transformer models impractical. SageMaker's dedicated inference instances load the model into memory once and serve requests in <100ms — far more efficient than loading a 250MB model on every Lambda cold start.

**Why `ml.m5.xlarge`?** A DistilBERT inference on CPU takes ~50–150ms on an m5.xlarge (4 vCPU, 16GB RAM). For the expected load (screening candidates one at a time from an ATS webhook), this is sufficient. Use `ml.g4dn.xlarge` (GPU) if you need <20ms latency at high throughput.

---

### Step 7: Build the Inference API (`app/api.py`)

```python
"""api.py — FastAPI inference API"""
import os, json, boto3
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from dotenv import load_dotenv
load_dotenv()

app = FastAPI(title="Talent Intelligence Platform")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

USE_SAGEMAKER = bool(os.getenv("SAGEMAKER_ENDPOINT_NAME"))
sagemaker_runtime = boto3.client("sagemaker-runtime",
                                  region_name=os.getenv("AWS_REGION","us-east-1"))

if not USE_SAGEMAKER:
    from transformers import pipeline
    classifier = pipeline("text-classification",
                          model=os.getenv("FINE_TUNED_MODEL_PATH","./model_weights/talent-scorer-lora"))


class CandidateRequest(BaseModel):
    resume_text: str
    job_id:      str = "general"


class ScoreResponse(BaseModel):
    fit_score:   int    # 0–100
    label:       str    # "hired" | "rejected"
    confidence:  float
    reasoning:   str


@app.get("/health")
def health():
    return {"status": "ok", "backend": "sagemaker" if USE_SAGEMAKER else "local"}


@app.post("/score", response_model=ScoreResponse)
def score_candidate(req: CandidateRequest):
    try:
        if USE_SAGEMAKER:
            payload = json.dumps({"inputs": req.resume_text})
            resp = sagemaker_runtime.invoke_endpoint(
                EndpointName=os.getenv("SAGEMAKER_ENDPOINT_NAME"),
                ContentType="application/json",
                Body=payload,
            )
            result = json.loads(resp["Body"].read())[0]
        else:
            result = classifier(req.resume_text[:512])[0]

        label_map = {"LABEL_0": "rejected", "LABEL_1": "hired",
                     "rejected": "rejected", "hired": "hired"}
        label      = label_map.get(result["label"], result["label"])
        confidence = round(result["score"], 4)
        fit_score  = int(confidence * 100) if label == "hired" else int((1 - confidence) * 100)

        return ScoreResponse(
            fit_score=fit_score,
            label=label,
            confidence=confidence,
            reasoning=f"Model predicts '{label}' with {confidence*100:.1f}% confidence based on resume content.",
        )
    except Exception as e:
        raise HTTPException(500, str(e))
```

---

### Step 8: Evaluate with W&B

After training, view your results at wandb.ai:
- **AUC-ROC curve** — area under curve should be >0.80 for a useful model (>0.90 is excellent)
- **F1 score** — look for F1 > 0.75 for both hired and rejected classes
- **Before/after comparison** — create a W&B run for the baseline (zero-shot classification) and compare tables

**Bias testing:**
```python
# After training, test on demographic subgroups
from sklearn.metrics import f1_score
for group in ["engineering", "marketing", "sales"]:
    subset = test_df[test_df["department"] == group]
    preds  = classifier(subset["resume_text"].tolist())
    f1     = f1_score(subset["label"], [1 if p["label"]=="hired" else 0 for p in preds])
    print(f"{group}: F1 = {f1:.3f}")
    wandb.log({f"f1_{group}": f1})
```

If F1 varies significantly across groups (>10 percentage points), the model may have learned biased patterns — investigate the training data and consider rebalancing.

---

### Step 9: Connect to an ATS via Webhook

Most ATS platforms (Lever, Greenhouse, Workday) support webhooks on new applications. Configure the webhook URL to point to your `/score` endpoint:

```json
{
  "webhook_url": "https://your-api.com/score",
  "event": "application.created",
  "payload_format": {
    "resume_text": "{{application.resume_text}}",
    "job_id": "{{job.id}}"
  }
}
```

The ATS will POST candidate data to your endpoint on each new application. Your API returns a `fit_score` 0–100 that the ATS can use to sort the candidate queue.

---

### Step 10: Troubleshooting

| Error | Cause | Fix |
|---|---|---|
| `botocore.exceptions.NoCredentialsError` | AWS credentials not configured | Run `aws configure` or set `AWS_ACCESS_KEY_ID` + `AWS_SECRET_ACCESS_KEY` in `.env` |
| SageMaker endpoint creation fails | IAM role missing SageMaker policies | Attach `AmazonSageMakerFullAccess` to your SageMaker execution role |
| W&B not logging | `WANDB_API_KEY` not set | Run `wandb login` or set the env var before training |
| LoRA `OOM` on GPU | Batch size too large | Reduce `per_device_train_batch_size` to 8 |
| `KeyError: 'LABEL_0'` | Model label format differs from expected | Print `classifier("test")[0]` to see actual label format, update `label_map` |
| ATS webhook timeout | Score endpoint takes >10s to respond | Pre-warm the model at startup, use async processing with a job queue |

---

## Evaluation Rubric

| Criteria | Meets | Exceeds |
|---|---|---|
| **Fine-tuning** | LoRA training completes; model saved | Both LoRA and OpenAI API paths working; W&B shows training curves |
| **Metrics** | F1 and AUC-ROC logged per epoch | Before/after comparison table in W&B; bias test across subgroups |
| **Deployment** | SageMaker endpoint created and callable | Health check endpoint; graceful fallback to local model |
| **API** | `/score` returns fit_score 0–100 | ATS webhook integration documented and tested |
| **Responsible AI** | Synthetic data used | Bias testing implemented; GDPR/EEOC considerations documented |

---

## Interview Talking Points

1. **Why synthetic data for HR fine-tuning?** — Real hire outcome data contains PII and is subject to GDPR, CCPA, and employment discrimination law. Synthetic data mimics statistical patterns safely. In production, you'd use real but de-identified data with explicit consent and legal review.

2. **Why AUC-ROC over accuracy for this task?** — Recruiters don't just want binary hire/reject — they want a ranked shortlist. AUC-ROC measures ranking quality: can the model consistently rank hired candidates higher than rejected ones? A model with 85% accuracy but 0.60 AUC is useless (it predicts the majority class). AUC > 0.85 is production-worthy.

3. **Why SageMaker over Lambda?** — A 250MB DistilBERT model is too large for Lambda's cold start budget. SageMaker keeps the model in memory on a dedicated instance, achieving <100ms inference latency. Lambda is optimal for lightweight inference (e.g., a simple classifier with a few KB of weights).

4. **How would you handle GDPR/EEOC compliance?** — Implement data minimisation (don't store resumes longer than necessary), provide explainability for each score (GDPR right to explanation), audit for disparate impact quarterly (EEOC requirements), and document the model card with known limitations and training data sources.

5. **How would you improve the model over time?** — Implement a feedback loop: when a hired candidate succeeds or fails in the role (6–12 months later), collect their performance rating and add it as a training signal. This creates a continuously improving model aligned to actual job performance, not just interview outcome.

---

## Bonus Extensions

- **Explainability:** Add SHAP values to explain which resume phrases drove the score — lawyers and candidates can challenge unexplained AI hiring decisions.
- **Multi-role models:** Fine-tune separate models for different job families (engineering vs marketing) — domain-specific patterns differ significantly enough to justify specialised models.
- **Interview question generation:** After scoring, generate 5 targeted interview questions based on gaps in the candidate's resume relative to the job requirements.
- **Batch scoring:** Add a `/score-batch` endpoint that accepts a CSV of candidates and returns ranked shortlist — useful for high-volume hiring campaigns.

