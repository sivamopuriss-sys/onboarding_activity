"""wandb_eval.py — Before/after model comparison with W&B"""
import wandb
import json
from sklearn.metrics import classification_report


def log_before_after_comparison(
    base_predictions: list,
    finetuned_predictions: list,
    true_labels: list,
    model_name: str = "distilbert-base-uncased",
):
    """Log before/after accuracy comparison to W&B."""
    wandb.init(project="trading-signal-engine", name="before-after-comparison")

    base_report = classification_report(true_labels, base_predictions,
                                       target_names=["Buy","Sell","Hold"], output_dict=True)
    ft_report   = classification_report(true_labels, finetuned_predictions,
                                       target_names=["Buy","Sell","Hold"], output_dict=True)

    # Log comparison table
    comparison_table = wandb.Table(
        columns=["Metric", "Base Model", "Fine-tuned", "Improvement"],
        data=[
            ["Overall Accuracy", base_report["accuracy"], ft_report["accuracy"],
             ft_report["accuracy"] - base_report["accuracy"]],
            ["Buy F1", base_report["Buy"]["f1-score"], ft_report["Buy"]["f1-score"],
             ft_report["Buy"]["f1-score"] - base_report["Buy"]["f1-score"]],
            ["Sell F1", base_report["Sell"]["f1-score"], ft_report["Sell"]["f1-score"],
             ft_report["Sell"]["f1-score"] - base_report["Sell"]["f1-score"]],
            ["Hold F1", base_report["Hold"]["f1-score"], ft_report["Hold"]["f1-score"],
             ft_report["Hold"]["f1-score"] - base_report["Hold"]["f1-score"]],
        ]
    )
    wandb.log({"before_after_comparison": comparison_table})
    print("Comparison logged to W&B. View at wandb.ai")
    wandb.finish()
