"""api.py — FastAPI inference endpoint"""
import os
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from openai import OpenAI
from langsmith_config import setup_langsmith
from dotenv import load_dotenv

load_dotenv()
setup_langsmith("project-22-trading-signals")
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
FINE_TUNED_MODEL = os.getenv("FINE_TUNED_MODEL", "gpt-4o-mini")

app = FastAPI(title="Trading Signal Engine")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

class SignalRequest(BaseModel):
    headline: str
    context: str = ""
    ticker: str = ""

@app.get("/health")
def health(): return {"status":"ok","model":FINE_TUNED_MODEL}

@app.post("/predict-signal")
def predict_signal(req: SignalRequest):
    try:
        resp = client.chat.completions.create(
            model=FINE_TUNED_MODEL,
            messages=[
                {"role":"system","content":"You are a financial analyst. Classify as Buy, Sell, or Hold. Return JSON: {signal, confidence, reasoning}"},
                {"role":"user","content":f"Headline: {req.headline}\nContext: {req.context}\nTicker: {req.ticker}"},
            ],
            response_format={"type":"json_object"},
            temperature=0.1,
        )
        return {"result": resp.choices[0].message.content, "model": FINE_TUNED_MODEL}
    except Exception as e:
        raise HTTPException(500, str(e))
