"""test_signals.py"""
import sys; sys.path.insert(0,"training")
from backtest import backtest_signals
import pandas as pd, numpy as np

def test_backtest_returns_dict():
    signals = pd.DataFrame({"date":["2024-01-02","2024-01-03"],
                             "ticker":["AAPL","AAPL"],"signal":["Buy","Hold"],"confidence":[0.9,0.7]})
    prices  = pd.DataFrame({"date":["2024-01-02","2024-01-03"],
                             "ticker":["AAPL","AAPL"],"open":[185.0,187.0],"close":[187.0,186.0]})
    result = backtest_signals(signals, prices)
    assert "total_return_pct" in result
    assert "sharpe_ratio" in result

def test_label_mapping():
    labels = {"Buy":0,"Sell":1,"Hold":2}
    assert labels["Buy"] == 0
    assert labels["Sell"] == 1
