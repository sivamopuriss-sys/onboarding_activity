"""backtest.py — Simple backtesting framework for trading signals"""
import pandas as pd
import numpy as np


def backtest_signals(signals_df: pd.DataFrame, prices_df: pd.DataFrame,
                     initial_capital: float = 10_000) -> dict:
    """
    Backtest Buy/Sell/Hold signals against historical prices.

    Args:
        signals_df: DataFrame with columns [date, signal, confidence]
        prices_df:  DataFrame with columns [date, open, close, ticker]
        initial_capital: Starting capital in USD

    Returns: dict with P&L, Sharpe ratio, max drawdown, accuracy metrics
    """
    merged = signals_df.merge(prices_df, on=["date","ticker"], how="inner")
    merged["return"] = merged["close"].pct_change().shift(-1)  # Next-day return

    # Signal to position mapping
    merged["position"] = merged["signal"].map({"Buy": 1, "Sell": -1, "Hold": 0})
    merged["strategy_return"] = merged["position"] * merged["return"]

    # Portfolio value
    merged["portfolio"] = initial_capital * (1 + merged["strategy_return"]).cumprod()
    final_value = merged["portfolio"].iloc[-1]
    total_return = (final_value - initial_capital) / initial_capital

    # Sharpe ratio (annualised, assuming 252 trading days)
    daily_std  = merged["strategy_return"].std()
    daily_mean = merged["strategy_return"].mean()
    sharpe = (daily_mean / daily_std) * np.sqrt(252) if daily_std > 0 else 0

    # Max drawdown
    rolling_max = merged["portfolio"].cummax()
    drawdown    = (merged["portfolio"] - rolling_max) / rolling_max
    max_drawdown = drawdown.min()

    # Signal accuracy (did Buy signals precede positive returns?)
    buy_signals  = merged[merged["signal"] == "Buy"]
    buy_accuracy = (buy_signals["return"] > 0).mean() if len(buy_signals) > 0 else 0

    sell_signals  = merged[merged["signal"] == "Sell"]
    sell_accuracy = (sell_signals["return"] < 0).mean() if len(sell_signals) > 0 else 0

    return {
        "initial_capital":    initial_capital,
        "final_value":        round(final_value, 2),
        "total_return_pct":   round(total_return * 100, 2),
        "sharpe_ratio":       round(sharpe, 3),
        "max_drawdown_pct":   round(max_drawdown * 100, 2),
        "buy_accuracy":       round(buy_accuracy, 3),
        "sell_accuracy":      round(sell_accuracy, 3),
        "total_signals":      len(merged),
        "buy_signals":        len(buy_signals),
        "sell_signals":       len(sell_signals),
    }
