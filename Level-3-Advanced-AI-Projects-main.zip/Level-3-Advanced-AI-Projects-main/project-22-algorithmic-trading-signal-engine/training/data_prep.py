"""data_prep.py — Prepare financial news dataset for fine-tuning"""
import json
import pandas as pd
from pathlib import Path

LABEL_MAP = {"Buy": 0, "Sell": 1, "Hold": 2}

def prepare_hf_dataset(input_path: str, output_dir: str = "data/"):
    """Prepare dataset for Hugging Face Trainer."""
    Path(output_dir).mkdir(exist_ok=True)
    with open(input_path) as f:
        records = [json.loads(l) for l in f]

    df = pd.DataFrame(records)
    df["label"] = df["signal"].map(LABEL_MAP)
    # 80/10/10 split
    train = df.sample(frac=0.8, random_state=42)
    remaining = df.drop(train.index)
    val  = remaining.sample(frac=0.5, random_state=42)
    test = remaining.drop(val.index)

    train.to_json(f"{output_dir}/train.jsonl", orient="records", lines=True)
    val.to_json(f"{output_dir}/val.jsonl",   orient="records", lines=True)
    test.to_json(f"{output_dir}/test.jsonl", orient="records", lines=True)

    print(f"Dataset split: {len(train)} train / {len(val)} val / {len(test)} test")
    return train, val, test


def prepare_openai_dataset(input_path: str, output_path: str = "data/openai_train.jsonl"):
    """Prepare dataset for OpenAI fine-tuning API (chat format)."""
    Path("data/").mkdir(exist_ok=True)
    with open(input_path) as f:
        records = [json.loads(l) for l in f]

    with open(output_path, "w") as out:
        for r in records:
            example = {
                "messages": [
                    {"role": "system", "content": "You are a financial analyst. Classify the news headline as Buy, Sell, or Hold signal."},
                    {"role": "user",   "content": f"Headline: {r['headline']}\nContext: {r.get('context','')}"},
                    {"role": "assistant", "content": r["signal"]},
                ]
            }
            out.write(json.dumps(example) + "\n")

    print(f"OpenAI dataset saved to {output_path}: {len(records)} examples")
    return output_path
