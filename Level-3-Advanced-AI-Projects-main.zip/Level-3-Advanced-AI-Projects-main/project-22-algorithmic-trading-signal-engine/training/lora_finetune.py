"""
lora_finetune.py — LoRA/QLoRA fine-tuning with Hugging Face + W&B tracking
Run on Google Colab (free T4) or locally with GPU.

Usage: python training/lora_finetune.py
"""
import os, wandb
from dotenv import load_dotenv

load_dotenv()
wandb.init(project=os.getenv("WANDB_PROJECT","trading-signal-engine"),
           name="lora-finetune-run-1", tags=["lora","financial-news"])

# ── Imports (install if running in Colab) ─────────────────────
try:
    import torch
    from transformers import (AutoTokenizer, AutoModelForSequenceClassification,
                              TrainingArguments, Trainer, DataCollatorWithPadding)
    from peft import LoraConfig, get_peft_model, TaskType
    from datasets import load_dataset
    import numpy as np
    from sklearn.metrics import accuracy_score, f1_score
except ImportError:
    print("Run: pip install torch transformers peft datasets accelerate bitsandbytes trl")
    raise

BASE_MODEL   = os.getenv("BASE_MODEL", "distilbert-base-uncased")
OUTPUT_DIR   = os.getenv("FINE_TUNED_MODEL_PATH", "./model_weights/trading-signal-lora")
LABEL2ID     = {"Buy": 0, "Sell": 1, "Hold": 2}
ID2LABEL     = {v: k for k, v in LABEL2ID.items()}

# ── Tokenizer + Model ─────────────────────────────────────────
tokenizer = AutoTokenizer.from_pretrained(BASE_MODEL)
model = AutoModelForSequenceClassification.from_pretrained(
    BASE_MODEL, num_labels=3, label2id=LABEL2ID, id2label=ID2LABEL)

# ── LoRA config ───────────────────────────────────────────────
lora_config = LoraConfig(
    task_type=TaskType.SEQ_CLS,
    r=8,                      # Rank — higher = more parameters, more expressive
    lora_alpha=16,            # Scaling factor
    lora_dropout=0.1,
    target_modules=["q_lin","k_lin","v_lin"],  # DistilBERT attention layers
    bias="none",
)
model = get_peft_model(model, lora_config)
model.print_trainable_parameters()
# Expected: ~0.5% of parameters trainable — that's the LoRA advantage

# ── Dataset ───────────────────────────────────────────────────
def tokenize(examples):
    return tokenizer(examples["headline"], truncation=True, max_length=128)

dataset = load_dataset("json", data_files={
    "train": "data/train.jsonl", "validation": "data/val.jsonl"})
dataset = dataset.map(tokenize, batched=True)
dataset = dataset.rename_column("label","labels")

# ── Metrics ───────────────────────────────────────────────────
def compute_metrics(eval_pred):
    logits, labels = eval_pred
    preds = np.argmax(logits, axis=-1)
    return {
        "accuracy": accuracy_score(labels, preds),
        "f1_macro": f1_score(labels, preds, average="macro"),
        "f1_buy":   f1_score(labels, preds, labels=[0], average="macro"),
        "f1_sell":  f1_score(labels, preds, labels=[1], average="macro"),
        "f1_hold":  f1_score(labels, preds, labels=[2], average="macro"),
    }

# ── Training ──────────────────────────────────────────────────
training_args = TrainingArguments(
    output_dir=OUTPUT_DIR,
    num_train_epochs=5,
    per_device_train_batch_size=16,
    per_device_eval_batch_size=32,
    evaluation_strategy="epoch",
    save_strategy="epoch",
    load_best_model_at_end=True,
    metric_for_best_model="f1_macro",
    report_to="wandb",          # Sends all metrics to W&B automatically
    logging_steps=10,
    learning_rate=2e-4,
    warmup_ratio=0.1,
    weight_decay=0.01,
)

trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=dataset["train"],
    eval_dataset=dataset["validation"],
    tokenizer=tokenizer,
    data_collator=DataCollatorWithPadding(tokenizer),
    compute_metrics=compute_metrics,
)

print("Starting LoRA fine-tuning... (view at wandb.ai)")
trainer.train()
trainer.save_model(OUTPUT_DIR)
print(f"Model saved to {OUTPUT_DIR}")
wandb.finish()
