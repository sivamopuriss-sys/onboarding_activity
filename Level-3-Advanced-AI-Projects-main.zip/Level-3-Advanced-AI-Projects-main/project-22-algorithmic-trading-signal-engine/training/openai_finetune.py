"""
openai_finetune.py — OpenAI Fine-tuning API alternative (no GPU needed)
Usage:
  python training/openai_finetune.py --prepare   # Prepare dataset
  python training/openai_finetune.py --train     # Submit fine-tuning job
  python training/openai_finetune.py --status    # Check job status
"""
import os, json, argparse, time, wandb
from openai import OpenAI
from data_prep import prepare_openai_dataset
from dotenv import load_dotenv

load_dotenv()
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))


def prepare():
    output = prepare_openai_dataset("../samples/sample_news_dataset.jsonl")
    print(f"Dataset ready: {output}")
    print("Validate with: openai tools fine_tunes.prepare_data -f data/openai_train.jsonl")


def train():
    wandb.init(project=os.getenv("WANDB_PROJECT","trading-signal-engine"),
               name="openai-finetune-run-1", tags=["openai","financial-news"])

    # Upload training file
    with open("data/openai_train.jsonl", "rb") as f:
        file_resp = client.files.create(file=f, purpose="fine-tune")
    print(f"File uploaded: {file_resp.id}")

    # Create fine-tuning job
    job = client.fine_tuning.jobs.create(
        training_file=file_resp.id,
        model="gpt-4o-mini-2024-07-18",  # Most cost-effective for fine-tuning
        hyperparameters={"n_epochs": 3, "batch_size": 8, "learning_rate_multiplier": 1.8},
    )
    print(f"Fine-tuning job created: {job.id}")

    # Log to W&B
    wandb.config.update({"job_id": job.id, "model": "gpt-4o-mini", "epochs": 3})

    # Save job ID for status check
    with open("data/openai_job_id.txt","w") as f:
        f.write(job.id)
    print(f"Job ID saved. Check status: python openai_finetune.py --status")
    wandb.finish()


def check_status():
    try:
        with open("data/openai_job_id.txt") as f:
            job_id = f.read().strip()
    except FileNotFoundError:
        print("No job ID found. Run --train first.")
        return

    job = client.fine_tuning.jobs.retrieve(job_id)
    print(f"Status: {job.status}")
    if job.status == "succeeded":
        print(f"Fine-tuned model ID: {job.fine_tuned_model}")
        print(f"Add to .env: FINE_TUNED_MODEL={job.fine_tuned_model}")
    elif job.status == "failed":
        print(f"Job failed: {job.error}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--prepare", action="store_true")
    parser.add_argument("--train",   action="store_true")
    parser.add_argument("--status",  action="store_true")
    args = parser.parse_args()
    if args.prepare: prepare()
    elif args.train: train()
    elif args.status: check_status()
    else: parser.print_help()
